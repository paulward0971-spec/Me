import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient } from "@tanstack/react-query";
import { PersistQueryClientProvider } from "@tanstack/react-query-persist-client";
import "@/index.css";
import App from "@/App";
import { hydrate, api } from "@/aib/mock";
import { idbPersister } from "@/offline/rqPersister";
import { registerProcessor, initSync } from "@/offline/sync";
import { registerServiceWorker } from "@/serviceWorkerRegistration";

const API = process.env.REACT_APP_BACKEND_URL;

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      gcTime: 1000 * 60 * 60 * 24, // keep for a day so cache can be persisted
      refetchOnWindowFocus: false,
      networkMode: "offlineFirst",
      retry: 1,
    },
    mutations: { networkMode: "offlineFirst" },
  },
});

// ---- offline queue processors ----------------------------------------------
// Queued transfer -> finalise locally now that we are online (money moves here,
// never while offline).
registerProcessor("transfer", async (payload) => {
  await api.syncQueuedTransfer(payload.transferId);
});

// Queued chat message -> deliver to the real backend assistant.
registerProcessor("chat", async (payload) => {
  const res = await fetch(`${API}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ session_id: payload.session_id, message: payload.message, context: payload.context || "" }),
  });
  if (!res.ok) throw new Error(`chat sync failed: ${res.status}`);
  const data = await res.json();
  if (data && Array.isArray(data.messages)) {
    try { await api.setChat(payload.session_id, data.messages); } catch (e) {}
  }
});

// ---- bootstrap --------------------------------------------------------------
async function bootstrap() {
  // 1. Initialise the local database and load cached data BEFORE first render,
  //    so the app opens instantly from local state (even with no network).
  try { await hydrate(); } catch (e) { /* fall back to in-memory seed */ }

  // 2. Start background synchronisation + register the PWA service worker.
  initSync();
  registerServiceWorker();

  const root = ReactDOM.createRoot(document.getElementById("root"));
  root.render(
    <React.StrictMode>
      <PersistQueryClientProvider client={queryClient} persistOptions={{ persister: idbPersister, maxAge: 1000 * 60 * 60 * 24 }}>
        <App />
      </PersistQueryClientProvider>
    </React.StrictMode>,
  );
}

bootstrap();
