// Connection + synchronisation status store (framework-agnostic, with a React hook).
import { useSyncExternalStore } from "react";

let state = {
  online: typeof navigator !== "undefined" ? navigator.onLine : true,
  // "online" | "offline" | "syncing" | "synced"
  status: (typeof navigator !== "undefined" && !navigator.onLine) ? "offline" : "online",
  pending: 0,
};

const listeners = new Set();
const onlineHandlers = new Set();

function emit() {
  state = { ...state };
  listeners.forEach((l) => { try { l(state); } catch (e) {} });
}

export function getState() { return state; }
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function subscribeOnline(fn) { onlineHandlers.add(fn); return () => onlineHandlers.delete(fn); }

export function setStatus(s) { if (state.status !== s) { state.status = s; emit(); } }
export function setPending(n) { if (state.pending !== n) { state.pending = n; emit(); } }
export function isOnline() { return state.online; }

if (typeof window !== "undefined") {
  window.addEventListener("online", () => {
    state.online = true;
    state.status = "syncing";
    emit();
    onlineHandlers.forEach((h) => { try { h(); } catch (e) {} });
  });
  window.addEventListener("offline", () => {
    state.online = false;
    state.status = "offline";
    emit();
  });
}

// React binding
export function useConnection() {
  return useSyncExternalStore(subscribe, getState, getState);
}
