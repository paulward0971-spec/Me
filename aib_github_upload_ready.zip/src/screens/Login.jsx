import React, { useEffect, useRef, useState } from "react";
import { authApi } from "../auth";

export default function Login({ onAuthenticated }) {
  const [pendingId, setPendingId] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(true);
  const [resending, setResending] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const inputRef = useRef(null);

  async function requestCode({ resend = false } = {}) {
    setError("");
    if (resend) setResending(true); else setBusy(true);
    try {
      const data = await authApi.requestCode();
      setPendingId(data.pendingId || "");
      setSent(true);
      setCode("");
      setTimeout(() => inputRef.current?.focus(), 0);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
      setResending(false);
    }
  }

  useEffect(() => {
    requestCode();
  }, []);

  async function verify(e) {
    e?.preventDefault();
    if (code.length !== 6 || !pendingId) return;
    setError(""); setBusy(true);
    try {
      await authApi.verifyCode(pendingId, code);
      onAuthenticated();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="private-login">
      <div className="private-login-card">
        <div className="private-login-mark">AIB</div>
        <h1>Private access</h1>
        <p>
          {sent
            ? "A one-time code has been sent to the authorised email address. Enter it below to continue."
            : "Preparing your one-time sign-in code…"}
        </p>
        <form onSubmit={verify}>
          <label htmlFor="private-code">One-time code</label>
          <input
            ref={inputRef}
            id="private-code"
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={6}
            value={code}
            onChange={e => setCode(e.target.value.replace(/\D/g, ""))}
            placeholder="000000"
            required
            autoFocus
          />
          <button type="submit" disabled={busy || code.length !== 6}>
            {busy ? "Checking…" : "Continue"}
          </button>
        </form>
        <button className="private-link" type="button" onClick={() => requestCode({ resend: true })} disabled={resending}>
          {resending ? "Sending new code…" : "Send me a new code"}
        </button>
        {error && <div className="private-error" role="alert">{error}</div>}
        <div className="private-note">
          The code is sent by Resend, expires after a short time, and can only be used once. Your browser stays signed in with a secure session cookie.
        </div>
      </div>
    </div>
  );
}
