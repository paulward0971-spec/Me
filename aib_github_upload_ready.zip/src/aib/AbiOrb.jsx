import React from "react";

// Abi's identity mark — the interlocking AIB "orb" used on the Help screen.
// Reused as the chat assistant avatar so Abi looks consistent everywhere.
export function AbiOrb({ size = 150, className, style }) {
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" className={className} style={style}>
      <defs>
        <linearGradient id="abiOrb1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#C24BE0" /><stop offset="1" stopColor="#7B1FA2" /></linearGradient>
        <linearGradient id="abiOrb2" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#B24DD1" /><stop offset="1" stopColor="#4A0E5C" /></linearGradient>
      </defs>
      <path d="M100 30 C 145 30, 170 60, 170 100 C 170 140, 145 170, 100 170 C 80 170, 65 158, 65 140 C 65 120, 82 108, 100 108 C 118 108, 130 96, 130 78 C 130 60, 118 46, 100 46 Z" fill="url(#abiOrb1)" />
      <path d="M100 60 C 128 60, 140 78, 140 100 C 140 122, 122 138, 100 138 C 90 138, 84 132, 84 122 C 84 112, 92 106, 100 106 C 116 106, 124 96, 124 82 C 124 68, 116 60, 100 60 Z" fill="url(#abiOrb2)" opacity="0.9" />
      <circle cx="100" cy="100" r="18" fill="#000" opacity="0.85" />
    </svg>
  );
}
