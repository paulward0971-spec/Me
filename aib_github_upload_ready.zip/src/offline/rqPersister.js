// TanStack Query <-> IndexedDB persister. Keeps useful query data across
// sessions so cached views render immediately, even offline.
import { dxdb } from "../aib/mock";

const KEY = "rq-cache";

export const idbPersister = {
  persistClient: async (client) => {
    try { await dxdb.meta.put({ key: KEY, value: client }); } catch (e) {}
  },
  restoreClient: async () => {
    try {
      const row = await dxdb.meta.get(KEY);
      return row ? row.value : undefined;
    } catch (e) {
      return undefined;
    }
  },
  removeClient: async () => {
    try { await dxdb.meta.delete(KEY); } catch (e) {}
  },
};
