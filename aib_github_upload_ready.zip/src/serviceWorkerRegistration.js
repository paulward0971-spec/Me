// Service worker registration + update lifecycle.
// Only active in production builds (the CRA dev server is not cached).

export function registerServiceWorker() {
  if (process.env.NODE_ENV !== "production") return;
  if (!("serviceWorker" in navigator)) return;

  window.addEventListener("load", () => {
    const swUrl = "/service-worker.js";
    navigator.serviceWorker
      .register(swUrl)
      .then((registration) => {
        // If there is already a waiting worker, surface the update prompt.
        if (registration.waiting) {
          window.__aibSwWaiting = registration.waiting;
          window.dispatchEvent(new Event("aib-sw-update"));
        }

        registration.addEventListener("updatefound", () => {
          const installing = registration.installing;
          if (!installing) return;
          installing.addEventListener("statechange", () => {
            if (installing.state === "installed" && navigator.serviceWorker.controller) {
              // A new version is ready and an old one is controlling the page.
              window.__aibSwWaiting = registration.waiting || installing;
              window.dispatchEvent(new Event("aib-sw-update"));
            }
          });
        });
      })
      .catch(() => { /* registration failed — app still works, just not cached */ });

    // When the new SW takes control, reload once to pick up fresh assets.
    let refreshing = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    });
  });
}
