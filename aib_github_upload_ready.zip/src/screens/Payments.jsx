import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import StatusBar from "../aib/StatusBar";
import BottomNav from "../aib/BottomNav";
import { api, formatIban } from "../aib/mock";
import { C } from "../aib/theme";

function Arrow({ dir }) {
  return (<svg width="22" height="22" viewBox="0 0 24 24" fill="none">{dir === "up" ? (<path d="M12 20 V4 M6 10 L12 4 L18 10" stroke="#fff" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" fill="none" />) : (<path d="M12 4 V20 M6 14 L12 20 L18 14" stroke="#fff" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" fill="none" />)}</svg>);
}

const rowS = { display: "flex", alignItems: "center", gap: 14, background: C.surfaceSecondary, padding: 16, borderRadius: 16, marginTop: 12, cursor: "pointer" };
const iconWrap = { width: 44, height: 44, borderRadius: 12, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 };

export default function Payments() {
  const nav = useNavigate();
  const [profile, setProfile] = useState(null);
  const [payees, setPayees] = useState([]);
  const [sheet, setSheet] = useState(null); // existing | request | standing
  const [so, setSo] = useState({ name: "", iban: "", amount: "", freq: "monthly" });
  const [copied, setCopied] = useState(false);

  useEffect(() => { api.getProfile().then(setProfile); api.listPayees().then(setPayees); }, []);

  const shareIban = async () => {
    const msg = `Please send money to my AIB account:\n\nName: ${profile?.account_holder}\nIBAN: ${formatIban(profile?.iban)}\nBIC: ${profile?.bic}`;
    try {
      if (navigator.share) await navigator.share({ text: msg });
      else { await navigator.clipboard.writeText(msg); setCopied(true); setTimeout(() => setCopied(false), 1500); return; }
    } catch (e) {}
    setSheet(null);
  };

  const rows = [
    { t: "Pay someone new", s: "Send a SEPA transfer with IBAN", dir: "up", on: () => nav("/transfer/new") },
    { t: "Sent transfers", s: "Track your SEPA transfers & arrival", dir: "down", on: () => nav("/transfers") },
    { t: "Pay an existing payee", s: "Choose from your saved payees", dir: "up", on: () => setSheet("existing") },
    { t: "Request money", s: "Send someone your IBAN", dir: "down", on: () => setSheet("request") },
    { t: "Standing orders", s: "Recurring payments & arrival times", dir: "up", on: () => nav("/standing-orders") },
  ];

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }}>
      <StatusBar />
      <div style={{ padding: "0 20px 12px" }}>
        <div style={{ color: "#fff", fontSize: 32, fontWeight: 900 }}>Payments</div>
        <div style={{ color: C.muted, marginTop: 4 }}>Send and receive money</div>
      </div>
      <div className="aib-scroll" style={{ flex: 1, padding: "0 16px 24px" }}>
        {rows.map((r, i) => (
          <div key={i} className="aib-press" style={rowS} onClick={r.on}>
            <div style={iconWrap}><Arrow dir={r.dir} /></div>
            <div style={{ flex: 1 }}>
              <div style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>{r.t}</div>
              <div style={{ color: C.muted, marginTop: 4, fontSize: 13 }}>{r.s}</div>
            </div>
            <span style={{ color: C.muted, fontSize: 24 }}>›</span>
          </div>
        ))}
      </div>
      <BottomNav active="payments" />

      {sheet && (
        <div onClick={() => setSheet(null)} style={backdrop}>
          <div onClick={(e) => e.stopPropagation()} style={sheetS} className="aib-fadein">
            <div style={grabber} />
            {sheet === "existing" && (<>
              <div style={sheetTitle}>Choose a payee</div>
              {payees.length === 0 ? <div style={{ color: C.muted, marginBottom: 12 }}>You have no saved payees yet.</div> : payees.map((p) => (
                <div key={p.id} className="aib-press" style={payeeRow} onClick={() => { setSheet(null); nav("/transfer/new"); }}>
                  <div style={payeeAvatar}>{p.name.split(" ").map((s) => s[0]).slice(0, 2).join("").toUpperCase()}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>{p.name}</div>
                    <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>{p.bank_name} • {formatIban(p.iban).slice(0, 19)}…</div>
                  </div>
                  <span style={{ color: C.muted, fontSize: 24 }}>›</span>
                </div>
              ))}
              <div className="aib-btn" style={sheetBtn} onClick={() => { setSheet(null); nav("/transfer/new"); }}>New payee</div>
            </>)}
            {sheet === "request" && (<>
              <div style={sheetTitle}>Request money</div>
              <div style={{ color: C.muted, fontSize: 14, marginBottom: 12 }}>Share your IBAN so someone can pay you.</div>
              <div style={{ background: "#161616", padding: 14, borderRadius: 12, marginBottom: 16 }}>
                <div style={detailLabel}>Name</div><div style={detailValue}>{profile?.account_holder}</div>
                <div style={{ ...detailLabel, marginTop: 12 }}>IBAN</div><div style={detailValue}>{formatIban(profile?.iban || "")}</div>
                <div style={{ ...detailLabel, marginTop: 12 }}>BIC</div><div style={detailValue}>{profile?.bic}</div>
              </div>
              <div className="aib-btn" style={sheetBtn} onClick={shareIban}>{copied ? "Copied to clipboard ✓" : "Share IBAN"}</div>
            </>)}
            {sheet === "standing" && (<>
              <div style={sheetTitle}>New standing order</div>
              <input style={inp} placeholder="Payee name" value={so.name} onChange={(e) => setSo({ ...so, name: e.target.value })} />
              <input style={inp} placeholder="IBAN" value={so.iban} onChange={(e) => setSo({ ...so, iban: e.target.value.toUpperCase() })} />
              <input style={inp} placeholder="Amount (EUR)" value={so.amount} onChange={(e) => setSo({ ...so, amount: e.target.value })} />
              <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                {["weekly", "monthly"].map((f) => (
                  <div key={f} className="aib-press" onClick={() => setSo({ ...so, freq: f })} style={{ padding: "10px 16px", borderRadius: 999, background: so.freq === f ? C.brandPrimary : "#161616", color: so.freq === f ? "#fff" : C.muted, fontWeight: 700 }}>{f[0].toUpperCase() + f.slice(1)}</div>
                ))}
              </div>
              <div className="aib-btn" style={sheetBtn} onClick={() => { setSheet(null); nav("/transfer/new"); }}>Continue</div>
            </>)}
          </div>
        </div>
      )}
    </div>
  );
}

const backdrop = { position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "flex-end", zIndex: 50 };
const sheetS = { width: "100%", background: "#0F0F0F", padding: "20px 20px 32px", borderTopLeftRadius: 20, borderTopRightRadius: 20 };
const grabber = { width: 40, height: 4, borderRadius: 2, background: "#3D3D3D", margin: "0 auto 16px" };
const sheetTitle = { color: "#fff", fontSize: 20, fontWeight: 900, marginBottom: 12 };
const payeeRow = { display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "0.5px solid #1F1F1F" };
const payeeAvatar = { width: 40, height: 40, borderRadius: 20, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 13 };
const detailLabel = { color: C.muted, fontSize: 12, fontWeight: 700 };
const detailValue = { color: "#fff", fontSize: 15, fontWeight: 800, marginTop: 4 };
const inp = { width: "100%", background: "#161616", color: "#fff", padding: 14, borderRadius: 12, fontSize: 15, fontWeight: 600, marginBottom: 10, border: "none" };
const sheetBtn = { background: C.brandPrimary, padding: 14, borderRadius: 999, textAlign: "center", marginTop: 8, color: "#fff", fontSize: 15, fontWeight: 800 };
