import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sprout, Percent, Umbrella, TrendingUp, HelpCircle, Phone, Calendar, CheckCircle2, PauseCircle, MessageCircle, Shuffle, Home as HomeIcon, Car, ChevronRight, Bell, MoreVertical, Search, Trash2, X, Pencil, PlusCircle } from "lucide-react";
import { api, formatEuros, initialsFor, getFreshness, subscribeFreshness } from "../aib/mock";
import { useConnection } from "../offline/connection";
import { timeAgo } from "../offline/time";
import { C } from "../aib/theme";
import { BankLogo } from "../aib/BankLogo";
import { AIB_BRANCHES } from "../aib/branches";
import BottomNav from "../aib/BottomNav";

const CATS = ["All", "Everyday", "Savings", "Invest", "Loans", "Mortgages", "Insurance"];

export default function Home() {
  const nav = useNavigate();
  const [profile, setProfile] = useState(null);
  const [txns, setTxns] = useState([]);
  const [cat, setCat] = useState("Everyday");
  const [toast, setToast] = useState(null);
  const [sheet, setSheet] = useState(null); // menu | balance | deposit | transactions
  const [balForm, setBalForm] = useState({ balance: "", available: "" });
  const [depAmount, setDepAmount] = useState("");
  const [depBranch, setDepBranch] = useState("");
  const [branchQuery, setBranchQuery] = useState("");

  useEffect(() => { api.getProfile().then(setProfile); api.listTransactions().then(setTxns); }, []);
  const show = (m) => { setToast(m); setTimeout(() => setToast(null), 1700); };

  const openMenu = () => setSheet("menu");
  const openBalance = () => {
    setBalForm({ balance: ((profile?.balance_cents || 0) / 100).toFixed(2), available: ((profile?.available_cents || 0) / 100).toFixed(2) });
    setSheet("balance");
  };
  const saveBalance = async () => {
    const b = Math.round(parseFloat(balForm.balance || "0") * 100);
    const a = balForm.available === "" ? b : Math.round(parseFloat(balForm.available || "0") * 100);
    const p = await api.setBalance(isNaN(b) ? 0 : b, isNaN(a) ? 0 : a);
    setProfile(p); setSheet(null); show("Balance updated");
  };
  const doDeposit = async () => {
    const amt = Math.round(parseFloat(depAmount || "0") * 100);
    if (!amt || amt <= 0) { show("Enter a deposit amount"); return; }
    const r = await api.addDeposit({ amount_cents: amt, branch: depBranch });
    setProfile(r.profile); setTxns(await api.listTransactions());
    setDepAmount(""); setDepBranch(""); setBranchQuery(""); setSheet(null); show("AIB deposit added");
  };
  const doDelete = async (id) => {
    await api.deleteTransaction(id);
    setTxns(await api.listTransactions()); show("Transaction deleted");
  };

  const filteredBranches = useMemo(() => {
    const q = branchQuery.trim().toLowerCase();
    const list = q ? AIB_BRANCHES.filter((b) => `${b.name} ${b.county}`.toLowerCase().includes(q)) : AIB_BRANCHES;
    return list.slice(0, 60);
  }, [branchQuery]);

  const name = profile?.display_name || "John";
  const initials = useMemo(() => {
    const v = profile?.account_holder || profile?.display_name || "JG";
    return v.split(/\s+/).map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  }, [profile]);
  const spent = formatEuros(profile?.monthly_spent_cents || 0).replace("-", "");

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }}>
      {/* Everything (header, tabs and activity) lives in one scroller so the whole
          page — from the tabs right up to "Hi John" — scrolls away as you look through history. */}
      <div className="aib-scroll" style={{ flex: 1 }}>
      <div className="aib-header" style={{ position: "relative", flexShrink: 0, overflow: "hidden", background: "linear-gradient(180deg,#A11FA5 0%,#8C1B8E 100%)" }}>
        <svg viewBox="0 0 402 214" preserveAspectRatio="none" width="100%" height="100%" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
          <defs>
            <linearGradient id="rb1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#C868DA" /><stop offset="1" stopColor="#9A2FB4" stopOpacity="0" /></linearGradient>
            <linearGradient id="rb2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F0D2F6" /><stop offset="1" stopColor="#C060D6" stopOpacity="0" /></linearGradient>
            <linearGradient id="rb3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#D98FE6" /><stop offset="1" stopColor="#A83FBE" stopOpacity="0" /></linearGradient>
          </defs>
          <path d="M-30 38 C 120 112, 250 18, 440 92 L440 152 C 250 96, 120 168, -30 112 Z" fill="url(#rb1)" opacity="0.55" />
          <path d="M-30 82 C 130 148, 260 56, 440 122 L440 148 C 260 92, 130 168, -30 122 Z" fill="url(#rb3)" opacity="0.6" />
          <path d="M-30 102 C 140 160, 270 72, 440 130 L440 140 C 270 90, 140 174, -30 130 Z" fill="url(#rb2)" opacity="0.7" />
          <path d="M-6 178 C 120 158, 250 208, 440 164 L440 220 L-6 220 Z" fill="#000" />
          <path d="M-6 178 C 120 158, 250 208, 440 164" fill="none" stroke="#E2A6EE" strokeOpacity="0.4" strokeWidth="1.6" />
        </svg>
        <div className="aib-safe-top" style={{ position: "relative", paddingLeft: 20, paddingRight: 20, paddingBottom: 0 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div className="aib-press" onClick={() => nav("/settings")} style={{ width: 44, height: 44, borderRadius: 22, background: "#5C0875", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontWeight: 900, fontSize: 15 }}>{initials}</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
              <HelpCircle className="aib-press" onClick={() => nav("/help")} size={26} color="#fff" strokeWidth={1.9} />
              <Bell className="aib-press" onClick={() => show("No new notifications")} size={26} color="#fff" strokeWidth={1.9} />
            </div>
          </div>
          <div style={{ color: "#fff", fontWeight: 900, fontSize: 34, marginTop: 14, lineHeight: "38px" }}>Hi {name}</div>
          <div style={{ color: "#fff", fontWeight: 800, fontSize: 18, marginTop: 6, marginBottom: 16 }}>You've spent {spent} this month</div>
        </div>
      </div>

      {/* Scrollable content — category tabs live inside the scroller so they
          scroll up out of view as you swipe down through the history. */}
        <div style={{ display: "flex", gap: 26, overflowX: "auto", padding: "16px 20px 14px", background: "#000", scrollbarWidth: "none" }}>
          {CATS.map((c) => {
            const on = c === cat;
            return (
              <div key={c} className="aib-press" onClick={() => setCat(c)} style={{ flexShrink: 0, padding: on ? "8px 18px" : "8px 2px", borderRadius: 999, background: on ? C.brandPrimary : "transparent", color: "#fff", fontSize: 20, fontWeight: on ? 800 : 700, whiteSpace: "nowrap" }}>{c}</div>
            );
          })}
        </div>
        <div style={{ padding: "4px 16px 24px" }}>
          {(cat === "Everyday" || cat === "All") && <Everyday profile={profile} txns={txns} nav={nav} show={show} onMenu={openMenu} />}
          {cat === "Savings" && <Savings show={show} />}
          {cat === "Invest" && <Invest show={show} />}
          {cat === "Loans" && <Loans show={show} />}
          {cat === "Mortgages" && <Mortgages show={show} />}
          {cat === "Insurance" && <Insurance show={show} />}
        </div>
      </div>

      {/* Bottom nav (original icons) */}
      <BottomNav active="home" />

      {sheet && (
        <div onClick={() => setSheet(null)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "flex-end", zIndex: 50 }}>
          <div onClick={(e) => e.stopPropagation()} className="aib-fadein" style={{ width: "100%", background: "#0F0F0F", padding: "18px 20px 30px", borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: "80%", display: "flex", flexDirection: "column" }}>
            <div style={{ width: 40, height: 4, borderRadius: 2, background: "#3D3D3D", margin: "0 auto 16px" }} />

            {sheet === "menu" && (<>
              <div style={{ color: "#fff", fontSize: 20, fontWeight: 900, marginBottom: 14 }}>{profile?.account_label || "AIB Bank Account"}</div>
              <MenuRow testid="menu-edit-balance" icon={<Pencil size={20} color={C.brandTertiary} />} title="Edit balance" sub="Change your balance and available funds" onClick={openBalance} />
              <MenuRow testid="menu-add-deposit" icon={<PlusCircle size={20} color={C.brandTertiary} />} title="Add AIB deposit" sub="Lodge a deposit from an AIB branch" onClick={() => setSheet("deposit")} />
              <MenuRow testid="menu-delete-txn" icon={<Trash2 size={20} color={C.brandTertiary} />} title="Delete transactions" sub="Remove items from your activity" onClick={() => setSheet("transactions")} last />
            </>)}

            {sheet === "balance" && (<>
              <div style={{ color: "#fff", fontSize: 20, fontWeight: 900, marginBottom: 14 }}>Edit balance</div>
              <Lbl>Balance (EUR)</Lbl>
              <input data-testid="balance-input" style={sheetInp} value={balForm.balance} onChange={(e) => setBalForm((f) => ({ ...f, balance: e.target.value }))} placeholder="0.00" inputMode="decimal" />
              <Lbl>Available (EUR)</Lbl>
              <input data-testid="available-input" style={sheetInp} value={balForm.available} onChange={(e) => setBalForm((f) => ({ ...f, available: e.target.value }))} placeholder="0.00" inputMode="decimal" />
              <div className="aib-btn" data-testid="save-balance-btn" onClick={saveBalance} style={sheetPrimary}>Save balance</div>
              <div className="aib-press" onClick={() => setSheet("menu")} style={sheetCancel}>Back</div>
            </>)}

            {sheet === "deposit" && (<>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                <BankLogo slug="aib" size={40} />
                <div style={{ flex: 1 }}>
                  <div style={{ color: "#fff", fontSize: 18, fontWeight: 900 }}>AIB</div>
                  <div style={{ color: C.muted, fontSize: 12, fontWeight: 700 }}>Deposit from an AIB branch</div>
                </div>
              </div>
              <Lbl>Amount (EUR)</Lbl>
              <input data-testid="deposit-amount-input" style={sheetInp} value={depAmount} onChange={(e) => setDepAmount(e.target.value)} placeholder="0.00" inputMode="decimal" />
              <Lbl>AIB branch</Lbl>
              <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.surfaceSecondary, borderRadius: 12, padding: "10px 14px", marginBottom: 8 }}>
                <Search size={18} color={C.muted} />
                <input data-testid="branch-search-input" value={branchQuery} onChange={(e) => setBranchQuery(e.target.value)} placeholder="Search all AIB branches in Ireland" style={{ flex: 1, background: "transparent", border: "none", color: "#fff", fontSize: 14 }} />
              </div>
              <div className="aib-scroll" style={{ maxHeight: 220, overflowY: "auto", background: "#141416", borderRadius: 12 }}>
                {filteredBranches.length === 0 && <div style={{ color: C.muted, fontSize: 13, padding: 16, textAlign: "center" }}>No branches found.</div>}
                {filteredBranches.map((b, i) => {
                  const on = depBranch === b.name;
                  return (
                    <div key={b.name + i} data-testid="branch-option" className="aib-press" onClick={() => setDepBranch(b.name)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderBottom: i < filteredBranches.length - 1 ? "0.5px solid #1F1F1F" : "none", background: on ? "rgba(142,36,170,0.16)" : "transparent" }}>
                      <BankLogo slug="aib" size={30} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>AIB {b.name}</div>
                        <div style={{ color: C.muted, fontSize: 12, marginTop: 1 }}>Co. {b.county}</div>
                      </div>
                      {on && <CheckCircle2 size={20} color={C.brandTertiary} />}
                    </div>
                  );
                })}
              </div>
              <div className="aib-btn" data-testid="confirm-deposit-btn" onClick={doDeposit} style={{ ...sheetPrimary, opacity: depAmount && Number(depAmount) > 0 ? 1 : 0.5 }}>{depBranch ? `Deposit from AIB ${depBranch}` : "Add deposit"}</div>
              <div className="aib-press" onClick={() => setSheet("menu")} style={sheetCancel}>Back</div>
            </>)}

            {sheet === "transactions" && (<>
              <div style={{ color: "#fff", fontSize: 20, fontWeight: 900, marginBottom: 6 }}>Delete transactions</div>
              <div style={{ color: C.muted, fontSize: 13, marginBottom: 12 }}>Tap the bin to remove an item from your activity.</div>
              <div className="aib-scroll" style={{ overflowY: "auto", background: "#141416", borderRadius: 12 }}>
                {txns.length === 0 && <div style={{ color: C.muted, fontSize: 13, padding: 16, textAlign: "center" }}>No transactions.</div>}
                {txns.map((t, i) => (
                  <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderBottom: i < txns.length - 1 ? "0.5px solid #1F1F1F" : "none" }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: "#fff", fontSize: 15, fontWeight: 800, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.merchant}</div>
                      <div style={{ color: C.muted, fontSize: 12, marginTop: 1 }}>{new Date(t.date).toLocaleDateString("en-IE", { day: "2-digit", month: "short" })} • {formatEuros(t.amount_cents)}</div>
                    </div>
                    <div className="aib-press" data-testid="delete-txn-btn" onClick={() => doDelete(t.id)} style={{ width: 38, height: 38, borderRadius: 19, background: "rgba(255,82,82,0.14)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Trash2 size={18} color={C.error} /></div>
                  </div>
                ))}
              </div>
              <div className="aib-press" onClick={() => setSheet("menu")} style={sheetCancel}>Back</div>
            </>)}
          </div>
        </div>
      )}

      {toast && <div className="aib-fadein" style={{ position: "absolute", left: 24, right: 24, bottom: 110, background: "rgba(20,20,22,0.96)", border: "1px solid #2A2A2A", borderRadius: 14, padding: "14px 18px", color: "#fff", fontSize: 14, fontWeight: 700, textAlign: "center", zIndex: 40, boxShadow: "0 10px 30px rgba(0,0,0,0.5)" }}>{toast}</div>}
    </div>
  );
}

/* ---------- Category content ---------- */

function Everyday({ profile, txns, nav, show, onMenu }) {
  return (
    <div className="aib-fadein">
      <div style={{ background: "#1A1A1C", borderRadius: 16, padding: 18, marginTop: 8 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <span style={{ color: C.brandLight, fontSize: 15, fontWeight: 900, letterSpacing: 0.3 }}>{profile?.account_label || "AIB BANK ACCOUNT-017"}</span>
          <div className="aib-press" data-testid="account-menu-btn" onClick={onMenu} style={{ width: 30, height: 30, borderRadius: 15, display: "flex", alignItems: "center", justifyContent: "center", marginTop: -4, marginRight: -6 }}><MoreVertical size={20} color={C.muted} /></div>
        </div>
        <div style={{ color: "#fff", fontSize: 34, fontWeight: 900, marginTop: 6 }}>{formatEuros(profile?.balance_cents || 0)}</div>
        <div style={{ color: C.muted, fontSize: 15, marginTop: 2 }}>{formatEuros(profile?.available_cents || 0)} available</div>
        <BalanceFreshness />
        <div style={{ height: 1, background: "#2A2A2A", margin: "14px 0" }} />
        <div className="aib-press" onClick={() => show("Opening a new account\u2026")} style={{ color: C.brandLight, fontSize: 16, fontWeight: 800, textAlign: "center" }}>Open a new account</div>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "22px 0 12px" }}>
        <span style={{ color: "#fff", fontSize: 24, fontWeight: 900 }}>Activity</span>
        <span className="aib-press" onClick={() => nav("/transactions")} style={{ color: C.brandLight, fontSize: 15, fontWeight: 800 }}>See all</span>
      </div>
      <div style={{ background: "#141416", borderRadius: 16, overflow: "hidden" }}>
        {txns.slice(0, 5).map((t, i, arr) => {
          const d = new Date(t.date);
          const dateStr = d.toLocaleDateString("en-IE", { day: "2-digit", month: "short" });
          const declined = t.status === "declined";
          const credit = t.amount_cents > 0;
          const isApp = (t.merchant || "").toLowerCase().includes("google play");
          const isAib = (t.merchant || "").toLowerCase().startsWith("aib");
          return (
            <div key={t.id} className="aib-press" onClick={() => nav(`/transaction/${t.id}`)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 14px", borderBottom: i < arr.length - 1 ? "0.5px solid #1F1F1F" : "none" }}>
              {isApp ? (
                <div style={{ width: 44, height: 44, borderRadius: 12, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, overflow: "hidden" }}>
                  <img src="/aib/google-play.png" alt="Google Play" style={{ width: 34, height: 34, objectFit: "contain" }} />
                </div>
              ) : isAib ? (
                <BankLogo slug="aib" size={44} />
              ) : (
                <div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(160deg,#8E24AA,#4A0E5C)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 15, flexShrink: 0 }}>{initialsFor(t.merchant)}</div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: "#fff", fontSize: 16, fontWeight: 800 }}>{t.merchant}</div>
                <div style={{ color: C.muted, fontSize: 13, marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{dateStr} • {t.label || "Payment"}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ color: declined ? C.muted : credit ? C.success : "#fff", fontSize: 16, fontWeight: 800, textDecoration: declined ? "line-through" : "none" }}>{formatEuros(t.amount_cents)}</div>
                {declined && <div style={{ color: C.error, fontSize: 13, fontWeight: 700, marginTop: 2 }}>Declined</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Savings({ show }) {
  return (
    <div className="aib-fadein">
      <Hero src="/aib/icons/savings.png" />
      <H2>Start a savings habit. Put money away regularly, or save a lump sum.</H2>
      <Card>
        <div style={{ color: "#fff", fontSize: 18, fontWeight: 600, textAlign: "center", lineHeight: "26px" }}>Start saving today with a savings account that keeps your money safe and growing.</div>
        <PurpleBtn onClick={() => show("Opening a new account\u2026")}>Open a new account</PurpleBtn>
      </Card>
      <RowCard icon={<Percent size={24} color={C.brandTertiary} />} title="Deposit rates" onClick={() => show("Deposit rates")} />
      <RowCard icon={<Calendar size={24} color={C.brandTertiary} />} title="Book an appointment" onClick={() => show("Book an appointment")} />
      <RowCard icon={<HelpCircle size={24} color={C.brandTertiary} />} title="Don't see an account?" sub="Add one of your accounts to the app" onClick={() => show("Add an account")} />
      <Footer />
    </div>
  );
}

function Invest({ show }) {
  return (
    <div className="aib-fadein">
      <Hero src="/aib/icons/invest.png" />
      <H2>Plan for your future with pensions and investments</H2>
      <Card>
        <ListItem icon={<TrendingUp size={24} color={C.muted} />} title="Invest in your future" body="You don't need big money to start, investing for the long-term gives your money the greater chance of growing in value." />
        <ListItem icon={<Sprout size={24} color={C.muted} />} title="Grow your pension your way" body="Having a good plan for retirement gives you freedom and choice for the future." />
        <ListItem icon={<Umbrella size={24} color={C.muted} />} title="Protect what matters to you" body="Provide cover for the people you love. Find out how you can protect yourself, family, income and mortgage if something happens." />
        <ListItem icon={<HelpCircle size={24} color={C.muted} />} title="Not sure where to start?" body="Check out our informative articles and useful calculators. You can speak to a financial advisor to discuss what's right for you." last />
        <PurpleBtn onClick={() => show("Continuing to AIB life Hub\u2026")}>Continue to AIB life Hub</PurpleBtn>
        <div style={{ color: "#fff", fontSize: 16, fontWeight: 800, textAlign: "center", lineHeight: "23px", marginTop: 14 }}>Your personal data will be shared with AIB life to enable you to use the AIB life Hub.</div>
      </Card>
      <RowCard icon={<Phone size={24} color={C.brandTertiary} />} title="Ready to speak to an AIB Financial Advisor?" onClick={() => show("Connecting you to an advisor\u2026")} />
      <RowCard icon={<HelpCircle size={24} color={C.brandTertiary} />} title="Don't see an account?" sub="Add one of your accounts to the app" onClick={() => show("Add an account")} />
      <Footer />
    </div>
  );
}

function Loans({ show }) {
  return (
    <div className="aib-fadein">
      <Hero src="/aib/icons/loans.png" />
      <H2>Make your plans real with a personal loan up to €30,000</H2>
      <Card>
        <ListItem icon={<Calendar size={24} color={C.muted} />} title="Set your repayment frequency" body="Weekly, fortnightly or monthly" />
        <ListItem icon={<CheckCircle2 size={24} color={C.muted} />} title="Pay off your loan early" body="No penalties for over payments" />
        <ListItem icon={<PauseCircle size={24} color={C.muted} />} title="Loan repayment holidays" body="Take a repayment break at certain times of the year" last />
        <PurpleBtn onClick={() => show("Starting your loan application\u2026")}>Apply for a loan</PurpleBtn>
      </Card>
      <RowCard icon={<CheckCircle2 size={24} color={C.brandTertiary} />} title="Your applications" onClick={() => show("No applications yet")} />
      <RowCard icon={<HelpCircle size={24} color={C.brandTertiary} />} title="Don't see an account?" sub="Add one of your accounts to the app" onClick={() => show("Add an account")} />
      <Footer />
    </div>
  );
}

function Mortgages({ show }) {
  return (
    <div className="aib-fadein">
      <Hero src="/aib/icons/mortgages.png" />
      <H2>Variable rate, fixed rate or green fixed rate mortgages.</H2>
      <Card>
        <ListItem icon={<MessageCircle size={24} color={C.muted} />} title="Expert advice" body="Available in branch or over the phone" />
        <ListItem icon={<Shuffle size={24} color={C.muted} />} title="No fees" body="Pay from an AIB account to avoid fees" last />
      </Card>
      <Card>
        <div style={{ color: "#fff", fontSize: 22, fontWeight: 900, textAlign: "center" }}>Apply or manage application</div>
        <div style={{ color: "#fff", fontSize: 16, fontWeight: 500, textAlign: "center", lineHeight: "24px", marginTop: 8 }}>Whatever stage you're at - calculate, apply, or continue your mortgage application</div>
        <PurpleBtn onClick={() => show("Opening MyMortgage\u2026")}>Go to MyMortgage</PurpleBtn>
      </Card>
      <Footer />
    </div>
  );
}

function Insurance({ show }) {
  return (
    <div className="aib-fadein">
      <Hero src="/aib/icons/insurance.png" />
      <H2>Protect your family into the future.</H2>
      <div style={{ background: "#141416", borderRadius: 16, overflow: "hidden", marginTop: 6 }}>
        <InsRow icon={<HomeIcon size={22} color="#fff" />} title="AIB Home Insurance" sub="In partnership with AXA" onClick={() => show("AIB Home Insurance")} />
        <InsRow icon={<Car size={22} color="#fff" />} title="AIB Car Insurance" sub="In partnership with AXA" onClick={() => show("AIB Car Insurance")} last />
      </div>
      <Footer />
    </div>
  );
}

/* ---------- Building blocks ---------- */

function Hero({ src }) {
  return (
    <div style={{ display: "flex", justifyContent: "center", marginTop: 18, marginBottom: 6 }}>
      <div style={{ width: 132, height: 132, borderRadius: 30, overflow: "hidden", boxShadow: "0 10px 30px rgba(0,0,0,0.35)", background: "#F3EFF6" }}>
        <img src={src} alt="" draggable={false} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      </div>
    </div>
  );
}
function H2({ children }) {
  return <div style={{ color: "#fff", fontSize: 28, fontWeight: 900, textAlign: "center", lineHeight: "36px", margin: "14px 6px 18px" }}>{children}</div>;
}
function Card({ children }) {
  return <div style={{ background: "#1A1A1C", borderRadius: 18, padding: 20, marginBottom: 16 }}>{children}</div>;
}
function PurpleBtn({ children, onClick }) {
  return <div className="aib-btn" onClick={onClick} style={{ background: C.brandPrimary, padding: 16, borderRadius: 999, textAlign: "center", color: "#fff", fontSize: 17, fontWeight: 800, marginTop: 18 }}>{children}</div>;
}
function ListItem({ icon, title, body, last }) {
  return (
    <div style={{ display: "flex", gap: 14, paddingBottom: last ? 0 : 22 }}>
      <div style={{ marginTop: 2, flexShrink: 0 }}>{icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ color: "#fff", fontSize: 20, fontWeight: 800 }}>{title}</div>
        <div style={{ color: C.muted, fontSize: 17, marginTop: 4, lineHeight: "24px" }}>{body}</div>
      </div>
    </div>
  );
}
function RowCard({ icon, title, sub, onClick }) {
  return (
    <div className="aib-press" onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 16, background: "#1A1A1C", borderRadius: 16, padding: "18px 16px", marginBottom: 12 }}>
      <div style={{ flexShrink: 0 }}>{icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ color: "#fff", fontSize: 19, fontWeight: 800 }}>{title}</div>
        {sub && <div style={{ color: C.muted, fontSize: 16, marginTop: 3 }}>{sub}</div>}
      </div>
      <ChevronRight size={20} color={C.muted} />
    </div>
  );
}
function InsRow({ icon, title, sub, onClick, last }) {
  return (
    <div className="aib-press" onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 14px", borderBottom: last ? "none" : "0.5px solid #1F1F1F" }}>
      <div style={{ width: 44, height: 44, borderRadius: 12, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ color: "#fff", fontSize: 19, fontWeight: 800 }}>{title}</div>
        <div style={{ color: C.muted, fontSize: 16, marginTop: 2 }}>{sub}</div>
      </div>
      <ChevronRight size={20} color={C.muted} />
    </div>
  );
}
function Footer() {
  return <div style={{ color: C.muted, fontSize: 15, textAlign: "center", lineHeight: "22px", margin: "14px 10px 8px" }}>Allied Irish Banks, p.l.c is regulated by the Central Bank of Ireland.</div>;
}

// Shows how fresh the displayed balance is and, when offline, makes it clear
// this is the last-known server balance (never presented as live).
function BalanceFreshness() {
  const conn = useConnection();
  const [, setTick] = useState(0);
  useEffect(() => {
    const unsub = subscribeFreshness(() => setTick((n) => n + 1));
    const iv = setInterval(() => setTick((n) => n + 1), 30000);
    return () => { unsub(); clearInterval(iv); };
  }, []);
  const f = getFreshness();
  const when = timeAgo(f.lastUpdated || Date.now());
  const offline = !conn.online;
  return (
    <div data-testid="balance-freshness" style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 8 }}>
      <span style={{ width: 7, height: 7, borderRadius: 4, background: offline ? C.warning : C.success, flexShrink: 0 }} />
      <span style={{ color: offline ? C.warning : C.muted, fontSize: 12, fontWeight: 700 }}>
        {offline ? `Offline · last known balance · updated ${when}` : `Updated ${when}`}
      </span>
    </div>
  );
}

/* ---------- Account sheet helpers ---------- */
function MenuRow({ icon, title, sub, onClick, last, testid }) {
  return (
    <div className="aib-press" data-testid={testid} onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 4px", borderBottom: last ? "none" : "0.5px solid #1F1F1F" }}>
      <div style={{ width: 40, height: 40, borderRadius: 20, background: "rgba(142,36,170,0.15)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ color: "#fff", fontSize: 16, fontWeight: 800 }}>{title}</div>
        {sub && <div style={{ color: C.muted, fontSize: 13, marginTop: 2 }}>{sub}</div>}
      </div>
      <ChevronRight size={20} color={C.muted} />
    </div>
  );
}
const Lbl = ({ children }) => <div style={{ color: C.muted, fontSize: 13, marginTop: 14, marginBottom: 8, fontWeight: 700 }}>{children}</div>;
const sheetInp = { width: "100%", background: C.surfaceSecondary, color: "#fff", fontSize: 16, padding: 14, borderRadius: 12, fontWeight: 700, border: "none" };
const sheetPrimary = { background: C.brandPrimary, padding: 15, borderRadius: 999, textAlign: "center", marginTop: 18, color: "#fff", fontSize: 16, fontWeight: 800 };
const sheetCancel = { marginTop: 10, padding: 10, textAlign: "center", color: C.muted, fontSize: 15, fontWeight: 700 };
