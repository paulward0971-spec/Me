import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import StatusBar from "../aib/StatusBar";
import BottomNav from "../aib/BottomNav";
import { api, formatEuros } from "../aib/mock";
import { C } from "../aib/theme";
import { BankLogo } from "../aib/BankLogo";
import { Countdown } from "../aib/Countdown";
import { ChevronLeft } from "lucide-react";

export default function TransferHistory() {
  const nav = useNavigate();
  const [transfers, setTransfers] = useState([]);
  useEffect(() => {
    api.listTransfers().then((all) => {
      const list = (all || []).filter((t) => t.status !== "prepared").sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      setTransfers(list);
    });
  }, []);

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }}>
      <StatusBar />
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 16px 12px" }}>
        <div className="aib-press" data-testid="transfers-back-btn" onClick={() => nav(-1)} style={{ width: 38, height: 38, borderRadius: 19, background: C.surfaceSecondary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><ChevronLeft size={22} color="#fff" /></div>
        <div>
          <div style={{ color: "#fff", fontSize: 26, fontWeight: 900 }}>Sent transfers</div>
          <div style={{ color: C.muted, fontSize: 13 }}>Your SEPA Standard Credit Transfers</div>
        </div>
      </div>
      <div className="aib-scroll" data-testid="transfers-list" style={{ flex: 1, padding: "0 16px 24px" }}>
        {transfers.length === 0 ? (
          <div style={{ background: "#111", borderRadius: 16, padding: 26, textAlign: "center", marginTop: 12 }}>
            <div style={{ color: "#fff", fontSize: 16, fontWeight: 900 }}>No transfers yet</div>
            <div style={{ color: C.muted, fontSize: 13, marginTop: 8, lineHeight: "18px" }}>Money you send will appear here with its reference and live arrival time.</div>
            <div className="aib-btn" onClick={() => nav("/transfer/new")} style={{ display: "inline-block", marginTop: 16, background: C.brandPrimary, padding: "12px 22px", borderRadius: 999, color: "#fff", fontWeight: 800 }}>Send money</div>
          </div>
        ) : transfers.map((t) => {
          const delivered = Date.now() > new Date(t.created_at).getTime() + 24 * 3600 * 1000;
          return (
            <div key={t.id} className="aib-press" data-testid="transfer-item" onClick={() => nav(`/transfer/success/${t.id}`)} style={{ background: "#111", borderRadius: 16, padding: 16, marginTop: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <BankLogo slug={t.bank_slug || "aib"} size={42} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ color: "#fff", fontSize: 16, fontWeight: 800, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.recipient_name}</div>
                  <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>{t.bank_name} • Ref {t.reference || t.note}</div>
                </div>
                <div style={{ color: "#fff", fontSize: 16, fontWeight: 900 }}>{formatEuros(-Math.abs(t.amount_cents))}</div>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 12, paddingTop: 12, borderTop: `0.5px solid ${C.border}` }}>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 6, background: delivered ? "rgba(76,175,80,0.15)" : "rgba(100,181,246,0.14)", color: delivered ? C.success : C.info, fontSize: 12, fontWeight: 800, padding: "5px 10px", borderRadius: 999 }}>
                  <span style={{ width: 7, height: 7, borderRadius: 4, background: delivered ? C.success : C.info }} />
                  {delivered ? "Delivered" : "Processing"}
                </span>
                <span style={{ color: delivered ? C.success : C.info, fontSize: 13, fontWeight: 800 }}>
                  <Countdown createdAt={t.created_at} prefix="Arrives in " doneText="Funds delivered" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
      <BottomNav active="payments" />
    </div>
  );
}
