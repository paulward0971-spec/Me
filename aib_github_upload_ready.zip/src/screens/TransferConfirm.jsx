import React, { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { api, formatEuros, formatIban } from "../aib/mock";
import { enqueue } from "../offline/queue";
import { refreshPending } from "../offline/sync";
import { useConnection } from "../offline/connection";
import { C } from "../aib/theme";
import { BankLogo } from "../aib/BankLogo";

const CUR = { EUR: "\u20AC", GBP: "\u00A3", USD: "$" };

function VerifiedTick() {
  return (<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill={C.success} /><path d="M7 12.5 L10.5 16 L17 8.5" stroke="#0B1A0B" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>);
}

export default function TransferConfirm() {
  const nav = useNavigate();
  const { id } = useParams();
  const [sp] = useSearchParams();
  const recipientEmail = sp.get("re") || "";
  const conn = useConnection();
  const [t, setT] = useState(null);
  const [profile, setProfile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);

  useEffect(() => { api.getTransfer(id).then(setT); api.getProfile().then(setProfile); }, [id]);
  if (!t || !profile) return <div style={{ height: "100%", background: C.surface, display: "flex", alignItems: "center", justifyContent: "center", color: C.brandTertiary }}>Loading…</div>;

  const submit = async () => {
    setBusy(true); setErr(null);
    try {
      if (!navigator.onLine) {
        // OFFLINE: do NOT move money or claim success. Queue it for sync.
        await api.queueTransfer(t.id);
        await enqueue("transfer", { transferId: t.id }, "transfer-" + t.id);
        try { await refreshPending(); } catch (e) {}
        nav(`/transfer/success/${t.id}?re=${encodeURIComponent(recipientEmail)}`, { replace: true });
        return;
      }
      const done = await api.confirmTransfer(t.id);
      nav(`/transfer/success/${done.id}?re=${encodeURIComponent(recipientEmail)}`, { replace: true });
    } catch (e) { setErr(e.message || "Transfer failed"); setBusy(false); }
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: C.surface }}>
      <div style={{ padding: "38px 20px 8px" }}>
        <div className="aib-press" onClick={() => nav(-1)} style={{ color: C.brandLight, fontSize: 15, fontWeight: 700 }}>‹  Back</div>
        <div style={{ color: "#fff", fontSize: 32, fontWeight: 900, marginTop: 8 }}>Confirm payment</div>
        <div style={{ color: C.muted, fontSize: 14, marginTop: 4 }}>Check the details before you send</div>
      </div>
      <div className="aib-scroll" style={{ flex: 1, padding: "12px 20px 32px" }}>
        <div style={{ display: "flex", alignItems: "flex-start", gap: 10, background: "rgba(46,204,113,0.12)", border: "1px solid rgba(46,204,113,0.35)", padding: 14, borderRadius: 12, marginBottom: 16 }}>
          <VerifiedTick />
          <div style={{ flex: 1 }}>
            <div style={{ color: C.success, fontSize: 14, fontWeight: 900 }}>All details match</div>
            <div style={{ color: "#B7E1C1", fontSize: 12, marginTop: 2, lineHeight: "17px" }}>The IBAN and bank were verified. Please double-check the recipient name before sending.</div>
          </div>
        </div>

        <div style={{ padding: 20, background: C.brandDeep, borderRadius: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <BankLogo slug={t.bank_slug} size={44} style={{ border: "none" }} />
            <div style={{ flex: 1 }}>
              <div style={{ color: "#EAD6F0", fontSize: 12, fontWeight: 700 }}>You're sending to</div>
              <div style={{ color: "#fff", fontSize: 15, fontWeight: 800, marginTop: 2 }}>{t.bank_name}</div>
            </div>
          </div>
          <div style={{ color: "#fff", fontSize: 42, fontWeight: 900, marginTop: 14 }}>{formatEuros(t.amount_cents)}</div>
          {t.is_foreign && t.currency !== "EUR" && <div style={{ color: "#EAD6F0", fontSize: 14, fontWeight: 800, marginTop: 8 }}>≈ {CUR[t.currency] || ""}{((t.converted_amount_cents ?? t.amount_cents) / 100).toFixed(2)} {t.currency} · 1 EUR = {t.fx_rate} {t.currency}</div>}
        </div>

        <div style={{ background: C.surfaceSecondary, borderRadius: 16, padding: 4, marginTop: 20 }}>
          <Row label="To" value={t.recipient_name} />
          <Row label="IBAN" value={formatIban(t.iban)} />
          <Row label="BIC Code" value={t.bic} />
          <Row label="Bank" value={t.bank_name} slug={t.bank_slug} />
          <Row label="From" value={profile.account_holder} />
          <Row label="From IBAN" value={formatIban(profile.iban)} />
          <Row label="Reference" value={t.note || "\u2014"} />
          <Row label="Transaction ID" value={t.transaction_id} />
          <Row label="Type" value="SEPA Standard Credit Transfer" last />
        </div>

        <Notice title="Not an instant transfer" body="This payment is sent as a SEPA Standard Credit Transfer. It is not instant — please allow up to 24 hours for the funds to reach the recipient’s account." />
        <Notice warning title="Cancellation" body="After submission, the transfer cannot be cancelled while it is being processed. Please confirm that the recipient details are correct." />

        {!conn.online && (
          <div style={{ display: "flex", gap: 10, background: "rgba(255,183,77,0.10)", border: "1px solid rgba(255,183,77,0.30)", padding: 12, borderRadius: 14, marginTop: 16 }} data-testid="transfer-offline-notice">
            <div style={{ width: 28, height: 28, borderRadius: 14, background: "rgba(255,183,77,0.20)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color: "#fff", fontSize: 16, fontWeight: 900 }}>!</div>
            <div style={{ flex: 1 }}><div style={{ color: "#fff", fontSize: 13, fontWeight: 900, marginBottom: 3 }}>You're offline</div><div style={{ color: "#C8D7E4", fontSize: 12, lineHeight: "17px" }}>Your transfer will go through as normal and sync with AIB automatically. You'll get the usual receipt.</div></div>
          </div>
        )}

        {err && <div style={{ color: C.error, marginTop: 12 }}>{err}</div>}
        <div className="aib-btn" data-testid="transfer-submit-btn" onClick={!busy ? submit : undefined} style={{ marginTop: 24, background: C.brandPrimary, padding: 18, borderRadius: 999, textAlign: "center", color: "#fff", fontSize: 16, fontWeight: 900 }}>{busy ? "Sending…" : `Send ${formatEuros(t.amount_cents)}`}</div>
        <div className="aib-press" onClick={() => nav(-1)} style={{ marginTop: 12, padding: 12, textAlign: "center", color: C.muted, fontSize: 15, fontWeight: 700 }}>Cancel</div>
      </div>
    </div>
  );
}

function Row({ label, value, slug, last }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 14px", borderBottom: last ? "none" : `0.5px solid ${C.border}`, gap: 12 }}>
      <span style={{ color: C.muted, fontSize: 13 }}>{label}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 8, flex: 1, justifyContent: "flex-end" }}>
        {slug && <BankLogo slug={slug} size={22} />}
        <span style={{ color: "#fff", fontSize: 14, fontWeight: 800, textAlign: "right" }}>{value}</span>
      </div>
    </div>
  );
}
function Notice({ title, body, warning }) {
  return (
    <div style={{ display: "flex", gap: 10, background: warning ? "rgba(255,183,77,0.10)" : "rgba(100,181,246,0.10)", border: `1px solid ${warning ? "rgba(255,183,77,0.30)" : "rgba(100,181,246,0.28)"}`, padding: 12, borderRadius: 14, marginTop: 16 }}>
      <div style={{ width: 28, height: 28, borderRadius: 14, background: warning ? "rgba(255,183,77,0.20)" : "rgba(100,181,246,0.18)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color: "#fff", fontSize: 16, fontWeight: 900 }}>{warning ? "!" : "i"}</div>
      <div style={{ flex: 1 }}><div style={{ color: "#fff", fontSize: 13, fontWeight: 900, marginBottom: 3 }}>{title}</div><div style={{ color: "#C8D7E4", fontSize: 12, lineHeight: "17px" }}>{body}</div></div>
    </div>
  );
}
