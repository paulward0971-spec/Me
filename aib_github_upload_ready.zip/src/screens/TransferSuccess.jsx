import React, { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { api, formatEuros, formatIban } from "../aib/mock";
import { useConnection } from "../offline/connection";
import { C } from "../aib/theme";
import { BankLogo } from "../aib/BankLogo";
import { Countdown } from "../aib/Countdown";

export default function TransferSuccess() {
  const nav = useNavigate();
  const { id } = useParams();
  const [sp] = useSearchParams();
  const recipientEmail = sp.get("re") || "";
  const conn = useConnection();
  const [t, setT] = useState(null);
  const [profile, setProfile] = useState(null);

  // Re-read the transfer when connectivity changes so a queued transfer that
  // synced in the background updates from "Queued" to "Processing" here.
  useEffect(() => { api.getTransfer(id).then(setT); api.getProfile().then(setProfile); }, [id, conn.online, conn.status]);
  if (!t) return <div style={{ height: "100%", background: C.surface, display: "flex", alignItems: "center", justifyContent: "center", color: C.brandTertiary }}>Loading…</div>;

  const offlineMade = !!t.offline;
  const failed = t.status === "failed";
  const statusLabel = failed ? "Failed" : "Sent";
  const statusColor = failed ? C.error : C.success;
  const headTitle = failed ? "Transfer failed" : "Money sent";
  const headSub = failed
    ? "Something went wrong. Please try the transfer again."
    : offlineMade
      ? "Sent while offline — saved on your device and syncing with AIB now you're reconnecting."
      : "Your transfer has been sent as a SEPA Standard Credit Transfer.";

  const openRecipientEmail = () => {
    const to = String(recipientEmail || "").trim();
    if (!to) return;
    const senderName = profile?.account_holder || "Account holder";
    const amount = formatEuros(t.amount_cents);
    const subject = encodeURIComponent(`AIB Banking — Transfer receipt — ${amount}`);
    const body = encodeURIComponent(`${senderName} has sent you ${amount}.\n\nSender: ${senderName}\nSender IBAN: ${formatIban(profile?.iban || "")}\nRecipient: ${t.recipient_name}\nRecipient IBAN: ${formatIban(t.iban)}\nReference: ${t.reference || t.note || "—"}\nTransaction ID: ${t.transaction_id || t.id}\n\nPlease allow up to 24 hours for the funds to reach the recipient account.`);
    window.location.href = `mailto:${encodeURIComponent(to)}?subject=${subject}&body=${body}`;
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: C.surface, overflow: "hidden" }}>
      {/* Brand header */}
      <div style={{ background: "linear-gradient(135deg,#4A0E5C,#7B1FA2)", padding: "40px 16px 14px", borderBottomLeftRadius: 20, borderBottomRightRadius: 20, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <BankLogo slug="aib" size={42} />
          <div style={{ flex: 1 }}>
            <div style={{ color: "#fff", fontSize: 18, fontWeight: 900, letterSpacing: 0.2 }}>AIB Banking</div>
            <div style={{ color: "#EAD6F0", fontSize: 12, marginTop: 2 }}>Transfer receipt</div>
          </div>
        </div>
      </div>

      {/* Scrollable so the action buttons are always reachable; overscroll is disabled globally. */}
      <div className="aib-scroll" style={{ flex: 1, display: "flex", flexDirection: "column", padding: "10px 16px", paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 46px)", minHeight: 0 }}>
        <div style={{ display: "flex", justifyContent: "center", marginTop: 4 }}>
          <div className="aib-pop" style={{ width: 52, height: 52, borderRadius: 26, background: failed ? "rgba(255,82,82,0.15)" : "rgba(76,175,80,0.15)", display: "flex", alignItems: "center", justifyContent: "center", color: failed ? C.error : C.success, fontSize: 28, fontWeight: 900 }}>{failed ? "!" : "✓"}</div>
        </div>
        <div data-testid="transfer-success-title" style={{ color: "#fff", fontSize: 20, fontWeight: 900, textAlign: "center", marginTop: 8 }}>{headTitle}</div>
        <div style={{ color: C.muted, fontSize: 12.5, textAlign: "center", marginTop: 4 }}>{headSub}</div>
        {offlineMade && !failed && (
          <div style={{ display: "flex", justifyContent: "center", marginTop: 8 }}>
            <span data-testid="transfer-offline-chip" style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(255,183,77,0.14)", border: "1px solid rgba(255,183,77,0.3)", color: C.warning, fontSize: 12, fontWeight: 800, padding: "5px 12px", borderRadius: 999 }}>
              <span style={{ width: 7, height: 7, borderRadius: 4, background: C.warning }} /> Offline · will sync
            </span>
          </div>
        )}

        <div style={{ background: C.surfaceSecondary, borderRadius: 16, marginTop: 14, padding: 2 }}>
          <Row label="Transaction ID" value={t.transaction_id || t.id} />
          <Row label="Reference" value={t.reference || t.note || "—"} />
          <Row label="Amount" value={formatEuros(t.amount_cents)} />
          <Row label="To" value={t.recipient_name} />
          <Row label="Recipient IBAN" value={formatIban(t.iban)} />
          <Row label="BIC Code" value={t.bic} />
          <Row label="Bank" value={t.bank_name} slug={t.bank_slug} />
          <Row label="Type" value="SEPA Standard Credit Transfer" />
          <Row label="Status" value={statusLabel} valueColor={statusColor} />
          <Row label="Expected arrival" value={<Countdown createdAt={t.created_at} prefix="" doneText="Delivered" />} valueColor={statusColor} />
          <Row label="Within" value="Up to 24 hours" last />
        </div>

        <div style={{ display: "flex", gap: 9, background: offlineMade ? "rgba(255,183,77,0.10)" : "rgba(100,181,246,0.10)", border: `1px solid ${offlineMade ? "rgba(255,183,77,0.30)" : "rgba(100,181,246,0.28)"}`, padding: "10px 12px", borderRadius: 12, marginTop: 12 }}>
          <div style={{ width: 22, height: 22, borderRadius: 11, background: offlineMade ? "rgba(255,183,77,0.20)" : "rgba(100,181,246,0.18)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color: "#fff", fontSize: 13, fontWeight: 900 }}>{offlineMade ? "!" : "i"}</div>
          <div style={{ color: "#C8D7E4", fontSize: 12, lineHeight: "16px" }}>{offlineMade ? "You made this transfer offline — the details are saved on your device and sync with AIB automatically. Sent as a SEPA Standard Credit Transfer: not instant, allow up to 24 hours to arrive." : "Sent as a SEPA Standard Credit Transfer — not instant, please allow up to 24 hours to arrive."}</div>
        </div>

        {recipientEmail && (
          <div className="aib-btn" onClick={openRecipientEmail} style={{ marginTop: 10, background: C.surfaceSecondary, border: `1px solid ${C.brandPrimary}`, padding: 12, borderRadius: 12, textAlign: "center", color: "#fff", fontSize: 13.5, fontWeight: 800 }}>Email receipt to recipient</div>
        )}

        <div style={{ flex: 1, minHeight: 12 }} />

        <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
          <div className="aib-btn" onClick={() => nav("/home", { replace: true })} style={{ flex: 1, background: C.brandPrimary, padding: 15, borderRadius: 12, textAlign: "center", color: "#fff", fontSize: 15, fontWeight: 800 }}>Back to Dashboard</div>
          <div className="aib-btn" onClick={() => nav("/transfer/new", { replace: true })} style={{ flex: 1, background: C.surfaceSecondary, padding: 15, borderRadius: 12, textAlign: "center", color: "#fff", fontSize: 15, fontWeight: 800 }}>New Transfer</div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, valueColor, slug, last }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 12px", borderBottom: last ? "none" : `0.5px solid ${C.border}`, gap: 10 }}>
      <span style={{ color: C.muted, fontSize: 12 }}>{label}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 7, flex: 1, justifyContent: "flex-end" }}>
        {slug && <BankLogo slug={slug} size={20} />}
        <span style={{ color: valueColor || "#fff", fontSize: 13, fontWeight: 800, textAlign: "right", wordBreak: "break-word" }}>{value}</span>
      </div>
    </div>
  );
}
