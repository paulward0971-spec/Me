// AIB educational prototype — LOCAL-FIRST data layer.
//
// All banking data lives locally on the device. It is now persisted in
// IndexedDB (via Dexie) as the primary store, with a localStorage mirror kept
// only as a fast synchronous fallback for the very first paint / hydration.
// The public `api` surface and its (Promise-returning) shape are unchanged, so
// every existing screen keeps working exactly as before.
import Dexie from "dexie";
import { formatEuros, formatIban } from "./format";
export { formatEuros, formatIban };

const LEGACY_KEY = "aib_mock_db_v2"; // previous localStorage-only store
const MIRROR_KEY = "aib_state_mirror_v1"; // synchronous fallback mirror
const META_MIRROR_KEY = "aib_meta_mirror_v1";
const STATE_KEYS = ["profile", "transactions", "payees", "transfers", "budgets", "chats"];

// ---- Dexie (IndexedDB) ------------------------------------------------------
export const dxdb = new Dexie("aib_pwa");
dxdb.version(1).stores({
  state: "&key", // key -> value (profile / transactions / ...)
  meta: "&key", // freshness + version info
  queue: "&id, status, createdAt", // offline mutation queue
});

// ---- helpers ----------------------------------------------------------------
function now() { return new Date().toISOString(); }
function daysAgoAt(n, h, m) { const d = new Date(Date.now() - n * 86400000); d.setHours(h, m, 0, 0); return d.toISOString(); }
function rid(prefix = "") { return prefix + Math.random().toString(36).slice(2, 10); }
function txnId() { return "DW-" + Math.floor(100000000 + Math.random() * 899999999); }
function aibRef() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 7; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return "AIB-" + s;
}

export function initialsFor(name) {
  const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) { const w = parts[0]; return (w[0] + (w[w.length - 1] || "")).toUpperCase(); }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

// Irish bank code -> brand meta. Used by the (offline-capable) IBAN detection.
const IE_BANKS = {
  AIBK: { bank_name: "AIB", bic: "AIBKIE2D", slug: "aib" },
  BOFI: { bank_name: "Bank of Ireland", bic: "BOFIIE2D", slug: "boi" },
  IPBS: { bank_name: "Permanent TSB", bic: "IPBSIE2D", slug: "ptsb" },
  EBSI: { bank_name: "EBS", bic: "EBSIIE2D", slug: "ebs" },
  ULSB: { bank_name: "Ulster Bank", bic: "ULSBIE2D", slug: "ulster" },
  REVO: { bank_name: "Revolut Ireland", bic: "REVOIE23", slug: "revolut" },
  BOFA: { bank_name: "An Post Money", bic: "BOFAIE3X", slug: "anpost" },
  MONZ: { bank_name: "Monzo", bic: "MONZIE22", slug: "monzo" },
  BUNQ: { bank_name: "bunq", bic: "BUNQIE21", slug: "bunq" },
};

const FOREIGN = {
  GB: { bank_name: "UK Bank", bic: "NWBKGB2L", slug: null, currency: "GBP", fx_rate: 0.85, country_name: "United Kingdom" },
  DE: { bank_name: "N26 Bank", bic: "NTSBDEB1", slug: "n26", currency: "EUR", fx_rate: 1, country_name: "Germany" },
  FR: { bank_name: "French Bank", bic: "BNPAFRPP", slug: null, currency: "EUR", fx_rate: 1, country_name: "France" },
  ES: { bank_name: "Spanish Bank", bic: "BSCHESMM", slug: null, currency: "EUR", fx_rate: 1, country_name: "Spain" },
  US: { bank_name: "US Bank", bic: "CHASUS33", slug: null, currency: "USD", fx_rate: 1.08, country_name: "United States" },
};

function seed() {
  const profile = {
    display_name: "John",
    account_holder: "John Guilfoyle",
    account_label: "AIB BANK ACCOUNT-017",
    balance_cents: 0,
    available_cents: 0,
    monthly_spent_cents: 4231,
    card_holder: "John Guilfoyle",
    card_last4: "4412",
    card_expiry: "07/29",
    iban: "IE12AIBK93200170123456",
    bic: "AIBKIE2D",
    account_number: "17012345",
    sort_code: "93-20-01",
    email: "",
    needs_setup: false,
  };
  const transactions = [
    { id: "1", merchant: "Google Play", amount_cents: -749, status: "declined", category: "card", label: "Electronics", date: daysAgoAt(2, 23, 55), reference: "GOOGLE *PLAY" },
    { id: "2", merchant: "Google Play", amount_cents: -749, status: "declined", category: "card", label: "Electronics", date: daysAgoAt(3, 3, 8), reference: "GOOGLE *PLAY" },
    { id: "3", merchant: "Google Play", amount_cents: -749, status: "declined", category: "card", label: "Electronics", date: daysAgoAt(6, 3, 20), reference: "GOOGLE *PLAY" },
    { id: "4", merchant: "John Mcdonagh", amount_cents: -1832, status: "completed", category: "transfer", label: "Outgoing Transfer", date: daysAgoAt(8, 0, 48), reference: "Dinner split" },
    { id: "5", merchant: "John Mcdonagh", amount_cents: 1800, status: "completed", category: "transfer", label: "Incoming Transfer", date: daysAgoAt(8, 0, 47), reference: "Payback" },
    { id: "6", merchant: "John Mcdonagh", amount_cents: -1800, status: "completed", category: "transfer", label: "Outgoing Transfer", date: daysAgoAt(8, 0, 45), reference: "Loan" },
    { id: "7", merchant: "Tesco", amount_cents: -2410, status: "completed", category: "card", label: "Groceries", date: daysAgoAt(9, 17, 12), reference: "TESCO STORES" },
    { id: "8", merchant: "Salary", amount_cents: 245000, status: "completed", category: "transfer", label: "Incoming Transfer", date: daysAgoAt(11, 9, 0), reference: "ACME LTD" },
    { id: "9", merchant: "Spotify", amount_cents: -1099, status: "completed", category: "card", label: "Entertainment", date: daysAgoAt(12, 8, 30), reference: "SPOTIFY" },
  ];
  const payees = [
    { id: rid("p_"), name: "John", iban: "IE93REVO99033765769982", bank_name: "Revolut Ireland", bank_slug: "revolut", bic: "REVOIE23" },
    { id: rid("p_"), name: "John Mcdonagh", iban: "IE29AIBK84928392828209", bank_name: "AIB", bank_slug: "aib", bic: "AIBKIE2D" },
  ];
  // Standing orders — recurring scheduled payments shown on the Payments screen.
  const standingOrders = [
    { id: rid("so_"), payee_name: "Irish Life Health", iban: "IE64IPBS99065612345678", bank_name: "Permanent TSB", bank_slug: "ptsb", amount_cents: 8900, frequency: "Monthly", reference: "Health cover", next_date: daysAgoAt(-3, 9, 0), active: true },
    { id: rid("so_"), payee_name: "Electric Ireland", iban: "IE12BOFI90001710000024", bank_name: "Bank of Ireland", bank_slug: "boi", amount_cents: 14500, frequency: "Monthly", reference: "Electricity", next_date: daysAgoAt(-9, 9, 0), active: true },
    { id: rid("so_"), payee_name: "John Mcdonagh", iban: "IE29AIBK84928392828209", bank_name: "AIB", bank_slug: "aib", amount_cents: 5000, frequency: "Weekly", reference: "Rent share", next_date: daysAgoAt(-2, 9, 0), active: true },
  ];
  return { profile, transactions, payees, transfers: {}, budgets: [], chats: {}, standingOrders };
}

function normalize(obj) {
  const base = seed();
  const out = { ...base };
  for (const k of Object.keys(base)) if (obj[k] !== undefined) out[k] = obj[k];
  return out;
}

// ---- in-memory mirror (source for synchronous reads) ------------------------
let mem = null;
let metaState = { lastUpdated: null, lastSynced: null, source: "local", version: 1 };
let metaListeners = new Set();

function readMirror() {
  try {
    const raw = localStorage.getItem(MIRROR_KEY);
    if (raw) return normalize(JSON.parse(raw));
  } catch (e) {}
  try {
    const legacy = localStorage.getItem(LEGACY_KEY);
    if (legacy) return normalize(JSON.parse(legacy));
  } catch (e) {}
  return null;
}

function pickState(db) {
  const o = {};
  for (const k of STATE_KEYS) o[k] = db[k];
  return o;
}

function writeMirror() {
  if (!mem) return;
  try { localStorage.setItem(MIRROR_KEY, JSON.stringify(pickState(mem))); } catch (e) {}
  try { localStorage.setItem(META_MIRROR_KEY, JSON.stringify(metaState)); } catch (e) {}
}

let persistTimer = null;
async function persistNow() {
  if (!mem) return;
  try {
    const rows = STATE_KEYS.map((k) => ({ key: k, value: mem[k] }));
    await dxdb.state.bulkPut(rows);
    await dxdb.meta.put({ key: "freshness", value: metaState });
  } catch (e) { /* IndexedDB unavailable — mirror still holds the data */ }
}
function schedulePersist() {
  writeMirror();
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(() => { persistTimer = null; persistNow(); }, 200);
}

// The list of state keys we persist (kept in sync with seed()).
STATE_KEYS.push("standingOrders");

// ---- hydration (called once at app startup, before first render) ------------
export async function hydrate() {
  try {
    await dxdb.open();
    const rows = await dxdb.state.toArray();
    if (rows && rows.length) {
      const obj = {};
      rows.forEach((r) => { obj[r.key] = r.value; });
      mem = normalize(obj);
    } else {
      mem = readMirror() || seed();
      await persistNow();
    }
    const m = await dxdb.meta.get("freshness");
    if (m && m.value) metaState = { ...metaState, ...m.value };
  } catch (e) {
    mem = readMirror() || seed();
  }
  writeMirror();
  return mem;
}

function load() {
  if (!mem) mem = readMirror() || seed();
  return mem;
}
function save(db) {
  mem = db;
  metaState = { ...metaState, lastUpdated: Date.now(), source: "local" };
  emitMeta();
  schedulePersist();
}
function wait(v, ms = 180) { return new Promise((res) => setTimeout(() => res(v), ms)); }

// ---- freshness / meta -------------------------------------------------------
function emitMeta() { metaListeners.forEach((f) => { try { f(metaState); } catch (e) {} }); }
export function getFreshness() { return { ...metaState }; }
export function subscribeFreshness(fn) { metaListeners.add(fn); return () => metaListeners.delete(fn); }
export function markSynced() {
  metaState = { ...metaState, lastSynced: Date.now() };
  emitMeta();
  schedulePersist();
}

// ---- IBAN detection (fully offline-capable) --------------------------------
export function detectBank(ibanRaw) {
  const iban = String(ibanRaw || "").replace(/\s+/g, "").toUpperCase();
  const country = iban.slice(0, 2);
  if (country === "IE") {
    const code = iban.slice(4, 8);
    const meta = IE_BANKS[code];
    if (meta) return { ...meta, is_valid: iban.length >= 22, is_foreign: false, currency: "EUR", fx_rate: 1 };
    return { bank_name: "Irish Bank", bic: code + "IE2X", slug: null, is_valid: iban.length >= 22, is_foreign: false, currency: "EUR", fx_rate: 1 };
  }
  const f = FOREIGN[country];
  if (f) return { ...f, is_valid: iban.length >= 15, is_foreign: f.currency !== "EUR" };
  return { bank_name: "International Bank", bic: "", slug: null, is_valid: iban.length >= 15, is_foreign: false, currency: "EUR", fx_rate: 1 };
}

// Money-move finalisation, guarded so an offline-queued transfer that syncs
// (or a retried queue item) can never deduct the balance twice.
function _finalize(db, t) {
  if (t.settled) return;
  t.settled = true;
  t.status = "processing";
  t.email_sent = !!(t.receipt_email || db.profile.email);
  const out = Math.abs(t.amount_cents || 0);
  db.profile.balance_cents = (db.profile.balance_cents || 0) - out;
  db.profile.available_cents = (db.profile.available_cents || 0) - out;
  if (!db.payees.some((p) => p.iban === t.iban)) {
    db.payees.unshift({ id: rid("p_"), name: t.recipient_name, iban: t.iban, bank_name: t.bank_name, bank_slug: t.bank_slug, bic: t.bic });
  }
  db.transactions.unshift({ id: rid("tx_"), merchant: t.recipient_name, amount_cents: -Math.abs(t.amount_cents), status: "completed", category: "transfer", label: "Outgoing Transfer", date: now(), reference: t.reference || t.transaction_id });
}

export const api = {
  getProfile: () => wait(load().profile),
  updateProfile: (patch) => {
    const db = load();
    db.profile = { ...db.profile, ...patch };
    save(db);
    return wait(db.profile);
  },
  setupProfile: (data) => {
    const db = load();
    db.profile = { ...db.profile, display_name: data.display_name, account_holder: data.display_name, account_label: data.account_label || db.profile.account_label, needs_setup: false };
    save(db);
    return wait(db.profile);
  },
  listTransactions: () => wait(load().transactions),
  getTransaction: (id) => wait(load().transactions.find((t) => String(t.id) === String(id)) || load().transactions[0]),
  ibanLookup: (iban) => wait(detectBank(iban), 220),
  listPayees: () => wait(load().payees),
  deletePayee: (id) => {
    const db = load();
    db.payees = db.payees.filter((p) => p.id !== id);
    save(db);
    return wait({ ok: true });
  },
  // ---- Standing orders ----
  listStandingOrders: () => wait(load().standingOrders || []),
  createStandingOrder: (body) => {
    const db = load();
    const bank = detectBank(body.iban || "");
    const so = {
      id: rid("so_"),
      payee_name: body.payee_name,
      iban: (body.iban || "").replace(/\s+/g, "").toUpperCase(),
      bank_name: bank.bank_name,
      bank_slug: bank.slug,
      amount_cents: body.amount_cents,
      frequency: body.frequency || "Monthly",
      reference: body.reference || "Standing order",
      next_date: body.next_date || now(),
      active: true,
    };
    db.standingOrders = [so, ...(db.standingOrders || [])];
    save(db);
    return wait(so);
  },
  toggleStandingOrder: (id) => {
    const db = load();
    db.standingOrders = (db.standingOrders || []).map((s) => (s.id === id ? { ...s, active: !s.active } : s));
    save(db);
    return wait({ ok: true });
  },
  deleteStandingOrder: (id) => {
    const db = load();
    db.standingOrders = (db.standingOrders || []).filter((s) => s.id !== id);
    save(db);
    return wait({ ok: true });
  },
  verifyEmail: (email) => {
    const db = load();
    db.profile.email = email;
    save(db);
    return wait({ reference: rid("E").toUpperCase() });
  },
  prepareTransfer: (payload) => {
    const db = load();
    const bank = detectBank(payload.iban);
    const converted = Math.round((payload.amount_cents || 0) * (bank.fx_rate || 1));
    const reference = (payload.reference && payload.reference.trim()) ? payload.reference.trim() : aibRef();
    const transfer = {
      id: rid("t_"),
      transaction_id: txnId(),
      recipient_name: payload.recipient_name,
      iban: payload.iban,
      amount_cents: payload.amount_cents,
      reference: reference,
      note: reference,
      transfer_type: "SEPA Standard Credit Transfer",
      bic: (payload.bic || bank.bic || "").toUpperCase(),
      bank_name: bank.bank_name,
      bank_slug: bank.slug,
      is_foreign: bank.is_foreign,
      currency: bank.currency,
      fx_rate: bank.fx_rate,
      converted_amount_cents: converted,
      receipt_email: payload.receipt_email || "",
      created_at: now(),
      status: "prepared",
      settled: false,
      email_sent: false,
    };
    db.transfers[transfer.id] = transfer;
    save(db);
    return wait(transfer);
  },
  // ONLINE confirm — money moves immediately (server would be the source of truth).
  confirmTransfer: (transfer_id) => {
    const db = load();
    const t = db.transfers[transfer_id];
    if (!t) throw new Error("Transfer not found");
    _finalize(db, t);
    save(db);
    return wait({ id: t.id });
  },
  // OFFLINE — behave like the real bank app: record the payment locally (so the
  // balance, activity and receipt all match) and mark it as made offline. It is
  // still enqueued so it reconciles/syncs with AIB when the connection returns.
  queueTransfer: (transfer_id) => {
    const db = load();
    const t = db.transfers[transfer_id];
    if (!t) throw new Error("Transfer not found");
    t.offline = true;
    t.queued_at = now();
    _finalize(db, t);
    save(db);
    return wait({ id: t.id });
  },
  // Called by the sync engine once the connection returns.
  syncQueuedTransfer: (transfer_id) => {
    const db = load();
    const t = db.transfers[transfer_id];
    if (!t) return wait({ id: transfer_id, missing: true });
    _finalize(db, t);
    save(db);
    return wait({ id: t.id, status: t.status });
  },
  getTransfer: (id) => wait(load().transfers[id]),
  listTransfers: () => wait(Object.values(load().transfers || {})),
  setBalance: (balance_cents, available_cents) => {
    const db = load();
    db.profile.balance_cents = Number.isFinite(balance_cents) ? balance_cents : 0;
    db.profile.available_cents = Number.isFinite(available_cents) ? available_cents : db.profile.balance_cents;
    save(db);
    return wait(db.profile);
  },
  addDeposit: ({ amount_cents, branch }) => {
    const db = load();
    const amt = Math.abs(amount_cents || 0);
    db.profile.balance_cents = (db.profile.balance_cents || 0) + amt;
    db.profile.available_cents = (db.profile.available_cents || 0) + amt;
    const label = branch ? `AIB ${branch}` : "AIB Deposit";
    const txn = { id: rid("tx_"), merchant: label, amount_cents: amt, status: "completed", category: "transfer", label: "AIB Deposit", date: now(), reference: aibRef(), bank_slug: "aib" };
    db.transactions.unshift(txn);
    save(db);
    return wait({ profile: db.profile, transaction: txn });
  },
  deleteTransaction: (id) => {
    const db = load();
    db.transactions = db.transactions.filter((t) => String(t.id) !== String(id));
    save(db);
    return wait({ ok: true });
  },
  listBudgets: () => {
    const db = load();
    return wait(db.budgets.map((b) => {
      const spent = db.transactions.filter((t) => t.amount_cents < 0 && t.status !== "declined").reduce((a, t) => a + Math.abs(t.amount_cents), 0);
      const spent_cents = Math.min(spent, b.monthly_cap_cents);
      return { ...b, spent_cents, percent: Math.min(1, spent_cents / (b.monthly_cap_cents || 1)) };
    }));
  },
  createBudget: (body) => {
    const db = load();
    db.budgets.push({ id: rid("b_"), name: body.name, monthly_cap_cents: body.monthly_cap_cents, categories: body.categories || [] });
    save(db);
    return wait({ ok: true });
  },
  deleteBudget: (id) => {
    const db = load();
    db.budgets = db.budgets.filter((b) => b.id !== id);
    save(db);
    return wait({ ok: true });
  },
  // Chat history is persisted locally so past conversations are visible offline.
  chatMessage: (session_id, message) => {
    const db = load();
    const list = db.chats[session_id] || [];
    list.push({ role: "user", text: message, ts: now() });
    const reply = abiReply(message);
    list.push({ role: "assistant", text: reply, ts: now(), offline: true });
    db.chats[session_id] = list;
    save(db);
    return wait({ reply, messages: list }, 500);
  },
  getChat: (session_id) => wait(load().chats[session_id] || []),
  setChat: (session_id, messages) => {
    const db = load();
    db.chats[session_id] = messages;
    save(db);
    return wait(messages);
  },
  appendChat: (session_id, msg) => {
    const db = load();
    const list = db.chats[session_id] || [];
    list.push(msg);
    db.chats[session_id] = list;
    save(db);
    return wait(list);
  },
  clearChat: (session_id) => {
    const db = load();
    delete db.chats[session_id];
    save(db);
    return wait({ ok: true });
  },
  resetDemo: () => {
    try { localStorage.removeItem(LEGACY_KEY); localStorage.removeItem(MIRROR_KEY); localStorage.removeItem(META_MIRROR_KEY); } catch (e) {}
    try { dxdb.state.clear(); dxdb.meta.clear(); dxdb.queue.clear(); } catch (e) {}
    mem = seed();
    save(mem);
  },
};

// Local, clearly-labelled "offline help" replies — never presented as the real
// backend AI. Used only when there is no connection.
export function abiReply(msg) {
  const m = (msg || "").toLowerCase();
  if (m.includes("transfer") || m.includes("send money")) return "To send money, go to Payments \u2192 Pay someone new, enter the recipient's IBAN and amount, then review and confirm. Remember this is an educational prototype \u2013 no real money moves.";
  if (m.includes("balance")) return "You can see your live account balance on the Home screen under your account card.";
  if (m.includes("card") && m.includes("freeze")) return "Open the Cards tab and tap Freeze to instantly block your card. Tap Unfreeze to reactivate it.";
  if (m.includes("pin") || m.includes("pac")) return "Your Personal Access Code (PAC) unlocks the app. In this prototype any 6-digit code works.";
  if (m.includes("hello") || m.includes("hi") || m.includes("hey")) return "Hi! I'm Abi, your AIB digital assistant. Ask me about transfers, cards, budgets or your balance.";
  return "I'm Abi, your digital assistant for this AIB prototype. I can help with transfers, cards, budgets and account questions. What would you like to do?";
}
