import React, { useEffect, useState } from "react";
import { useConnection } from "./connection";

// A subtle, app-level connection/sync indicator plus the PWA "new version"
// prompt. Mounted once inside the phone screen (see App.js).
export default function AppStatus() {
  const conn = useConnection();
  const [visible, setVisible] = useState(false);
  const [updateReady, setUpdateReady] = useState(false);

  // Decide when the banner shows.
  useEffect(() => {
    if (conn.status === "offline" || conn.status === "syncing") { setVisible(true); return; }
    if (conn.status === "synced") {
      setVisible(true);
      const t = setTimeout(() => setVisible(false), 2200); // auto-hide after success
      return () => clearTimeout(t);
    }
    setVisible(false);
  }, [conn.status, conn.pending]);

  // PWA update available -> offer refresh.
  useEffect(() => {
    const onUpd = () => setUpdateReady(true);
    window.addEventListener("aib-sw-update", onUpd);
    return () => window.removeEventListener("aib-sw-update", onUpd);
  }, []);

  const refresh = () => {
    try {
      if (window.__aibSwWaiting) window.__aibSwWaiting.postMessage("SKIP_WAITING");
    } catch (e) {}
    setTimeout(() => window.location.reload(), 250);
  };

  let text = "";
  let dot = "#4CAF50";
  let bg = "rgba(20,20,22,0.96)";
  if (conn.status === "offline") { text = "Offline · Showing saved data"; dot = "#FFB74D"; }
  else if (conn.status === "syncing") { text = "Back online · Syncing…"; dot = "#64B5F6"; }
  else if (conn.status === "synced") { text = "Synced"; dot = "#4CAF50"; }

  return (
    <>
      {visible && (
        <div
          data-testid="offline-indicator"
          className="aib-fadein"
          style={{
            position: "absolute", top: "calc(env(safe-area-inset-top, 0px) + 8px)", left: "50%",
            transform: "translateX(-50%)", zIndex: 90, display: "flex", alignItems: "center", gap: 8,
            background: bg, border: "1px solid #2A2A2A", borderRadius: 999, padding: "7px 14px",
            boxShadow: "0 8px 24px rgba(0,0,0,0.45)", maxWidth: "92%",
          }}
        >
          <span style={{ width: 8, height: 8, borderRadius: 4, background: dot, boxShadow: `0 0 8px ${dot}`, flexShrink: 0 }} />
          <span style={{ color: "#fff", fontSize: 12.5, fontWeight: 700, whiteSpace: "nowrap" }}>{text}</span>
          {conn.status === "offline" && conn.pending > 0 && (
            <span data-testid="offline-pending-count" style={{ color: "#FFB74D", fontSize: 12, fontWeight: 800 }}>· {conn.pending} queued</span>
          )}
        </div>
      )}

      {updateReady && (
        <div
          data-testid="pwa-update-banner"
          className="aib-fadein"
          style={{
            position: "absolute", bottom: "calc(env(safe-area-inset-bottom, 0px) + 90px)", left: 16, right: 16,
            zIndex: 95, display: "flex", alignItems: "center", gap: 10,
            background: "rgba(20,20,22,0.98)", border: "1px solid #8E24AA", borderRadius: 14,
            padding: "12px 14px", boxShadow: "0 12px 30px rgba(0,0,0,0.5)",
          }}
        >
          <span style={{ color: "#fff", fontSize: 13.5, fontWeight: 700, flex: 1 }}>New version available</span>
          <div className="aib-btn" data-testid="pwa-update-refresh" onClick={refresh} style={{ background: "#8E24AA", color: "#fff", fontWeight: 800, fontSize: 13, padding: "8px 16px", borderRadius: 999 }}>Refresh</div>
        </div>
      )}
    </>
  );
}
