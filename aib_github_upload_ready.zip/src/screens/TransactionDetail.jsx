import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, formatEuros } from "../aib/mock";
import { C } from "../aib/theme";

function BackChev() { return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M15 5 L8 12 L15 19" stroke="#fff" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>); }
function InfoDot() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke={C.brandTertiary} strokeWidth={1.6} fill="none" /><circle cx="12" cy="8" r="1" fill={C.brandTertiary} /><path d="M12 11 V17" stroke={C.brandTertiary} strokeWidth={1.6} strokeLinecap="round" /></svg>); }

export default function TransactionDetail() {
  const nav = useNavigate();
  const { id } = useParams();
  const [t, setT] = useState(null);
  const [profile, setProfile] = useState(null);
  useEffect(() => { api.getTransaction(id).then(setT); api.getProfile().then(setProfile); }, [id]);
  if (!t || !profile) return <div style={{ height: "100%", background: "#000", display: "flex", alignItems: "center", justifyContent: "center", color: C.brandTertiary }}>Loading…</div>;

  const d = new Date(t.date);
  const timeStr = d.toLocaleTimeString("en-IE", { hour: "2-digit", minute: "2-digit", hour12: false });
  const dateStr = d.toLocaleDateString("en-IE", { day: "2-digit", month: "long", year: "numeric" });
  const creditValueDate = new Date(d.getTime() - 86400000).toLocaleDateString("en-IE", { day: "2-digit", month: "long", year: "numeric" });
  const initials = (t.merchant || "?").split(/\s+/).map((s) => s[0]).slice(0, 2).join("").toUpperCase();
  const isApp = (t.merchant || "").toLowerCase().includes("google play");
  const isCredit = t.amount_cents > 0;
  const isDeclined = t.status === "declined";
  const paymentType = t.category === "transfer" ? "SEPA Standard Credit Transfer" : "Card payment";
  const txnType = t.category === "transfer" ? "Transfer" : isCredit ? "Credit" : "Debit";

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000", paddingTop: 38 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 8px" }}>
        <div className="aib-press" onClick={() => nav(-1)} style={{ width: 40, height: 40, borderRadius: 20, background: "#1A1A1A", display: "flex", alignItems: "center", justifyContent: "center" }}><BackChev /></div>
        <div style={{ color: "#fff", fontSize: 18, fontWeight: 800, flex: 1, textAlign: "center" }}>Transaction details</div>
        <div style={{ width: 40 }} />
      </div>
      <div className="aib-scroll" style={{ flex: 1, padding: "16px 16px 40px" }}>
        <div style={{ background: "#161616", borderRadius: 18, padding: 20, display: "flex", flexDirection: "column", alignItems: "center", marginTop: 24, position: "relative" }}>
          <div style={{ width: 68, height: 68, borderRadius: 16, background: isApp ? "#fff" : C.brandDeep, display: "flex", alignItems: "center", justifyContent: "center", position: "absolute", top: -34, color: "#fff", fontSize: 22, fontWeight: 900, overflow: "hidden" }}>{isApp ? <img src="/aib/google-play.png" alt="Google Play" style={{ width: 50, height: 50, objectFit: "contain" }} /> : initials}</div>
          <div style={{ color: "#fff", fontSize: 24, fontWeight: 800, marginTop: 40 }}>{t.merchant}</div>
          <div style={{ color: C.muted, fontSize: 15, marginTop: 8 }}>{timeStr} • {dateStr}</div>
          <div style={{ color: isCredit ? C.success : "#fff", fontSize: 40, fontWeight: 900, marginTop: 8, textDecoration: isDeclined ? "line-through" : "none", opacity: isDeclined ? 0.7 : 1 }}>{formatEuros(t.amount_cents)}</div>
          {isDeclined && <div style={{ color: C.error, marginTop: 4, fontWeight: 800 }}>Declined</div>}
        </div>

        <div style={{ color: "#fff", fontSize: 22, fontWeight: 900, marginTop: 24, marginBottom: 12 }}>Transaction details</div>
        <div style={{ background: "#111", borderRadius: 16, padding: "0 16px" }}>
          <Row label="Account" value={profile.account_number || "17012345"} />
          <Row label="Currency" value="EUR" />
          <RowStacked label="Reference number" value={t.reference || t.id} />
          <Row label="AIB Payment Fee" value="€0.00" valueColor={C.brandTertiary} withInfo />
          <Row label="Transaction type" value={txnType} />
          <Row label="Payment type" value={paymentType} />
          <Row label="Status" value={isDeclined ? "Declined" : "Completed"} valueColor={isDeclined ? C.error : "#fff"} />
          <Row label="Transaction date" value={dateStr} />
          <Row label="Credit value date" value={creditValueDate} last />
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, valueColor, withInfo, last }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 0", borderBottom: last ? "none" : "0.5px solid #1F1F1F", gap: 12 }}>
      <span style={{ color: C.muted, fontSize: 15 }}>{label}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 6, justifyContent: "flex-end" }}>
        <span style={{ color: valueColor || "#fff", fontSize: 17, fontWeight: 800, textAlign: "right" }}>{value}</span>
        {withInfo && <InfoDot />}
      </div>
    </div>
  );
}
function RowStacked({ label, value, last }) {
  return (
    <div style={{ padding: "14px 0", borderBottom: last ? "none" : "0.5px solid #1F1F1F" }}>
      <div style={{ color: C.muted, fontSize: 15 }}>{label}</div>
      <div style={{ color: "#fff", fontSize: 18, fontWeight: 900, marginTop: 6 }}>{value}</div>
    </div>
  );
}
