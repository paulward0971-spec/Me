import React from "react";

// AIB-style ark/bird emblem on a purple gradient tile (vector, from prototype).
export function AibLogo({ size = 120, showText = true, radius = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 200 200">
      <defs>
        <linearGradient id="aibBg" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#5B1470" />
          <stop offset="1" stopColor="#A036BE" />
        </linearGradient>
      </defs>
      <rect x="0" y="0" width="200" height="200" rx={radius * (200 / size)} fill="url(#aibBg)" />
      <path d="M 40 105 C 40 100, 46 96, 54 96 L 146 96 C 154 96, 160 100, 160 105 L 160 110 C 160 132, 138 148, 100 148 C 62 148, 40 132, 40 110 Z" fill="#FFFFFF" />
      <path d="M 50 108 C 52 106, 58 105, 64 105 L 136 105 C 142 105, 148 106, 150 108 L 150 111 C 150 128, 132 140, 100 140 C 68 140, 50 128, 50 111 Z" fill="url(#aibBg)" />
      <path d="M 34 108 C 30 96, 34 86, 44 86 L 44 96 C 40 96, 38 100, 38 104 Z" fill="#FFFFFF" />
      <path d="M 166 108 C 170 96, 166 86, 156 86 L 156 96 C 160 96, 162 100, 162 104 Z" fill="#FFFFFF" />
      <rect x="97" y="52" width="6" height="50" fill="#FFFFFF" />
      <rect x="76" y="78" width="48" height="6" fill="#FFFFFF" />
      <path d="M 66 62 C 66 52, 78 46, 96 46 L 122 46 C 132 46, 138 50, 138 58 C 138 66, 132 70, 122 70 L 78 70 C 70 70, 66 66, 66 62 Z" fill="#FFFFFF" />
      <ellipse cx="132" cy="52" rx="10" ry="9" fill="#FFFFFF" />
      <path d="M 140 52 L 148 50 L 144 57 Z" fill="#FFFFFF" />
      <circle cx="134" cy="50" r="1.6" fill="#5B1470" />
      <path d="M 60 58 L 68 54 L 68 66 Z" fill="#FFFFFF" />
      {showText && (
        <text x="100" y="180" fontSize="30" fontWeight="900" fill="#FFFFFF" textAnchor="middle" fontFamily="Inter, Helvetica, sans-serif" letterSpacing="1">AIB</text>
      )}
    </svg>
  );
}
