import React from "react";

// Status bar intentionally shows NO time / battery / signal indicators.
// It is just a small blank spacer so content clears the dynamic island.
export default function StatusBar() {
  return <div style={{ height: "calc(env(safe-area-inset-top, 0px) + 30px)", flexShrink: 0 }} />;
}
