// Durable offline mutation queue backed by IndexedDB (Dexie `queue` table).
// Nothing here ever silently drops an action: items stay until they succeed.
import { dxdb } from "../aib/mock";

function genId(type) {
  return `${type}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

// enqueue an action. Pass a stable `clientId` to guarantee de-duplication —
// enqueuing the same clientId twice returns the existing item.
export async function enqueue(type, payload, clientId) {
  const id = clientId || genId(type);
  try {
    const existing = await dxdb.queue.get(id);
    if (existing) return existing;
    const item = {
      id,
      type,
      payload,
      status: "pending", // pending | processing | failed
      attempts: 0,
      nextAttemptAt: Date.now(),
      error: null,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    await dxdb.queue.put(item);
    return item;
  } catch (e) {
    return null;
  }
}

export async function listQueue() {
  try { return await dxdb.queue.orderBy("createdAt").toArray(); } catch (e) { return []; }
}

export async function pendingCount() {
  try { return await dxdb.queue.where("status").anyOf("pending", "failed", "processing").count(); } catch (e) { return 0; }
}

export async function updateItem(id, patch) {
  try {
    const cur = await dxdb.queue.get(id);
    if (!cur) return;
    await dxdb.queue.put({ ...cur, ...patch, updatedAt: Date.now() });
  } catch (e) {}
}

export async function removeItem(id) {
  try { await dxdb.queue.delete(id); } catch (e) {}
}

export async function clearQueue() {
  try { await dxdb.queue.clear(); } catch (e) {}
}
