import "./App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import PhoneFrame from "./aib/PhoneFrame";
import Splash from "./screens/Splash";
import Passcode from "./screens/Passcode";
import Home from "./screens/Home";
import Insights from "./screens/Insights";
import Payments from "./screens/Payments";
import Cards from "./screens/Cards";
import Products from "./screens/Products";
import TransferNew from "./screens/TransferNew";
import TransferConfirm from "./screens/TransferConfirm";
import TransferSuccess from "./screens/TransferSuccess";
import TransactionDetail from "./screens/TransactionDetail";
import Transactions from "./screens/Transactions";
import TransferHistory from "./screens/TransferHistory";
import Settings from "./screens/Settings";
import Help from "./screens/Help";
import Chat from "./screens/Chat";
import StandingOrders from "./screens/StandingOrders";
import AppStatus from "./offline/AppStatus";
import Login from "./screens/Login";
import { authApi } from "./auth";
import { useEffect, useState } from "react";

function PrivateApp() {
  const [status, setStatus] = useState("checking");

  useEffect(() => {
    let mounted = true;
    authApi.session()
      .then((data) => mounted && setStatus(data.authenticated ? "authenticated" : "signed-out"))
      .catch(() => mounted && setStatus("signed-out"));
    return () => { mounted = false; };
  }, []);

  if (status === "checking") {
    return <div className="private-loading" aria-label="Checking private access"><div className="private-spinner" /></div>;
  }
  if (status === "signed-out") {
    return <Login onAuthenticated={() => setStatus("authenticated")} />;
  }

  return (
    <div className="App">
      <BrowserRouter>
        <PhoneFrame>
          <AppStatus />
          <Routes>
            <Route path="/" element={<Splash />} />
            <Route path="/passcode" element={<Passcode />} />
            <Route path="/home" element={<Home />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="/payments" element={<Payments />} />
            <Route path="/cards" element={<Cards />} />
            <Route path="/products" element={<Products />} />
            <Route path="/transfer/new" element={<TransferNew />} />
            <Route path="/transfer/confirm/:id" element={<TransferConfirm />} />
            <Route path="/transfer/success/:id" element={<TransferSuccess />} />
            <Route path="/transaction/:id" element={<TransactionDetail />} />
            <Route path="/transactions" element={<Transactions />} />
            <Route path="/transfers" element={<TransferHistory />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/help" element={<Help />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/standing-orders" element={<StandingOrders />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </PhoneFrame>
      </BrowserRouter>
    </div>
  );
}

function App() {
  return <PrivateApp />;
}

export default App;
