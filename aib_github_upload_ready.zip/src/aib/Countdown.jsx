import React, { useEffect, useState } from "react";

// A SEPA Standard Credit Transfer settles within one business day.
// We model arrival as submission time + 24 hours and count down to it live.
export function arrivalTime(createdAt) {
  return new Date(new Date(createdAt).getTime() + 24 * 3600 * 1000);
}

export function useCountdown(target) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(iv);
  }, []);
  return new Date(target).getTime() - now;
}

export function formatRemaining(ms) {
  if (ms <= 0) return "delivered";
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  if (h > 0) return `~${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function Countdown({ createdAt, prefix = "arrives in ", doneText = "Funds delivered", style }) {
  const ms = useCountdown(arrivalTime(createdAt));
  const done = ms <= 0;
  return <span style={style}>{done ? doneText : prefix + formatRemaining(ms)}</span>;
}
