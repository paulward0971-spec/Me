import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { C } from "../aib/theme";

const PAC_LENGTH = 5;
const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", null, "0", "del"];

function BackChevron() {
  return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M15 5 L8 12 L15 19" stroke="#E1BEE7" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>);
}
function DelIcon() {
  return (<svg width="30" height="22" viewBox="0 0 32 22" fill="none"><path d="M11 1 L2 11 L11 21 L30 21 L30 1 Z" stroke="#8E8E93" strokeWidth={1.8} strokeLinejoin="round" fill="none" /><path d="M16 7 L24 15 M24 7 L16 15" stroke="#8E8E93" strokeWidth={1.8} strokeLinecap="round" /></svg>);
}

export default function Passcode() {
  const nav = useNavigate();
  const [pin, setPin] = useState("");
  const press = (v) => {
    if (v === "del") { setPin((p) => p.slice(0, -1)); return; }
    if (pin.length >= PAC_LENGTH) return;
    const next = pin + v;
    setPin(next);
    if (next.length === PAC_LENGTH) setTimeout(() => nav("/home"), 220);
  };
  return (
    <div style={{ width: "100%", height: "100%", background: "#000", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "16px 16px 28px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 22 }}>
        <div className="aib-press" onClick={() => nav("/passcode")} style={{ width: 40, height: 40, borderRadius: 20, background: "#1A1A1A", display: "flex", alignItems: "center", justifyContent: "center" }}><BackChevron /></div>
        <div style={{ color: "#fff", fontSize: 16, fontWeight: 800, flex: 1, textAlign: "center" }}>Personal Access Code (PAC)</div>
        <div style={{ width: 40 }} />
      </div>

      <div style={{ display: "flex", justifyContent: "center", marginTop: 30 }}>
        <div style={{ display: "flex", gap: 22 }}>
          {Array.from({ length: PAC_LENGTH }).map((_, i) => (
            <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: i < pin.length ? C.brandPrimary : "#3D3D3D", boxShadow: i < pin.length ? "0 0 10px rgba(142,36,170,0.7)" : "none", transition: "background 0.15s, box-shadow 0.15s" }} />
          ))}
        </div>
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
        {KEYS.map((k, i) => (
          <div key={i} style={{ width: "33.33%", height: 84, display: "flex", alignItems: "center", justifyContent: "center" }}>
            {k === null ? <div /> : k === "del" ? (
              <div className="aib-press" onClick={() => press("del")} style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}><DelIcon /></div>
            ) : (
              <div className="aib-press" onClick={() => press(k)} style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 32, fontWeight: 500 }}>{k}</div>
            )}
          </div>
        ))}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", padding: "0 8px 12px" }}>
        <div className="aib-press" style={{ color: "#E1BEE7", fontSize: 20, fontWeight: 800, lineHeight: "26px" }}>Forgot your Personal<br />Access Code?</div>
      </div>
    </div>
  );
}
