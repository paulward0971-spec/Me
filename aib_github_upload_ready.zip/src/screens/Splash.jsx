import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Splash() {
  const nav = useNavigate();
  const [fade, setFade] = useState(false);
  useEffect(() => {
    const t1 = setTimeout(() => setFade(true), 2200);
    const t2 = setTimeout(() => nav("/passcode"), 2700);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [nav]);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: "#6E0E85", transition: "opacity 0.5s ease", opacity: fade ? 0 : 1 }}>
      {/* Exact splash artwork (logo + purple background) — kept static so the AIB mark holds still. */}
      <img src="/aib/splash-user.png" alt="AIB" draggable={false} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center" }} />

      {/* Only the bottom swoosh, overlaid exactly on top of itself, bobbing up and down subtly. */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: "40%", overflow: "hidden" }}>
        <img className="aib-swoosh-bob" src="/aib/splash-user.png" alt="" draggable={false} style={{ position: "absolute", left: 0, bottom: 0, width: "100%", height: "250%", objectFit: "cover", objectPosition: "center" }} />
      </div>
    </div>
  );
}
