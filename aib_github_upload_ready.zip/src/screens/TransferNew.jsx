import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, formatIban } from "../aib/mock";
import { useConnection } from "../offline/connection";
import { C } from "../aib/theme";
import { BankLogo } from "../aib/BankLogo";

const CUR = { EUR: "\u20AC", GBP: "\u00A3", USD: "$", CHF: "CHF ", USDC: "$" };

export default function TransferNew() {
  const nav = useNavigate();
  const conn = useConnection();
  const [name, setName] = useState("");
  const [iban, setIban] = useState("");
  const [amount, setAmount] = useState("");
  const [ref, setRef] = useState("");
  const [bic, setBic] = useState("");
  const [bicTouched, setBicTouched] = useState(false);
  const [receiptEmail, setReceiptEmail] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [bank, setBank] = useState(null);
  const [checking, setChecking] = useState(false);
  const [busy, setBusy] = useState(false);
  const [payees, setPayees] = useState([]);
  const [err, setErr] = useState(null);

  useEffect(() => { api.listPayees().then(setPayees); api.getProfile().then((p) => { if (p.email) setReceiptEmail(p.email); }); }, []);
  const cleanedIban = useMemo(() => iban.replace(/\s+/g, "").toUpperCase(), [iban]);

  useEffect(() => {
    if (cleanedIban.length < 6) { setBank(null); return; }
    setChecking(true);
    const t = setTimeout(async () => {
      try { setBank(await api.ibanLookup(cleanedIban)); } catch { setBank(null); } finally { setChecking(false); }
    }, 250);
    return () => clearTimeout(t);
  }, [cleanedIban]);

  useEffect(() => { if (bank?.bic && !bicTouched) setBic(bank.bic); }, [bank, bicTouched]);

  const canContinue = name.trim().length > 1 && cleanedIban.length >= 15 && Number(amount) > 0;

  const onContinue = async () => {
    setErr(null); setBusy(true);
    try {
      const t = await api.prepareTransfer({ recipient_name: name.trim(), iban: cleanedIban, amount_cents: Math.round(Number(amount) * 100), reference: ref || undefined, bic: bic.trim() ? bic.trim().toUpperCase() : undefined, receipt_email: receiptEmail.includes("@") ? receiptEmail.trim() : undefined });
      nav(`/transfer/confirm/${t.id}?re=${encodeURIComponent(recipientEmail.trim())}`);
    } catch (e) { setErr(e.message || "Could not prepare transfer"); } finally { setBusy(false); }
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: C.surface }}>
      <div style={{ padding: "38px 20px 8px" }}>
        <div className="aib-press" onClick={() => nav(-1)} style={{ color: C.brandLight, fontSize: 15, fontWeight: 700 }}>‹  Back</div>
        <div style={{ color: "#fff", fontSize: 32, fontWeight: 900, marginTop: 8 }}>Send money</div>
        <div style={{ color: C.muted, fontSize: 14, marginTop: 4 }}>SEPA Standard Credit Transfer · not instant, arrives within 24 hours</div>
      </div>
      <div className="aib-scroll" style={{ flex: 1, padding: "12px 20px 40px" }}>
        {payees.length > 0 && (
          <div style={{ marginBottom: 8 }}>
            <div style={{ color: C.muted, fontSize: 13, fontWeight: 700, marginBottom: 10 }}>Recent payees</div>
            <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4 }}>
              {payees.map((p) => (
                <div key={p.id} className="aib-press" onClick={() => { setName(p.name); setIban(p.iban); }} style={{ width: 110, flexShrink: 0, background: C.surfaceSecondary, borderRadius: 14, padding: 12, display: "flex", flexDirection: "column", alignItems: "center" }}>
                  <div style={{ position: "relative", width: 44, height: 44, marginBottom: 8 }}>
                    <div style={{ width: 44, height: 44, borderRadius: 22, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 900, fontSize: 14 }}>{p.name.split(" ").map((s) => s[0]).slice(0, 2).join("").toUpperCase()}</div>
                    {p.bank_slug && <div style={{ position: "absolute", right: -6, bottom: -4, background: C.surfaceSecondary, borderRadius: 12, padding: 1 }}><BankLogo slug={p.bank_slug} size={22} /></div>}
                  </div>
                  <div style={{ color: "#fff", fontSize: 13, fontWeight: 800, maxWidth: "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</div>
                  <div style={{ color: C.muted, fontSize: 11, marginTop: 2 }}>{p.bank_name}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        <Lbl>Recipient name</Lbl>
        <input style={inp} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. John Carthy" />
        <Lbl>IBAN</Lbl>
        <input style={inp} value={formatIban(iban)} onChange={(e) => setIban(e.target.value.replace(/\s+/g, ""))} placeholder="IE29 AIBK 8492 8392 8282 09" />
        {cleanedIban.length >= 6 && (
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 8, background: C.surfaceSecondary, padding: 12, borderRadius: 10 }}>
            {checking ? <span style={{ color: C.brandTertiary, fontSize: 13 }}>Detecting bank…</span> : (<>
              <BankLogo slug={bank?.slug} size={36} />
              <div style={{ flex: 1 }}>
                <div style={{ color: "#fff", fontSize: 14, fontWeight: 800 }}>{bank?.bank_name || "Detecting bank…"}</div>
                {bank?.bic && <div style={{ color: C.muted, fontSize: 12, fontWeight: 700, marginTop: 2 }}>{bank.bic}</div>}
                {bank?.is_foreign && <div style={{ color: C.brandTertiary, fontSize: 12, fontWeight: 800, marginTop: 3 }}>Foreign bank · sends in {bank?.currency}</div>}
                {!conn.online && bank && <div data-testid="iban-offline-note" style={{ color: C.warning, fontSize: 11, fontWeight: 800, marginTop: 3 }}>Detected offline from the IBAN</div>}
              </div>
            </>)}
          </div>
        )}
        <Lbl>BIC / SWIFT</Lbl>
        <input style={inp} value={bic} onChange={(e) => { setBicTouched(true); setBic(e.target.value.toUpperCase()); }} placeholder="BIC / SWIFT" maxLength={11} />
        <Lbl>Amount (EUR)</Lbl>
        <input style={inp} value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" inputMode="decimal" />
        {bank?.is_foreign && bank?.currency !== "EUR" && Number(amount) > 0 && (
          <div style={{ marginTop: 14, background: C.surfaceSecondary, borderRadius: 12, padding: 14, borderLeft: `3px solid ${C.brandTertiary}` }}>
            <div style={{ color: C.muted, fontSize: 11, fontWeight: 800, letterSpacing: 0.5, textTransform: "uppercase" }}>Currency conversion</div>
            <div style={{ color: "#fff", fontSize: 18, fontWeight: 900, marginTop: 6 }}>Recipient gets ≈ {CUR[bank.currency] || ""}{(Number(amount) * (bank?.fx_rate || 1)).toFixed(2)} {bank.currency}</div>
            <div style={{ color: C.muted, fontSize: 12, marginTop: 4 }}>You send €{Number(amount).toFixed(2)} · 1 EUR = {bank?.fx_rate} {bank.currency}</div>
          </div>
        )}
        <Lbl>Reference (optional)</Lbl>
        <input style={inp} value={ref} onChange={(e) => setRef(e.target.value)} placeholder="e.g. Rent September" maxLength={35} />
        <Lbl>Email receipt to (optional)</Lbl>
        <input style={inp} value={receiptEmail} onChange={(e) => setReceiptEmail(e.target.value)} placeholder="you@example.com" />
        <div style={hint}>If your email is linked in Settings, it is used automatically for your receipt.</div>
        <Lbl>Recipient email (optional)</Lbl>
        <input style={inp} value={recipientEmail} onChange={(e) => setRecipientEmail(e.target.value)} placeholder="recipient@example.com" />
        <div style={hint}>After the transfer, you can email the recipient a copy of the receipt.</div>
        {err && <div style={{ color: C.error, marginTop: 12 }}>{err}</div>}
        <div className="aib-btn" onClick={canContinue && !busy ? onContinue : undefined} style={{ marginTop: 30, background: C.brandPrimary, padding: 16, borderRadius: 999, textAlign: "center", color: "#fff", fontSize: 16, fontWeight: 800, opacity: canContinue ? 1 : 0.4 }}>{busy ? "Preparing…" : "Continue"}</div>
      </div>
    </div>
  );
}

const Lbl = ({ children }) => <div style={{ color: C.muted, fontSize: 13, marginTop: 20, marginBottom: 8, fontWeight: 700 }}>{children}</div>;
const inp = { width: "100%", background: C.surfaceSecondary, color: "#fff", fontSize: 16, padding: 14, borderRadius: 12, fontWeight: 600, border: "none" };
const hint = { color: C.muted, fontSize: 11, marginTop: 8, lineHeight: "16px" };
