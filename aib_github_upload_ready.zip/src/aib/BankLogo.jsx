import React from "react";
import { C } from "./theme";

const HAS_OWN_BACKGROUND = {
  aib: true, boi: true, ptsb: true, ebs: true, ulster: true,
  anpost: true, monzo: true, bunq: true, n26: false, revolut: false,
};

function GenericBank({ size }) {
  const s = size * 0.6;
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
      <path d="M3 10 L12 4 L21 10 L21 11 L3 11 Z" fill={C.muted} />
      <rect x="5" y="12" width="2" height="7" fill={C.muted} />
      <rect x="9" y="12" width="2" height="7" fill={C.muted} />
      <rect x="13" y="12" width="2" height="7" fill={C.muted} />
      <rect x="17" y="12" width="2" height="7" fill={C.muted} />
      <rect x="3" y="20" width="18" height="1.6" fill={C.muted} />
    </svg>
  );
}

export function BankLogo({ slug, size = 32, style }) {
  const hasOwnBg = slug ? HAS_OWN_BACKGROUND[slug] === true : false;
  const bg = hasOwnBg ? "transparent" : "#fff";
  const border = hasOwnBg ? "transparent" : C.border;
  const radius = Math.round(size * 0.26);
  return (
    <div
      style={{
        width: size, height: size, borderRadius: radius, backgroundColor: bg,
        border: `1px solid ${border}`, display: "flex", alignItems: "center",
        justifyContent: "center", overflow: "hidden", flexShrink: 0, ...style,
      }}
    >
      {slug ? (
        <img src={`/aib/banks/${slug}.png`} alt={slug} style={{ width: size, height: size, borderRadius: radius, objectFit: "cover" }} />
      ) : (
        <GenericBank size={size} />
      )}
    </div>
  );
}
