/* AIB PWA service worker.
 *
 * Caching strategy (see spec):
 *   - App shell (navigations)  : cache-first with background refresh + network fallback
 *   - Static build assets      : stale-while-revalidate (cache-first, refresh in background)
 *   - Icons / local /aib assets: cache-first
 *   - API (/api/*)             : network-only — sensitive account data is NEVER cached
 *
 * Versioned caches are cleaned up on activation so a new deploy cannot leave a
 * user stuck on an old application.
 */
var VERSION = "aib-pwa-v3";
var SHELL_CACHE = "aib-shell-" + VERSION;
var STATIC_CACHE = "aib-static-" + VERSION;

// Minimal shell + branding that must be available for a cold offline start.
var SHELL_URLS = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/favicon.png",
  "/aib/pwa/icon-192.png",
  "/aib/pwa/icon-512.png",
  "/aib/pwa/maskable-512.png",
  "/aib/pwa/apple-touch-icon.png",
  "/aib/splash-user.png",
  "/aib/banks/aib.png",
  "/aib/banks/boi.png",
  "/aib/banks/ptsb.png",
  "/aib/banks/ebs.png",
  "/aib/banks/ulster.png",
  "/aib/banks/revolut.png",
  "/aib/banks/anpost.png",
  "/aib/banks/monzo.png",
  "/aib/banks/n26.png",
  "/aib/banks/bunq.png",
  "/aib/google-play.png",
];

self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(SHELL_CACHE).then(function (cache) {
      // Cache tolerantly: one missing asset must not fail the whole install.
      return Promise.all(
        SHELL_URLS.map(function (url) {
          return cache
            .add(new Request(url, { cache: "reload" }))
            .catch(function () { return null; });
        })
      );
    })
  );
  // New SW installs but waits — the app shows a "New version" prompt and the
  // user (or controllerchange) triggers activation via SKIP_WAITING.
});

self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.map(function (key) {
          if (key !== SHELL_CACHE && key !== STATIC_CACHE) return caches.delete(key);
          return null;
        })
      );
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener("message", function (event) {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});

function isStaticAsset(url) {
  return (
    url.pathname.startsWith("/static/") ||
    url.pathname.startsWith("/aib/") ||
    /\.(?:js|css|png|jpg|jpeg|svg|gif|webp|ico|woff2?|ttf|eot|json|webmanifest)$/.test(url.pathname)
  );
}

self.addEventListener("fetch", function (event) {
  var req = event.request;
  if (req.method !== "GET") return; // mutations always go to the network / queue

  var url;
  try { url = new URL(req.url); } catch (e) { return; }

  // Ignore cross-origin (backend API host, fonts CDN, analytics).
  if (url.origin !== self.location.origin) return;

  // Never cache API responses — they can contain sensitive account data.
  if (url.pathname.startsWith("/api")) return;

  // App shell for navigations: cache-first (instant, offline-safe) + refresh.
  if (req.mode === "navigate") {
    event.respondWith(
      caches.open(SHELL_CACHE).then(function (cache) {
        return cache.match("/index.html").then(function (cached) {
          var network = fetch(req)
            .then(function (res) {
              if (res && res.status === 200) cache.put("/index.html", res.clone());
              return res;
            })
            .catch(function () { return null; });
          return cached || network || network;
        });
      })
    );
    return;
  }

  // Static assets: stale-while-revalidate.
  if (isStaticAsset(url)) {
    event.respondWith(
      caches.open(STATIC_CACHE).then(function (cache) {
        return cache.match(req).then(function (cached) {
          var network = fetch(req)
            .then(function (res) {
              if (res && res.status === 200) cache.put(req, res.clone());
              return res;
            })
            .catch(function () { return cached; });
          return cached || network;
        });
      })
    );
  }
});
