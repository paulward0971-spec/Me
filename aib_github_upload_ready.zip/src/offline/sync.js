// Synchronisation engine: drains the offline queue when the connection returns,
// with retry + exponential backoff + de-duplication, and drives the connection
// status indicator (syncing -> synced -> online).
import { listQueue, updateItem, removeItem, pendingCount } from "./queue";
import { setStatus, setPending, subscribeOnline, isOnline, getState } from "./connection";
import { markSynced } from "../aib/mock";

const processors = {}; // type -> async (payload, item) => result
const MAX_ATTEMPTS = 8;
const BASE_BACKOFF_MS = 2000;

export function registerProcessor(type, fn) { processors[type] = fn; }

let running = false;

export async function refreshPending() {
  const n = await pendingCount();
  setPending(n);
  return n;
}

export async function processQueue() {
  if (running) return;
  running = true;
  try {
    const items = await listQueue();
    for (const it of items) {
      if (it.status === "done") { await removeItem(it.id); continue; }
      if (it.nextAttemptAt && it.nextAttemptAt > Date.now()) continue; // backoff not elapsed
      const fn = processors[it.type];
      if (!fn) continue;
      try {
        await updateItem(it.id, { status: "processing" });
        await fn(it.payload, it);
        await removeItem(it.id); // success -> gone (prevents duplicates)
      } catch (e) {
        const attempts = (it.attempts || 0) + 1;
        const backoff = Math.min(BASE_BACKOFF_MS * Math.pow(2, attempts - 1), 5 * 60 * 1000);
        await updateItem(it.id, {
          status: "failed",
          attempts,
          error: String((e && e.message) || e),
          nextAttemptAt: Date.now() + backoff,
        });
        // A failed sync is retained for retry — never discarded.
        if (attempts < MAX_ATTEMPTS) scheduleRetry(backoff);
      }
    }
  } finally {
    running = false;
    await refreshPending();
  }
}

let retryTimer = null;
function scheduleRetry(delay) {
  if (retryTimer) return;
  retryTimer = setTimeout(async () => {
    retryTimer = null;
    if (isOnline()) await runSync();
  }, Math.min(delay, 30000));
}

// Full sync cycle used on reconnect + at startup.
export async function runSync() {
  if (!isOnline()) return;
  const pending = await refreshPending();
  if (pending > 0) setStatus("syncing");
  await processQueue();
  const left = await refreshPending();
  markSynced();
  if (left === 0) {
    setStatus("synced");
    setTimeout(() => { if (getState().status === "synced") setStatus("online"); }, 2500);
  } else {
    setStatus("online");
  }
}

let started = false;
export function initSync() {
  if (started) return;
  started = true;
  subscribeOnline(() => { runSync(); });
  // Attempt an initial drain shortly after boot (handles items left from a
  // previous session that ended offline).
  setTimeout(() => { if (isOnline()) runSync(); else refreshPending(); }, 1500);
}
