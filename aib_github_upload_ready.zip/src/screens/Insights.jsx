import React, { useEffect, useMemo, useState } from "react";
import StatusBar from "../aib/StatusBar";
import BottomNav from "../aib/BottomNav";
import { api, formatEuros } from "../aib/mock";
import { C } from "../aib/theme";

const DAYS = 14;
function buildSeries(txns) {
  const today = new Date();
  const cur = new Array(DAYS).fill(0);
  const prev = new Array(DAYS).fill(0);
  for (const t of txns) {
    if (t.status === "declined" || !t.amount_cents || t.amount_cents >= 0) continue;
    const d = new Date(t.date);
    const ago = Math.floor((today.getTime() - d.getTime()) / 86400000);
    if (ago >= 0 && ago < DAYS) cur[DAYS - 1 - ago] += Math.abs(t.amount_cents);
    else if (ago >= DAYS && ago < DAYS * 2) prev[DAYS * 2 - 1 - ago] += Math.abs(t.amount_cents);
  }
  const curTotal = cur.reduce((a, b) => a + b, 0);
  const prevTotal = prev.reduce((a, b) => a + b, 0);
  const diffPct = prevTotal > 0 ? Math.round(((prevTotal - curTotal) / prevTotal) * 100) : 0;
  return { cur, prev, curTotal, prevTotal, diffPct };
}

export default function Insights() {
  const [txns, setTxns] = useState([]);
  const [budgets, setBudgets] = useState([]);
  const [open, setOpen] = useState(false);
  const [b, setB] = useState({ name: "", cap: "", cat: "" });
  const reload = () => api.listBudgets().then(setBudgets);
  useEffect(() => { api.listTransactions().then(setTxns); reload(); }, []);

  const series = useMemo(() => buildSeries(txns), [txns]);
  const inOut = useMemo(() => {
    let inC = 0, outC = 0; const cats = {};
    for (const t of txns) {
      if (t.status === "declined") continue;
      if (t.amount_cents > 0) inC += t.amount_cents;
      else if (t.amount_cents < 0) { outC += Math.abs(t.amount_cents); const k = t.label || "Other"; cats[k] = (cats[k] || 0) + Math.abs(t.amount_cents); }
    }
    const catArr = Object.entries(cats).map(([name, cents]) => ({ name, cents })).sort((a, b) => b.cents - a.cents).slice(0, 6);
    return { inC, outC, catArr };
  }, [txns]);
  const CAT_COLORS = ["#B14DD6", "#7C4DFF", "#26C6DA", "#66BB6A", "#FFCA28", "#EF5350"];
  const maxBar = Math.max(...series.cur, ...series.prev, 1);
  const barW = 20, gap = 4, chartW = DAYS * (barW + gap), chartH = 140;

  const create = async () => {
    if (!b.name.trim() || !Number(b.cap)) return;
    await api.createBudget({ name: b.name.trim(), monthly_cap_cents: Math.round(Number(b.cap) * 100), categories: b.cat.trim() ? b.cat.split(",").map((s) => s.trim()) : [] });
    setB({ name: "", cap: "", cat: "" }); setOpen(false); reload();
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }}>
      <StatusBar />
      <div style={{ padding: "0 20px" }}>
        <div style={{ color: "#fff", fontSize: 32, fontWeight: 900 }}>Insights</div>
        <div style={{ color: C.muted, marginTop: 4 }}>Your spending, last 14 days</div>
      </div>
      <div className="aib-scroll" style={{ flex: 1, padding: 16 }}>
        <div style={{ background: "#111", borderRadius: 16, padding: 20, marginBottom: 16 }}>
          <div style={{ color: C.muted, fontSize: 13 }}>Total spent</div>
          <div style={{ color: "#fff", fontSize: 32, fontWeight: 900, marginTop: 6 }}>{formatEuros(-series.curTotal)}</div>
          <div style={{ display: "inline-block", marginTop: 10, background: "rgba(76,175,80,0.15)", borderRadius: 999, padding: "6px 12px" }}>
            <span style={{ color: C.success, fontSize: 13, fontWeight: 800 }}>{series.diffPct >= 0 ? `${series.diffPct}% lower than same period last month` : `${Math.abs(series.diffPct)}% higher than same period last month`}</span>
          </div>
        </div>

        <div style={{ background: "#111", borderRadius: 16, padding: 16, marginBottom: 20 }}>
          <div style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>Daily spend</div>
          <div style={{ overflowX: "auto", padding: "12px 0" }}>
            <svg width={chartW} height={chartH + 26}>
              <line x1="0" y1={chartH} x2={chartW} y2={chartH} stroke="#1F1F1F" strokeWidth={1} />
              {series.cur.map((v, i) => {
                const h = (v / maxBar) * (chartH - 10);
                const x = i * (barW + gap);
                const ph = (series.prev[i] / maxBar) * (chartH - 10);
                return (<g key={i}><rect x={x + 4} y={chartH - ph} width={barW - 8} height={ph} fill="#2A2A2A" rx={3} /><rect x={x} y={chartH - h} width={barW} height={h} fill={C.brandTertiary} rx={4} /></g>);
              })}
            </svg>
          </div>
          <div style={{ display: "flex", alignItems: "center", marginTop: 6 }}>
            <div style={{ width: 10, height: 10, borderRadius: 5, background: C.brandTertiary, marginRight: 6 }} /><span style={{ color: C.muted, fontSize: 12, fontWeight: 700 }}>This period</span>
            <div style={{ width: 10, height: 10, borderRadius: 5, background: "#2A2A2A", marginLeft: 16, marginRight: 6 }} /><span style={{ color: C.muted, fontSize: 12, fontWeight: 700 }}>Last month</span>
          </div>
        </div>

        <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
          <div style={{ flex: 1, background: "#111", borderRadius: 16, padding: 16 }}>
            <div style={{ color: C.muted, fontSize: 12 }}>Money in</div>
            <div data-testid="money-in" style={{ color: C.success, fontSize: 20, fontWeight: 900, marginTop: 4 }}>{formatEuros(inOut.inC)}</div>
          </div>
          <div style={{ flex: 1, background: "#111", borderRadius: 16, padding: 16 }}>
            <div style={{ color: C.muted, fontSize: 12 }}>Money out</div>
            <div data-testid="money-out" style={{ color: "#fff", fontSize: 20, fontWeight: 900, marginTop: 4 }}>{formatEuros(-inOut.outC)}</div>
          </div>
        </div>

        {inOut.catArr.length > 0 && (
          <div style={{ background: "#111", borderRadius: 16, padding: 16, marginBottom: 20 }}>
            <div style={{ color: "#fff", fontSize: 15, fontWeight: 800, marginBottom: 12 }}>Spending by category</div>
            {inOut.catArr.map((c, i) => {
              const pct = Math.max(6, Math.round((c.cents / inOut.catArr[0].cents) * 100));
              return (
                <div key={c.name} style={{ marginBottom: i < inOut.catArr.length - 1 ? 12 : 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                    <span style={{ color: "#fff", fontSize: 13, fontWeight: 700 }}>{c.name}</span>
                    <span style={{ color: C.muted, fontSize: 13, fontWeight: 700 }}>{formatEuros(-c.cents)}</span>
                  </div>
                  <div style={{ height: 8, background: "#222", borderRadius: 4, overflow: "hidden" }}>
                    <div style={{ height: 8, borderRadius: 4, width: `${pct}%`, background: CAT_COLORS[i % CAT_COLORS.length], transition: "width 0.6s ease" }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ color: "#fff", fontSize: 20, fontWeight: 900 }}>Budgets</div>
          <div className="aib-press" onClick={() => setOpen(true)} style={{ color: C.brandLight, fontSize: 14, fontWeight: 800 }}>+ Create a budget</div>
        </div>

        {budgets.length === 0 ? (
          <div style={{ background: "#111", borderRadius: 16, padding: 20, textAlign: "center" }}>
            <div style={{ color: "#fff", fontSize: 16, fontWeight: 900 }}>No budgets yet</div>
            <div style={{ color: C.muted, fontSize: 13, marginTop: 8, lineHeight: "18px" }}>Set a monthly spend cap and we'll track it against your live transactions.</div>
            <div className="aib-btn" onClick={() => setOpen(true)} style={{ display: "inline-block", marginTop: 16, background: C.brandPrimary, padding: "12px 22px", borderRadius: 999, color: "#fff", fontWeight: 800 }}>Create a budget</div>
          </div>
        ) : budgets.map((bd) => (
          <div key={bd.id} style={{ background: "#111", borderRadius: 16, padding: 16, marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>{bd.name}</span>
              <span style={{ color: C.muted, fontSize: 13, fontWeight: 700 }}>{formatEuros(-bd.spent_cents)} / {formatEuros(-bd.monthly_cap_cents)}</span>
            </div>
            <div style={{ height: 8, background: "#222", borderRadius: 4, overflow: "hidden" }}><div style={{ height: 8, borderRadius: 4, width: `${Math.round(bd.percent * 100)}%`, background: bd.percent > 0.9 ? C.error : C.brandTertiary }} /></div>
            {bd.categories?.length > 0 && <div style={{ color: C.muted, fontSize: 12, marginTop: 8, textTransform: "capitalize" }}>{bd.categories.join(", ")}</div>}
          </div>
        ))}
      </div>
      <BottomNav active="insights" />

      {open && (
        <div onClick={() => setOpen(false)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "flex-end", zIndex: 50 }}>
          <div onClick={(e) => e.stopPropagation()} className="aib-fadein" style={{ width: "100%", background: "#0F0F0F", padding: "20px 20px 32px", borderTopLeftRadius: 20, borderTopRightRadius: 20 }}>
            <div style={{ width: 40, height: 4, borderRadius: 2, background: "#3D3D3D", margin: "0 auto 16px" }} />
            <div style={{ color: "#fff", fontSize: 20, fontWeight: 900, marginBottom: 12 }}>Create a budget</div>
            <Lbl>Name</Lbl>
            <input style={inp} placeholder="e.g. Groceries" value={b.name} onChange={(e) => setB({ ...b, name: e.target.value })} />
            <Lbl>Monthly cap (EUR)</Lbl>
            <input style={inp} placeholder="200" value={b.cap} onChange={(e) => setB({ ...b, cap: e.target.value })} />
            <Lbl>Categories (comma-separated, optional)</Lbl>
            <input style={inp} placeholder="groceries, entertainment" value={b.cat} onChange={(e) => setB({ ...b, cat: e.target.value })} />
            <div className="aib-btn" onClick={create} style={{ background: C.brandPrimary, padding: 14, borderRadius: 999, textAlign: "center", marginTop: 20, color: "#fff", fontSize: 15, fontWeight: 800 }}>Save budget</div>
          </div>
        </div>
      )}
    </div>
  );
}

const Lbl = ({ children }) => <div style={{ color: C.muted, fontSize: 12, fontWeight: 700, marginTop: 10, marginBottom: 6 }}>{children}</div>;
const inp = { width: "100%", background: "#161616", color: "#fff", padding: 14, borderRadius: 12, fontSize: 15, fontWeight: 600, border: "none" };
