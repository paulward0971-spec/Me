import React, { useEffect, useState } from "react";
import StatusBar from "../aib/StatusBar";
import BottomNav from "../aib/BottomNav";
import { api } from "../aib/mock";
import { C } from "../aib/theme";

function Snowflake({ size = 28 }) { return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M12 2 V22 M2 12 H22 M5 5 L19 19 M19 5 L5 19" stroke="#fff" strokeWidth={2} strokeLinecap="round" /></svg>); }
function Hash({ size = 28 }) { return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M9 3 L7 21 M17 3 L15 21 M4 9 H21 M3 15 H20" stroke="#fff" strokeWidth={2} strokeLinecap="round" /></svg>); }
function Dots({ size = 28 }) { return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><circle cx="12" cy="5" r="1.6" fill="#fff" /><circle cx="12" cy="12" r="1.6" fill="#fff" /><circle cx="12" cy="19" r="1.6" fill="#fff" /></svg>); }
function IceCrystal({ size = 72 }) { return (<svg width={size} height={size} viewBox="0 0 60 60" fill="none"><path d="M30 4 V56 M4 30 H56 M10 10 L50 50 M50 10 L10 50" stroke="#B3E5FC" strokeWidth={2.5} strokeLinecap="round" /><path d="M26 8 L30 4 L34 8 M26 52 L30 56 L34 52 M8 26 L4 30 L8 34 M52 26 L56 30 L52 34" stroke="#B3E5FC" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>); }

export default function Cards() {
  const [frozen, setFrozen] = useState(false);
  const [profile, setProfile] = useState(null);
  useEffect(() => { api.getProfile().then((p) => { setProfile(p); setFrozen(!!p.card_frozen); }); }, []);
  const toggleFreeze = () => setFrozen((f) => { const n = !f; api.updateProfile({ card_frozen: n }); return n; });
  const initials = (profile?.account_holder || "J G").split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }}>
      <StatusBar />
      <div className="aib-scroll" style={{ flex: 1, paddingBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 20px 8px" }}>
          <div style={{ width: 40, height: 40, borderRadius: 20, background: C.brandDeep, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 12 }}>{initials}</div>
          <div style={{ color: "#fff", fontSize: 18, fontWeight: 800 }}>Debit-{profile?.card_last4 || "4412"}</div>
          <div style={{ width: 40, height: 40, borderRadius: 20, background: C.surfaceSecondary, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800 }}>?</div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: 8 }}>
          <div style={{ width: "88%", aspectRatio: "1.6", borderRadius: 20, overflow: "hidden", background: "#000", position: "relative" }}>
            <img src="/aib/card-user.png" alt="card" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            {frozen && (<div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "rgba(179,229,252,0.28)" }}><IceCrystal /><div style={{ color: "#01579B", fontSize: 20, fontWeight: 900, marginTop: 6, letterSpacing: 1 }}>Card frozen</div></div>)}
          </div>

          <div style={{ color: C.muted, marginTop: 20, fontSize: 14, fontWeight: 700, letterSpacing: 0.5 }}>{profile?.account_label || "AIB BANK ACCOUNT-017"}</div>

          <div style={{ display: "flex", gap: 20, marginTop: 22 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div className="aib-btn" data-testid="freeze-tile-btn" onClick={toggleFreeze} style={{ width: 60, height: 60, borderRadius: 16, background: frozen ? "#0288D1" : C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center" }}><Snowflake /></div>
              <div style={{ color: "#fff", fontSize: 14, fontWeight: 700, marginTop: 6 }}>{frozen ? "Unfreeze" : "Freeze"}</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div className="aib-btn" style={{ width: 60, height: 60, borderRadius: 16, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", opacity: frozen ? 0.4 : 1 }}><Hash /></div>
              <div style={{ color: "#fff", fontSize: 14, fontWeight: 700, marginTop: 6 }}>Show PIN</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div className="aib-btn" style={{ width: 60, height: 60, borderRadius: 16, background: C.surfaceSecondary, display: "flex", alignItems: "center", justifyContent: "center" }}><Dots /></div>
              <div style={{ color: "#fff", fontSize: 14, fontWeight: 700, marginTop: 6 }}>More</div>
            </div>
          </div>

          {frozen && (<div style={{ marginTop: 18, marginLeft: 16, marginRight: 16, padding: 14, borderRadius: 12, background: "rgba(2,136,209,0.15)", borderLeft: "3px solid #03A9F4", alignSelf: "stretch" }}><div style={{ color: "#03A9F4", fontSize: 14, fontWeight: 800 }}>This card is frozen</div><div style={{ color: "#B3E5FC", fontSize: 13, marginTop: 6, lineHeight: "18px" }}>Payments and cash withdrawals will be declined. Tap Unfreeze to reactivate.</div></div>)}
        </div>

        <div style={{ marginTop: 24, marginLeft: 16, marginRight: 16, background: C.surfaceSecondary, borderRadius: 16, padding: "16px 16px", display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12, background: frozen ? "rgba(2,136,209,0.22)" : "rgba(142,36,170,0.18)", display: "flex", alignItems: "center", justifyContent: "center", transition: "background 0.25s ease" }}><Snowflake size={22} /></div>
          <div style={{ flex: 1 }}>
            <div style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>Freeze card</div>
            <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>{frozen ? "Frozen — payments & withdrawals blocked" : "Instantly block payments & withdrawals"}</div>
          </div>
          <Toggle on={frozen} onToggle={toggleFreeze} />
        </div>

        <div style={{ marginTop: 20, marginLeft: 16, marginRight: 16, background: C.surfaceSecondary, borderRadius: 16, padding: 4 }}>
          {[["Card holder", profile?.card_holder || "John Guilfoyle"], ["Expires", profile?.card_expiry || "07/29"], ["Card number", `•••• •••• •••• ${profile?.card_last4 || "4412"}`]].map(([l, v], i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "14px 14px", borderBottom: i < 2 ? `0.5px solid ${C.border}` : "none" }}>
              <span style={{ color: C.muted, fontSize: 14 }}>{l}</span>
              <span style={{ color: "#fff", fontSize: 14, fontWeight: 700 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
      <BottomNav active="cards" />
    </div>
  );
}

function Toggle({ on, onToggle }) {
  return (
    <div className="aib-btn" data-testid="freeze-toggle" onClick={onToggle} style={{ width: 52, height: 30, borderRadius: 15, background: on ? "#0288D1" : "#3A3A3A", position: "relative", transition: "background 0.25s ease", flexShrink: 0 }}>
      <div style={{ position: "absolute", top: 3, left: on ? 25 : 3, width: 24, height: 24, borderRadius: 12, background: "#fff", transition: "left 0.25s cubic-bezier(.4,0,.2,1)", boxShadow: "0 1px 3px rgba(0,0,0,0.4)" }} />
    </div>
  );
}
