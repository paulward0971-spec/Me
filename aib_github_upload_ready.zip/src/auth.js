const API_BASE = process.env.REACT_APP_BACKEND_URL || "";

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  let data = {};
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const authApi = {
  session: () => request("/api/auth/session"),
  requestCode: () => request("/api/auth/request-code", { method: "POST", body: JSON.stringify({}) }),
  verifyCode: (pendingId, code) => request("/api/auth/verify-code", { method: "POST", body: JSON.stringify({ pendingId, code }) }),
  logout: () => request("/api/auth/logout", { method: "POST" }),
};
