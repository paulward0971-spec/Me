import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Send, ChevronLeft } from "lucide-react";
import { AbiOrb } from "../aib/AbiOrb";
import { C } from "../aib/theme";
import { api, formatEuros, formatIban } from "../aib/mock";
import { enqueue } from "../offline/queue";
import { refreshPending } from "../offline/sync";

const API = process.env.REACT_APP_BACKEND_URL;

const SUGGESTIONS = [
  "How do I send money?",
  "Is my transfer instant?",
  "How long does a transfer take?",
  "How do I freeze my card?",
];

// Abi looks like she is genuinely researching the customer's payment info before replying.
const RESEARCH_STEPS = [
  "Looking into that for you…",
  "Checking your payment details…",
  "Reviewing your transfer information…",
  "Putting your answer together…",
];

function AbiAvatar({ size = 34, spin = false }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, background: "#0F0F12", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, border: "1px solid #26262C", overflow: "hidden" }}>
      <AbiOrb size={Math.round(size * 0.82)} className={spin ? "aib-orb-spin" : undefined} />
    </div>
  );
}

export default function Chat() {
  const nav = useNavigate();
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [research, setResearch] = useState("");
  const endRef = useRef(null);
  // New ephemeral session each time the chat opens — history is remembered while
  // you're in the chat, but cleared the moment you leave and reopen it.
  const sidRef = useRef("abi-" + Math.random().toString(36).slice(2) + Date.now().toString(36));

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy, research]);

  const send = async (preset) => {
    const m = (preset ?? text).trim();
    if (!m || busy) return;
    setText(""); setBusy(true);
    setMessages((p) => [...p, { role: "user", text: m }]);

    // OFFLINE: never fake an AI reply. Save the message, queue it, and let the
    // user know it will be sent to Abi automatically once back online.
    if (!navigator.onLine) {
      const clientId = "chat-" + sidRef.current + "-" + Date.now();
      let ctx = "";
      try { ctx = await buildContext(); } catch (e) {}
      await enqueue("chat", { session_id: sidRef.current, message: m, context: ctx }, clientId);
      try { await api.appendChat(sidRef.current, { role: "user", text: m, ts: new Date().toISOString() }); } catch (e) {}
      try { await refreshPending(); } catch (e) {}
      setMessages((p) => [...p, { role: "assistant", text: "You're offline, so Abi can't reply right now. Your message is saved and will be sent automatically when you're back online.", offline: true }]);
      setBusy(false);
      return;
    }

    // Cycle through the "researching" status lines so the wait feels considered.
    let i = 0; setResearch(RESEARCH_STEPS[0]);
    const iv = setInterval(() => { i = (i + 1) % RESEARCH_STEPS.length; setResearch(RESEARCH_STEPS[i]); }, 1200);

    try {
      const context = await buildContext();
      const [data] = await Promise.all([
        fetch(`${API}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ session_id: sidRef.current, message: m, context }),
        }).then((r) => r.json()),
        // Minimum "research" time so a reply never snaps back instantly.
        new Promise((r) => setTimeout(r, 3200)),
      ]);
      if (Array.isArray(data.messages)) setMessages(data.messages);
      else throw new Error("bad response");
    } catch (e) {
      setMessages((p) => [...p, { role: "assistant", text: "Sorry, I couldn't reach the assistant just now. Please note transfers are sent as a SEPA Standard Credit Transfer — they are not instant and can take up to 24 hours to arrive." }]);
    } finally {
      clearInterval(iv);
      setBusy(false); setResearch("");
    }
  };

  const empty = messages.length === 0;

  const buildContext = async () => {
    try {
      const [profile, transfers, txns] = await Promise.all([api.getProfile(), api.listTransfers(), api.listTransactions()]);
      const sorted = [...(transfers || [])].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 10);
      const tLines = sorted.length
        ? sorted.map((t, i) => `${i + 1}. Sent ${formatEuros(t.amount_cents)} to ${t.recipient_name} — IBAN ${formatIban(t.iban)}, BIC ${t.bic || "n/a"}, bank ${t.bank_name}, reference ${t.reference || t.note || "n/a"}, transaction ID ${t.transaction_id}, status ${t.status}, type SEPA Standard Credit Transfer, submitted ${t.created_at}`).join("\n")
        : "No transfers sent yet.";
      const acct = `Account holder: ${profile.account_holder}. Balance: ${formatEuros(profile.balance_cents || 0)} (${formatEuros(profile.available_cents || 0)} available). Account IBAN: ${formatIban(profile.iban || "")}.`;
      const recent = (txns || []).slice(0, 8).map((t) => `${t.merchant}: ${formatEuros(t.amount_cents)} (${t.label || "payment"}, ${t.status})`).join("; ");
      return `${acct}\nRecent transfers:\n${tLines}\nRecent activity: ${recent || "None."}`;
    } catch (e) {
      return "";
    }
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#08080A" }} data-testid="chat-screen">
      {/* Header */}
      <div style={{ position: "relative", flexShrink: 0, background: "linear-gradient(135deg,#4A0E5C 0%,#8C1B8E 100%)", padding: "44px 16px 16px", boxShadow: "0 8px 24px rgba(0,0,0,0.4)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div className="aib-press" data-testid="chat-back-btn" onClick={() => nav(-1)} style={{ width: 38, height: 38, borderRadius: 19, background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <ChevronLeft size={22} color="#fff" strokeWidth={2.4} />
          </div>
          <div style={{ width: 44, height: 44, borderRadius: 22, background: "rgba(255,255,255,0.12)", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
            <AbiOrb size={38} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ color: "#fff", fontSize: 18, fontWeight: 900, letterSpacing: 0.2 }}>Abi</div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 2 }}>
              <span style={{ width: 7, height: 7, borderRadius: 4, background: "#4CE07B", boxShadow: "0 0 6px #4CE07B" }} />
              <span style={{ color: "rgba(255,255,255,0.9)", fontSize: 12, fontWeight: 700 }}>Digital assistant · online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="aib-scroll" style={{ flex: 1, padding: "18px 16px 8px" }} data-testid="chat-messages">
        {empty && (
          <div className="aib-fadein" style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", marginTop: 20, marginBottom: 18 }}>
            <AbiOrb size={92} className="aib-orb-float" />
            <div style={{ color: "#fff", fontSize: 20, fontWeight: 900, marginTop: 14 }}>Hi, I'm Abi</div>
            <div style={{ color: C.muted, fontSize: 14, lineHeight: "21px", marginTop: 8, maxWidth: 280 }}>I'm your AIB digital assistant. Ask me about transfers, cards, budgets or your balance.</div>
          </div>
        )}

        {messages.map((m, i) => {
          const isUser = m.role === "user";
          return (
            <div key={i} className="aib-msg-in" style={{ display: "flex", alignItems: "flex-end", gap: 8, justifyContent: isUser ? "flex-end" : "flex-start", marginBottom: 12 }}>
              {!isUser && <AbiAvatar size={30} />}
              <div style={{ maxWidth: "76%", padding: "11px 15px", borderRadius: 18, background: isUser ? "linear-gradient(135deg,#9A2FB4,#7A1690)" : "#17171B", color: isUser ? "#fff" : "#ECECEF", fontSize: 14.5, lineHeight: "21px", fontWeight: isUser ? 600 : 500, borderBottomRightRadius: isUser ? 5 : 18, borderBottomLeftRadius: isUser ? 18 : 5, boxShadow: "0 2px 10px rgba(0,0,0,0.25)", border: isUser ? "none" : "1px solid #232329" }}>{m.text}</div>
            </div>
          );
        })}

        {busy && (
          <div className="aib-msg-in" style={{ display: "flex", alignItems: "flex-end", gap: 8, marginBottom: 12 }}>
            <AbiAvatar size={30} spin />
            <div style={{ padding: "11px 15px", borderRadius: 18, borderBottomLeftRadius: 5, background: "#17171B", border: "1px solid #232329", display: "flex", alignItems: "center", gap: 10, maxWidth: "76%" }}>
              <span style={{ color: "#D9B8E8", fontSize: 13.5, fontWeight: 600 }}>{research || "Thinking…"}</span>
              <span className="aib-typing" style={{ display: "inline-flex" }}><span /><span /><span /></span>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Quick suggestions */}
      {!busy && (
        <div style={{ display: "flex", gap: 8, padding: "4px 14px 10px", overflowX: "auto", flexShrink: 0, scrollbarWidth: "none" }}>
          {SUGGESTIONS.map((s) => (
            <div key={s} className="aib-press" data-testid="chat-suggestion" onClick={() => send(s)} style={{ flexShrink: 0, whiteSpace: "nowrap", padding: "9px 14px", borderRadius: 999, background: "rgba(160,54,190,0.14)", border: "1px solid rgba(199,125,218,0.4)", color: "#E6C6F2", fontSize: 13, fontWeight: 700 }}>{s}</div>
          ))}
        </div>
      )}

      {/* Composer */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px 22px", borderTop: "1px solid #1A1A1F", background: "#0C0C0F", flexShrink: 0 }}>
        <input
          value={text}
          data-testid="chat-input"
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Message Abi…"
          style={{ flex: 1, background: "#17171B", color: "#fff", border: "1px solid #26262C", borderRadius: 999, padding: "13px 18px", fontSize: 15 }}
        />
        <div className="aib-btn" data-testid="chat-send-btn" onClick={() => send()} style={{ width: 48, height: 48, borderRadius: 24, background: text.trim() && !busy ? "linear-gradient(135deg,#A036BE,#7A1690)" : "#2A2A30", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, opacity: text.trim() && !busy ? 1 : 0.6 }}>
          <Send size={20} color="#fff" strokeWidth={2.2} />
        </div>
      </div>
    </div>
  );
}
