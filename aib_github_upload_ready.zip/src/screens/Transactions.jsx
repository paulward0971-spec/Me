import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { api, formatEuros, initialsFor } from "../aib/mock";
import { C } from "../aib/theme";

function BackChev() { return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M15 5 L8 12 L15 19" stroke="#E1BEE7" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>); }

// Google Play store purchases show the official Play logo (user-supplied asset).
function AppTile() {
  return (
    <div style={{ width: 48, height: 48, borderRadius: 12, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, overflow: "hidden" }}>
      <img src="/aib/google-play.png" alt="Google Play" style={{ width: 38, height: 38, objectFit: "contain" }} />
    </div>
  );
}
function InitialsTile({ name }) {
  return (
    <div style={{ width: 48, height: 48, borderRadius: 12, background: "linear-gradient(160deg,#8E24AA,#4A0E5C)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <span style={{ color: "#fff", fontWeight: 800, fontSize: 16 }}>{initialsFor(name)}</span>
    </div>
  );
}

function timeOf(iso) { return new Date(iso).toLocaleTimeString("en-IE", { hour: "2-digit", minute: "2-digit", hour12: false }); }
function dayKey(iso) { const d = new Date(iso); return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`; }
function dayLabel(iso) { return new Date(iso).toLocaleDateString("en-IE", { day: "numeric", month: "long" }); }

export default function Transactions() {
  const nav = useNavigate();
  const [txns, setTxns] = useState([]);
  const [q, setQ] = useState("");
  useEffect(() => { api.listTransactions().then(setTxns); }, []);

  const groups = useMemo(() => {
    const filtered = txns.filter((t) => {
      if (!q.trim()) return true;
      const s = q.toLowerCase();
      return (t.merchant || "").toLowerCase().includes(s) || (t.label || "").toLowerCase().includes(s);
    });
    const sorted = [...filtered].sort((a, b) => new Date(b.date) - new Date(a.date));
    const map = new Map();
    for (const t of sorted) {
      const k = dayKey(t.date);
      if (!map.has(k)) map.set(k, { label: dayLabel(t.date), items: [], total: 0 });
      const g = map.get(k);
      g.items.push(t);
      if (t.status !== "declined") g.total += t.amount_cents;
    }
    return Array.from(map.values());
  }, [txns, q]);

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }}>
      <div style={{ display: "flex", alignItems: "center", padding: "40px 16px 10px", position: "relative" }}>
        <div className="aib-press" onClick={() => nav(-1)} style={{ width: 42, height: 42, borderRadius: 21, background: "#161616", display: "flex", alignItems: "center", justifyContent: "center" }}><BackChev /></div>
        <div style={{ position: "absolute", left: 0, right: 0, textAlign: "center", color: "#fff", fontSize: 20, fontWeight: 800, pointerEvents: "none" }}>Transactions</div>
      </div>

      <div style={{ display: "flex", gap: 12, padding: "6px 16px 12px", alignItems: "center" }}>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 10, background: "#2A2A2C", borderRadius: 999, padding: "12px 16px" }}>
          <Search size={20} color={C.muted} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" style={{ flex: 1, background: "transparent", border: "none", color: "#fff", fontSize: 16 }} />
        </div>
        <div className="aib-press" style={{ width: 46, height: 46, borderRadius: 23, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><SlidersHorizontal size={20} color="#fff" /></div>
      </div>

      <div style={{ padding: "0 16px 12px" }}>
        <div style={{ display: "inline-flex", alignItems: "center", gap: 10, background: C.brandPrimary, borderRadius: 999, padding: "9px 16px" }}>
          <span style={{ color: "#fff", fontSize: 15, fontWeight: 800, letterSpacing: 0.3 }}>AIB BANK ACCOUNT-017</span>
          <X size={17} color="#fff" />
        </div>
      </div>

      <div className="aib-scroll" style={{ flex: 1, padding: "0 16px 30px" }}>
        {groups.length === 0 && <div style={{ color: C.muted, textAlign: "center", marginTop: 40 }}>No transactions found.</div>}
        {groups.map((g, gi) => (
          <div key={gi} style={{ marginTop: gi === 0 ? 6 : 18 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
              <span style={{ color: "#fff", fontSize: 22, fontWeight: 900 }}>{g.label}</span>
              <span style={{ color: g.total > 0 ? C.success : C.muted, fontSize: 17, fontWeight: 700 }}>{formatEuros(g.total)}</span>
            </div>
            {g.items.map((t) => {
              const declined = t.status === "declined";
              const credit = t.amount_cents > 0;
              const isApp = (t.merchant || "").toLowerCase().includes("google play");
              return (
                <div key={t.id} className="aib-press" onClick={() => nav(`/transaction/${t.id}`)} style={{ display: "flex", alignItems: "center", gap: 14, background: "#161618", borderRadius: 18, padding: "16px 16px", marginBottom: 12 }}>
                  {isApp ? <AppTile /> : <InitialsTile name={t.merchant} />}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ color: "#fff", fontSize: 19, fontWeight: 800 }}>{t.merchant}</div>
                    <div style={{ color: C.muted, fontSize: 15, marginTop: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{timeOf(t.date)} • {t.label || "Payment"}</div>
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <div style={{ color: declined ? C.muted : credit ? C.success : "#fff", fontSize: 19, fontWeight: 800, textDecoration: declined ? "line-through" : "none" }}>{formatEuros(t.amount_cents)}</div>
                    {declined && <div style={{ color: C.error, fontSize: 15, fontWeight: 700, marginTop: 3 }}>Declined</div>}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
