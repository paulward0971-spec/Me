# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)


## Private access / Resend OTP

The app now uses server-side email OTP authentication. Configure these **server-only** environment variables before deploying:

```bash
RESEND_API_KEY=re_...
AUTH_FROM_EMAIL=Private AIB <login@your-verified-domain.example>
AUTH_ALLOWED_EMAILS=owner@example.com
AUTH_LOGIN_EMAIL=owner@example.com
SESSION_DAYS=30
AUTH_CODE_MINUTES=10
```

`AUTH_FROM_EMAIL` must use a domain/address verified in Resend. `AUTH_ALLOWED_EMAILS` is the access allowlist. `AUTH_LOGIN_EMAIL` is the mailbox that receives the automatic one-time code; the browser never asks the user to enter an email address.

Flow:
1. The user enters an authorised email.
2. The server sends a six-digit code through Resend.
3. The code expires after the configured interval and is invalid after one successful use.
4. Verification creates a persistent, HttpOnly session cookie.
5. The session is stored server-side (hashed token only) and survives a server restart when the deployment filesystem is persistent.
6. Logout invalidates the session.

Do not put `RESEND_API_KEY` in `REACT_APP_*` variables or client-side code.

The PWA remains installable from the browser's Add to Home Screen / Install App action. On phones the existing phone frame becomes full-viewport and respects `safe-area-inset-*` values for notches and home indicators.
