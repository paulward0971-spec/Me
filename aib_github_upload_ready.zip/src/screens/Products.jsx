import React from "react";
import StatusBar from "../aib/StatusBar";
import BottomNav from "../aib/BottomNav";
import { C } from "../aib/theme";

const PRODUCTS = [
  { id: "sav", title: "Online Saver", body: "1.50% variable p.a. Instant access.", tag: "Savings" },
  { id: "loan", title: "Personal Loan", body: "Borrow from €1,000. Fixed rate.", tag: "Loans" },
  { id: "mort", title: "Green Mortgage", body: "Discounted rate for BER A homes.", tag: "Mortgage" },
  { id: "inv", title: "Investment Funds", body: "Start investing with €100/mo.", tag: "Invest" },
];

export default function Products() {
  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }}>
      <StatusBar />
      <div style={{ padding: "0 20px 12px" }}>
        <div style={{ color: "#fff", fontSize: 32, fontWeight: 900 }}>Products</div>
        <div style={{ color: C.muted, marginTop: 4 }}>Explore AIB products</div>
      </div>
      <div className="aib-scroll" style={{ flex: 1, padding: "0 16px 24px" }}>
        {PRODUCTS.map((p) => (
          <div key={p.id} className="aib-press" style={{ background: C.surfaceSecondary, padding: 18, borderRadius: 16, marginBottom: 12 }}>
            <div style={{ color: C.brandTertiary, fontSize: 12, fontWeight: 800, letterSpacing: 0.5 }}>{p.tag}</div>
            <div style={{ color: "#fff", fontSize: 18, fontWeight: 900, marginTop: 6 }}>{p.title}</div>
            <div style={{ color: C.muted, fontSize: 13, marginTop: 6 }}>{p.body}</div>
          </div>
        ))}
      </div>
      <BottomNav active="products" />
    </div>
  );
}
