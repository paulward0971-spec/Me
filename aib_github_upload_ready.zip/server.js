/* Private AIB PWA server.
 *
 * - Serves the CRA build / SPA
 * - Sends one-time login codes through Resend
 * - Verifies codes once and creates persistent HttpOnly sessions
 * - Does not cache authentication/API responses
 *
 * Required production environment:
 *   RESEND_API_KEY=re_...
 *   AUTH_FROM_EMAIL=Your App <login@your-verified-domain.example>
 *   AUTH_ALLOWED_EMAILS=user@example.com,another@example.com
 *   AUTH_LOGIN_EMAIL=user@example.com   # email that receives the automatic login code
 * Optional:
 *   SESSION_DAYS=30
 *   AUTH_CODE_MINUTES=10
 *   AUTH_APP_NAME=Private AIB
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const zlib = require("zlib");

const BUILD_DIR = path.join(__dirname, "build");
const DATA_DIR = path.join(__dirname, ".private-data");
const AUTH_FILE = path.join(DATA_DIR, "auth.json");
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || "0.0.0.0";
const SESSION_DAYS = Math.max(1, Number(process.env.SESSION_DAYS || 30));
const CODE_MINUTES = Math.max(2, Number(process.env.AUTH_CODE_MINUTES || 10));
const APP_NAME = process.env.AUTH_APP_NAME || "Private AIB";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
  ".gif": "image/gif", ".svg": "image/svg+xml", ".ico": "image/x-icon",
  ".webp": "image/webp", ".woff": "font/woff", ".woff2": "font/woff2",
  ".ttf": "font/ttf", ".txt": "text/plain; charset=utf-8", ".map": "application/json; charset=utf-8",
};

const NO_CACHE = new Set(["/service-worker.js", "/manifest.webmanifest", "/manifest.json", "/index.html", "/"]);
const COOKIE_NAME = "aib_private_session";
const CODE_COOKIE = "aib_login_pending";
const sessions = new Map();
const loginCodes = new Map();
const rate = new Map();

function loadAuth() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const data = JSON.parse(fs.readFileSync(AUTH_FILE, "utf8"));
    for (const [id, session] of Object.entries(data.sessions || {})) sessions.set(id, session);
  } catch (_) {}
}
function saveAuth() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const sessionsObj = Object.fromEntries(sessions);
  const tmp = AUTH_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify({ sessions: sessionsObj }, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, AUTH_FILE);
}
loadAuth();

function cleanup() {
  const now = Date.now();
  for (const [id, s] of sessions) if (s.expiresAt <= now) sessions.delete(id);
  for (const [id, c] of loginCodes) if (c.expiresAt <= now || c.used) loginCodes.delete(id);
  for (const [key, t] of rate) if (t < now - 60_000) rate.delete(key);
}
setInterval(() => { cleanup(); saveAuth(); }, 60_000).unref();

function hash(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}
function randomToken(bytes = 32) { return crypto.randomBytes(bytes).toString("base64url"); }
function normalEmail(v) { return String(v || "").trim().toLowerCase(); }
function allowedEmails() {
  return String(process.env.AUTH_ALLOWED_EMAILS || "").split(",").map(normalEmail).filter(Boolean);
}
function isAllowed(email) {
  const list = allowedEmails();
  return list.length > 0 && list.includes(email);
}
function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function sessionFrom(req) {
  cleanup();
  const token = parseCookies(req)[COOKIE_NAME];
  if (!token) return null;
  const session = sessions.get(hash(token));
  if (!session || session.expiresAt <= Date.now()) {
    if (session) sessions.delete(hash(token));
    return null;
  }
  return { token, ...session };
}
function secureCookie() {
  return process.env.NODE_ENV === "production" || process.env.COOKIE_SECURE === "true";
}
function cookie(name, value, maxAge) {
  return `${name}=${encodeURIComponent(value)}; Max-Age=${maxAge}; Path=/; HttpOnly; SameSite=Lax${secureCookie() ? "; Secure" : ""}`;
}
function clearCookie(name) {
  return `${name}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax${secureCookie() ? "; Secure" : ""}`;
}
function send(res, status, headers, body) {
  res.writeHead(status, headers);
  res.end(body || "");
}
function json(res, status, obj, extra = {}) {
  send(res, status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...extra }, JSON.stringify(obj));
}
function bodyJson(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", chunk => {
      raw += chunk;
      if (raw.length > 32 * 1024) req.destroy();
    });
    req.on("end", () => {
      try { resolve(JSON.parse(raw || "{}")); } catch (_) { reject(new Error("Invalid JSON")); }
    });
    req.on("error", reject);
  });
}
function rateLimit(key, limit = 5) {
  const now = Date.now();
  const arr = rate.get(key) || [];
  const fresh = arr.filter(t => t > now - 10 * 60_000);
  fresh.push(now);
  rate.set(key, fresh);
  return fresh.length <= limit;
}
function getIp(req) {
  return String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();
}

async function sendLoginCode(email, code) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.AUTH_FROM_EMAIL;
  if (!apiKey || !from) throw new Error("Resend is not configured. Set RESEND_API_KEY and AUTH_FROM_EMAIL.");
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from,
      to: [email],
      subject: `${APP_NAME} sign-in code`,
      text: `Your ${APP_NAME} one-time sign-in code is ${code}.\n\nIt expires in ${CODE_MINUTES} minutes and can only be used once. If you did not request it, you can ignore this email.`,
      html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto"><h2>${APP_NAME}</h2><p>Your one-time sign-in code is:</p><p style="font-size:32px;font-weight:700;letter-spacing:8px">${code}</p><p>This code expires in ${CODE_MINUTES} minutes and can only be used once.</p></div>`,
    }),
  });
  if (!response.ok) throw new Error(`Resend returned ${response.status}`);
}

async function authRoute(req, res, pathname) {
  const ip = getIp(req);
  if (pathname === "/api/auth/session" && req.method === "GET") {
    const session = sessionFrom(req);
    return json(res, 200, { authenticated: !!session, email: session?.email || null, expiresAt: session?.expiresAt || null });
  }

  if (pathname === "/api/auth/request-code" && req.method === "POST") {
    if (!rateLimit(`request:${ip}`, 5)) return json(res, 429, { error: "Too many attempts. Please wait a few minutes." });
    let data;
    try { data = await bodyJson(req); } catch (_) { return json(res, 400, { error: "Invalid request." }); }
    // The browser never supplies an email address. The server decides which
    // authorised mailbox receives the code, so the login page only needs the OTP.
    const configuredLoginEmail = normalEmail(process.env.AUTH_LOGIN_EMAIL);
    const configuredAllowed = allowedEmails();
    const email = configuredLoginEmail || configuredAllowed[0] || "";
    if (!email || !isAllowed(email) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return json(res, 500, { error: "Private login is not configured with an authorised email address." });
    }
    const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, "0");
    const pendingId = randomToken(24);
    loginCodes.set(hash(pendingId), {
      email,
      codeHash: hash(code),
      expiresAt: Date.now() + CODE_MINUTES * 60_000,
      used: false,
      attempts: 0,
    });
    try {
      await sendLoginCode(email, code);
    } catch (e) {
      loginCodes.delete(hash(pendingId));
      console.error("Resend error:", e.message);
      return json(res, 500, { error: "The sign-in email could not be sent. Check the server's Resend configuration." });
    }
    return json(res, 200, { ok: true, pendingId, expiresInSeconds: CODE_MINUTES * 60, message: "If that address is authorised, a code has been sent." });
  }

  if (pathname === "/api/auth/verify-code" && req.method === "POST") {
    if (!rateLimit(`verify:${ip}`, 10)) return json(res, 429, { error: "Too many attempts. Please wait a few minutes." });
    let data;
    try { data = await bodyJson(req); } catch (_) { return json(res, 400, { error: "Invalid request." }); }
    const pendingId = String(data.pendingId || "");
    const code = String(data.code || "").replace(/\D/g, "");
    const pending = loginCodes.get(hash(pendingId));
    if (!pending || pending.used || pending.expiresAt <= Date.now() || pending.attempts >= 5) {
      return json(res, 401, { error: "That code is invalid or has expired. Request a new one." });
    }
    pending.attempts += 1;
    if (hash(code) !== pending.codeHash) return json(res, 401, { error: "That code is incorrect." });

    pending.used = true;
    loginCodes.delete(hash(pendingId));
    const token = randomToken(32);
    const expiresAt = Date.now() + SESSION_DAYS * 24 * 60 * 60_000;
    sessions.set(hash(token), { email: pending.email, createdAt: Date.now(), expiresAt });
    saveAuth();
    return json(res, 200, { authenticated: true, email: pending.email, expiresAt }, {
      "Set-Cookie": cookie(COOKIE_NAME, token, SESSION_DAYS * 24 * 60 * 60),
    });
  }

  if (pathname === "/api/auth/logout" && req.method === "POST") {
    const token = parseCookies(req)[COOKIE_NAME];
    if (token) sessions.delete(hash(token));
    saveAuth();
    return json(res, 200, { authenticated: false }, { "Set-Cookie": clearCookie(COOKIE_NAME) });
  }

  return false;
}

function safeJoin(base, target) {
  const p = path.normalize(path.join(base, target));
  if (!p.startsWith(base)) return null;
  return p;
}
function serveFile(req, res, filePath, urlPath) {
  fs.readFile(filePath, (err, data) => {
    if (err) return sendIndex(req, res);
    const ext = path.extname(filePath).toLowerCase();
    const headers = { "Content-Type": MIME[ext] || "application/octet-stream" };
    if (NO_CACHE.has(urlPath)) headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
    else if (urlPath.startsWith("/static/")) headers["Cache-Control"] = "public, max-age=31536000, immutable";
    else headers["Cache-Control"] = "public, max-age=3600";
    if (urlPath === "/service-worker.js") headers["Service-Worker-Allowed"] = "/";
    const accept = req.headers["accept-encoding"] || "";
    if (/\b(gzip)\b/.test(accept) && data.length > 512 && /text|javascript|json|manifest|svg/.test(headers["Content-Type"])) {
      zlib.gzip(data, (e, gz) => {
        if (e) return send(res, 200, headers, data);
        headers["Content-Encoding"] = "gzip"; headers["Vary"] = "Accept-Encoding";
        send(res, 200, headers, gz);
      });
    } else send(res, 200, headers, data);
  });
}
function sendIndex(req, res) {
  const indexPath = path.join(BUILD_DIR, "index.html");
  fs.readFile(indexPath, (err, data) => {
    if (err) return send(res, 500, { "Content-Type": "text/plain" }, "Build not found. Run `npm run build`.");
    send(res, 200, { "Content-Type": MIME[".html"], "Cache-Control": "no-cache, no-store, must-revalidate" }, data);
  });
}

const server = http.createServer(async (req, res) => {
  if (!["GET", "HEAD", "POST"].includes(req.method)) return send(res, 405, { "Content-Type": "text/plain" }, "Method Not Allowed");
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, "http://localhost").pathname); } catch (_) { urlPath = "/"; }

  if (urlPath.startsWith("/api/auth/")) {
    const handled = await authRoute(req, res, urlPath);
    if (handled !== false) return;
  }

  // Every application API route requires the same private session.
  if (urlPath.startsWith("/api/")) {
    if (!sessionFrom(req)) return json(res, 401, { error: "Authentication required." });

    // Keep the existing assistant service, but put it behind the private session.
    // The upstream URL is never exposed to the browser.
    if (urlPath === "/api/chat" && req.method === "POST") {
      const upstream = process.env.BACKEND_UPSTREAM_URL || process.env.REACT_APP_BACKEND_URL;
      if (!upstream) return json(res, 503, { error: "Chat backend is not configured." });
      let payload;
      try { payload = await bodyJson(req); } catch (_) { return json(res, 400, { error: "Invalid request." }); }
      try {
        const upstreamRes = await fetch(`${upstream.replace(/\/$/, "")}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const text = await upstreamRes.text();
        res.writeHead(upstreamRes.status, {
          "Content-Type": upstreamRes.headers.get("content-type") || "application/json; charset=utf-8",
          "Cache-Control": "no-store",
        });
        return res.end(text);
      } catch (e) {
        console.error("Chat upstream error:", e.message);
        return json(res, 502, { error: "Chat service unavailable." });
      }
    }

    return json(res, 404, { error: "API route not found." });
  }

  // Public static branding/PWA metadata is intentionally available so browsers can
  // discover/install the PWA. The actual app is gated client-side by the session.
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, { "Content-Type": "text/plain" }, "Method Not Allowed");
  if (urlPath === "/") return sendIndex(req, res);
  const filePath = safeJoin(BUILD_DIR, urlPath);
  if (!filePath) return send(res, 400, { "Content-Type": "text/plain" }, "Bad Request");
  fs.stat(filePath, (err, stat) => {
    if (!err && stat.isFile()) return serveFile(req, res, filePath, urlPath);
    return sendIndex(req, res);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`Private AIB PWA listening on http://${HOST}:${PORT}`);
  if (!process.env.RESEND_API_KEY || !process.env.AUTH_FROM_EMAIL || !allowedEmails().length) {
    console.warn("Authentication is not configured: set RESEND_API_KEY, AUTH_FROM_EMAIL and AUTH_ALLOWED_EMAILS.");
  }
});
