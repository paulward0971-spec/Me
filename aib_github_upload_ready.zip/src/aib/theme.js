// AIB Demo Prototype - Dark theme with AIB purple accents (ported to web).
export const C = {
  surface: "#0A0A0A",
  onSurface: "#FFFFFF",
  surfaceSecondary: "#161616",
  onSurfaceSecondary: "#F5F5F5",
  surfaceTertiary: "#1F1F1F",
  onSurfaceTertiary: "#E5E5E5",
  surfaceInverse: "#FFFFFF",
  onSurfaceInverse: "#0A0A0A",
  muted: "#8E8E93",

  brand: "#8E24AA",
  onBrand: "#FFFFFF",
  brandPrimary: "#8E24AA",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#5F1478",
  onBrandSecondary: "#FFFFFF",
  brandTertiary: "#C77DDA",
  onBrandTertiary: "#FFFFFF",
  brandDeep: "#4A0E5C",
  brandLight: "#EED4F5",

  success: "#4CAF50",
  onSuccess: "#FFFFFF",
  warning: "#FFB74D",
  onWarning: "#0A0A0A",
  error: "#FF5252",
  onError: "#FFFFFF",
  info: "#64B5F6",
  onInfo: "#0A0A0A",

  border: "#2A2A2A",
  borderStrong: "#3D3D3D",
  divider: "#1F1F1F",
};

// Fixed logical width of the phone screen used across the app.
export const SCREEN_W = 402;
export const SCREEN_H = 874;
export const REF_W = 1284; // reference screenshot width
export const REF_H = 2778; // reference screenshot height
export const SCALE = SCREEN_W / REF_W;
