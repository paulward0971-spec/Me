import React from "react";
import { useNavigate } from "react-router-dom";
import { C } from "./theme";

const Icons = {
  home: (col) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 11 L12 4 L20 11 V20 A1 1 0 0 1 19 21 H14 V15 H10 V21 H5 A1 1 0 0 1 4 20 Z" stroke={col} strokeWidth={2} strokeLinejoin="round" fill="none" /></svg>),
  insights: (col) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="4" y="12" width="3" height="8" fill={col} rx="1" /><rect x="10.5" y="6" width="3" height="14" fill={col} rx="1" /><rect x="17" y="9" width="3" height="11" fill={col} rx="1" /></svg>),
  payments: (col) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M7 8 H19 L16 5" stroke={col} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" fill="none" /><path d="M17 16 H5 L8 19" stroke={col} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>),
  cards: (col) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="3" y="6" width="18" height="13" rx="2" stroke={col} strokeWidth={2} fill="none" /><line x1="3" y1="10" x2="21" y2="10" stroke={col} strokeWidth={2} /></svg>),
  products: (col) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 8 L12 4 L20 8 L12 12 Z" stroke={col} strokeWidth={2} strokeLinejoin="round" fill="none" /><path d="M4 12 L12 16 L20 12" stroke={col} strokeWidth={2} strokeLinejoin="round" fill="none" /><path d="M4 16 L12 20 L20 16" stroke={col} strokeWidth={2} strokeLinejoin="round" fill="none" /></svg>),
};

const TABS = [
  { key: "home", label: "Home", path: "/home" },
  { key: "insights", label: "Insights", path: "/insights" },
  { key: "payments", label: "Payments", path: "/payments" },
  { key: "cards", label: "Cards", path: "/cards" },
  { key: "products", label: "Products", path: "/products" },
];

export default function BottomNav({ active }) {
  const nav = useNavigate();
  return (
    <div className="aib-safe-bottom" style={{ display: "flex", justifyContent: "space-around", alignItems: "center", background: "#000", borderTop: `0.5px solid ${C.border}`, minHeight: 72, paddingTop: 8, flexShrink: 0 }}>
      {TABS.map((t) => {
        const on = t.key === active;
        const col = on ? C.onSurface : C.muted;
        return (
          <div key={t.key} className="aib-press" onClick={() => nav(t.path)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, width: 62 }}>
            {Icons[t.key](col)}
            <span style={{ color: col, fontSize: 11, fontWeight: on ? 700 : 500 }}>{t.label}</span>
          </div>
        );
      })}
    </div>
  );
}
