// AIB branches across Ireland (representative list of the 170+ branch network).
export const AIB_BRANCHES = [
  // Dublin
  { name: "Artane", county: "Dublin" }, { name: "Balbriggan", county: "Dublin" }, { name: "Ballsbridge", county: "Dublin" },
  { name: "Ballymount", county: "Dublin" }, { name: "Ballymun", county: "Dublin" }, { name: "Blackrock", county: "Dublin" },
  { name: "Blanchardstown", county: "Dublin" }, { name: "Cabra", county: "Dublin" }, { name: "Carrickmines", county: "Dublin" },
  { name: "Clondalkin", county: "Dublin" }, { name: "Clonskeagh", county: "Dublin" }, { name: "Cornelscourt", county: "Dublin" },
  { name: "Crumlin", county: "Dublin" }, { name: "Dame Street", county: "Dublin" }, { name: "Drumcondra", county: "Dublin" },
  { name: "Dublin Airport", county: "Dublin" }, { name: "Dún Laoghaire", county: "Dublin" }, { name: "Dundrum", county: "Dublin" },
  { name: "Finglas", county: "Dublin" }, { name: "Grafton Street", county: "Dublin" }, { name: "IFSC", county: "Dublin" },
  { name: "Lucan", county: "Dublin" }, { name: "Malahide", county: "Dublin" }, { name: "Nutgrove", county: "Dublin" },
  { name: "O'Connell Street", county: "Dublin" }, { name: "Phibsborough", county: "Dublin" }, { name: "Raheny", county: "Dublin" },
  { name: "Ranelagh", county: "Dublin" }, { name: "Rathfarnham", county: "Dublin" }, { name: "Rathgar", county: "Dublin" },
  { name: "Rathmines", county: "Dublin" }, { name: "Sandymount", county: "Dublin" }, { name: "Santry", county: "Dublin" },
  { name: "Stillorgan", county: "Dublin" }, { name: "Swords", county: "Dublin" }, { name: "Tallaght", county: "Dublin" },
  { name: "Terenure", county: "Dublin" }, { name: "Walkinstown", county: "Dublin" },
  // Cork
  { name: "Ballincollig", county: "Cork" }, { name: "Bandon", county: "Cork" }, { name: "Bantry", county: "Cork" },
  { name: "Bishopstown", county: "Cork" }, { name: "Blackpool", county: "Cork" }, { name: "Blarney", county: "Cork" },
  { name: "Carrigaline", county: "Cork" }, { name: "Castletownbere", county: "Cork" }, { name: "Charleville", county: "Cork" },
  { name: "Clonakilty", county: "Cork" }, { name: "Cobh", county: "Cork" }, { name: "Patrick Street (Cork City)", county: "Cork" },
  { name: "Douglas", county: "Cork" }, { name: "Dunmanway", county: "Cork" }, { name: "Fermoy", county: "Cork" },
  { name: "Glanmire", county: "Cork" }, { name: "Kanturk", county: "Cork" }, { name: "Kinsale", county: "Cork" },
  { name: "Macroom", county: "Cork" }, { name: "Mallow", county: "Cork" }, { name: "Midleton", county: "Cork" },
  { name: "Millstreet", county: "Cork" }, { name: "Mitchelstown", county: "Cork" }, { name: "Skibbereen", county: "Cork" },
  { name: "South Mall", county: "Cork" }, { name: "Youghal", county: "Cork" },
  // Galway
  { name: "Athenry", county: "Galway" }, { name: "Ballinasloe", county: "Galway" }, { name: "Clifden", county: "Galway" },
  { name: "Gort", county: "Galway" }, { name: "Loughrea", county: "Galway" }, { name: "Lynch's Castle (Galway City)", county: "Galway" },
  { name: "Oranmore", county: "Galway" }, { name: "Salthill", county: "Galway" }, { name: "Spiddal", county: "Galway" },
  { name: "Tuam", county: "Galway" },
  // Kerry
  { name: "Cahersiveen", county: "Kerry" }, { name: "Castleisland", county: "Kerry" }, { name: "Dingle", county: "Kerry" },
  { name: "Kenmare", county: "Kerry" }, { name: "Killarney", county: "Kerry" }, { name: "Killorglin", county: "Kerry" },
  { name: "Listowel", county: "Kerry" }, { name: "Tralee", county: "Kerry" },
  // Limerick
  { name: "O'Connell Street (Limerick City)", county: "Limerick" }, { name: "Newcastle West", county: "Limerick" },
  { name: "Abbeyfeale", county: "Limerick" }, { name: "Kilmallock", county: "Limerick" }, { name: "Adare", county: "Limerick" },
  { name: "Castletroy", county: "Limerick" },
  // Clare
  { name: "Ennis", county: "Clare" }, { name: "Kilrush", county: "Clare" }, { name: "Shannon", county: "Clare" },
  { name: "Ennistymon", county: "Clare" }, { name: "Killaloe", county: "Clare" },
  // Tipperary
  { name: "Clonmel", county: "Tipperary" }, { name: "Nenagh", county: "Tipperary" }, { name: "Thurles", county: "Tipperary" },
  { name: "Tipperary Town", county: "Tipperary" }, { name: "Cashel", county: "Tipperary" }, { name: "Roscrea", county: "Tipperary" },
  { name: "Carrick-on-Suir", county: "Tipperary" },
  // Waterford
  { name: "Waterford City", county: "Waterford" }, { name: "Dungarvan", county: "Waterford" }, { name: "Tramore", county: "Waterford" },
  { name: "Lismore", county: "Waterford" },
  // Wexford
  { name: "Wexford Town", county: "Wexford" }, { name: "Enniscorthy", county: "Wexford" }, { name: "Gorey", county: "Wexford" },
  { name: "New Ross", county: "Wexford" },
  // Wicklow
  { name: "Bray", county: "Wicklow" }, { name: "Wicklow Town", county: "Wicklow" }, { name: "Arklow", county: "Wicklow" },
  { name: "Greystones", county: "Wicklow" }, { name: "Blessington", county: "Wicklow" },
  // Kilkenny / Carlow / Laois / Offaly
  { name: "Kilkenny City", county: "Kilkenny" }, { name: "Callan", county: "Kilkenny" }, { name: "Thomastown", county: "Kilkenny" },
  { name: "Carlow Town", county: "Carlow" }, { name: "Tullow", county: "Carlow" }, { name: "Bagenalstown", county: "Carlow" },
  { name: "Portlaoise", county: "Laois" }, { name: "Portarlington", county: "Laois" }, { name: "Mountmellick", county: "Laois" },
  { name: "Tullamore", county: "Offaly" }, { name: "Birr", county: "Offaly" }, { name: "Edenderry", county: "Offaly" },
  // Kildare
  { name: "Naas", county: "Kildare" }, { name: "Newbridge", county: "Kildare" }, { name: "Athy", county: "Kildare" },
  { name: "Kildare Town", county: "Kildare" }, { name: "Maynooth", county: "Kildare" }, { name: "Celbridge", county: "Kildare" },
  { name: "Leixlip", county: "Kildare" }, { name: "Clane", county: "Kildare" }, { name: "Monasterevin", county: "Kildare" },
  // Meath / Louth
  { name: "Navan", county: "Meath" }, { name: "Trim", county: "Meath" }, { name: "Kells", county: "Meath" },
  { name: "Ashbourne", county: "Meath" }, { name: "Dunshaughlin", county: "Meath" }, { name: "Laytown", county: "Meath" },
  { name: "Drogheda", county: "Louth" }, { name: "Dundalk", county: "Louth" }, { name: "Ardee", county: "Louth" },
  // Midlands / Border / West
  { name: "Athlone", county: "Westmeath" }, { name: "Mullingar", county: "Westmeath" }, { name: "Moate", county: "Westmeath" },
  { name: "Longford Town", county: "Longford" },
  { name: "Cavan Town", county: "Cavan" }, { name: "Bailieborough", county: "Cavan" }, { name: "Cootehill", county: "Cavan" }, { name: "Virginia", county: "Cavan" },
  { name: "Monaghan Town", county: "Monaghan" }, { name: "Carrickmacross", county: "Monaghan" }, { name: "Castleblayney", county: "Monaghan" }, { name: "Clones", county: "Monaghan" },
  { name: "Letterkenny", county: "Donegal" }, { name: "Donegal Town", county: "Donegal" }, { name: "Ballybofey", county: "Donegal" },
  { name: "Buncrana", county: "Donegal" }, { name: "Bundoran", county: "Donegal" }, { name: "Dungloe", county: "Donegal" }, { name: "Carndonagh", county: "Donegal" },
  { name: "Sligo Town", county: "Sligo" }, { name: "Ballymote", county: "Sligo" }, { name: "Tubbercurry", county: "Sligo" },
  { name: "Carrick-on-Shannon", county: "Leitrim" }, { name: "Manorhamilton", county: "Leitrim" },
  { name: "Castlebar", county: "Mayo" }, { name: "Ballina", county: "Mayo" }, { name: "Westport", county: "Mayo" },
  { name: "Claremorris", county: "Mayo" }, { name: "Ballinrobe", county: "Mayo" }, { name: "Belmullet", county: "Mayo" },
  { name: "Swinford", county: "Mayo" }, { name: "Ballyhaunis", county: "Mayo" },
  { name: "Roscommon Town", county: "Roscommon" }, { name: "Boyle", county: "Roscommon" }, { name: "Castlerea", county: "Roscommon" },
];
