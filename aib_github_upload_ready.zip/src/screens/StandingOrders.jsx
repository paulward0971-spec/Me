import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, Plus, Trash2, Repeat } from "lucide-react";
import StatusBar from "../aib/StatusBar";
import BottomNav from "../aib/BottomNav";
import { api, formatEuros, formatIban, detectBank } from "../aib/mock";
import { C } from "../aib/theme";
import { BankLogo } from "../aib/BankLogo";
import { Countdown } from "../aib/Countdown";

function fmtDate(d) {
  try { return new Date(d).toLocaleDateString("en-IE", { day: "2-digit", month: "short", year: "numeric" }); } catch (e) { return "—"; }
}

export default function StandingOrders() {
  const nav = useNavigate();
  const [orders, setOrders] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [sheet, setSheet] = useState(false);
  const [form, setForm] = useState({ name: "", iban: "", amount: "", freq: "Monthly", reference: "" });
  const [toast, setToast] = useState(null);

  const refresh = () => {
    api.listStandingOrders().then(setOrders);
    api.listTransfers().then((all) => setTransfers((all || []).filter((t) => t.status !== "prepared").sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 6)));
  };
  useEffect(() => { refresh(); }, []);
  const show = (m) => { setToast(m); setTimeout(() => setToast(null), 1600); };

  const bank = useMemo(() => (form.iban.replace(/\s+/g, "").length >= 6 ? detectBank(form.iban) : null), [form.iban]);
  const canSave = form.name.trim().length > 1 && form.iban.replace(/\s+/g, "").length >= 15 && Number(form.amount) > 0;

  const create = async () => {
    if (!canSave) { show("Fill in name, IBAN and amount"); return; }
    await api.createStandingOrder({
      payee_name: form.name.trim(),
      iban: form.iban,
      amount_cents: Math.round(Number(form.amount) * 100),
      frequency: form.freq,
      reference: form.reference.trim() || "Standing order",
      next_date: new Date(Date.now() + 3 * 86400000).toISOString(),
    });
    setForm({ name: "", iban: "", amount: "", freq: "Monthly", reference: "" });
    setSheet(false); refresh(); show("Standing order created");
  };

  const toggle = async (id) => { await api.toggleStandingOrder(id); refresh(); };
  const remove = async (id) => { await api.deleteStandingOrder(id); refresh(); show("Standing order removed"); };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#000" }} data-testid="standing-orders-screen">
      <StatusBar />
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 16px 12px" }}>
        <div className="aib-press" data-testid="so-back-btn" onClick={() => nav(-1)} style={{ width: 38, height: 38, borderRadius: 19, background: C.surfaceSecondary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><ChevronLeft size={22} color="#fff" /></div>
        <div style={{ flex: 1 }}>
          <div style={{ color: "#fff", fontSize: 26, fontWeight: 900 }}>Standing orders</div>
          <div style={{ color: C.muted, fontSize: 13 }}>Recurring SEPA payments</div>
        </div>
        <div className="aib-press" data-testid="so-add-btn" onClick={() => setSheet(true)} style={{ width: 40, height: 40, borderRadius: 20, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Plus size={22} color="#fff" /></div>
      </div>

      <div className="aib-scroll" style={{ flex: 1, padding: "0 16px 24px" }}>
        {/* Active standing orders */}
        {orders.length === 0 ? (
          <div style={{ background: "#111", borderRadius: 16, padding: 24, textAlign: "center", marginTop: 8 }}>
            <div style={{ color: "#fff", fontSize: 16, fontWeight: 900 }}>No standing orders yet</div>
            <div style={{ color: C.muted, fontSize: 13, marginTop: 8, lineHeight: "18px" }}>Set up a recurring payment and it will appear here.</div>
            <div className="aib-btn" data-testid="so-empty-add" onClick={() => setSheet(true)} style={{ display: "inline-block", marginTop: 16, background: C.brandPrimary, padding: "12px 22px", borderRadius: 999, color: "#fff", fontWeight: 800 }}>New standing order</div>
          </div>
        ) : orders.map((o) => (
          <div key={o.id} data-testid="so-item" style={{ background: "#111", borderRadius: 16, padding: 16, marginTop: 12, opacity: o.active ? 1 : 0.55 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <BankLogo slug={o.bank_slug || "aib"} size={42} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: "#fff", fontSize: 16, fontWeight: 800, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{o.payee_name}</div>
                <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>{o.bank_name || "Bank"} • {formatIban(o.iban).slice(0, 22)}…</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ color: "#fff", fontSize: 16, fontWeight: 900 }}>{formatEuros(-Math.abs(o.amount_cents))}</div>
                <div style={{ color: C.brandLight, fontSize: 11, fontWeight: 800, marginTop: 2 }}>{o.frequency}</div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 12, paddingTop: 12, borderTop: `0.5px solid ${C.border}` }}>
              <div style={{ color: C.muted, fontSize: 12 }}>
                <div>Next payment {fmtDate(o.next_date)}</div>
                <div style={{ color: C.info, marginTop: 2, fontWeight: 700 }}>SEPA · arrives within 24 hours of sending</div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <div className="aib-press" data-testid="so-toggle" onClick={() => toggle(o.id)} style={{ padding: "6px 12px", borderRadius: 999, background: o.active ? "rgba(76,175,80,0.15)" : "rgba(255,183,77,0.15)", color: o.active ? C.success : C.warning, fontSize: 12, fontWeight: 800 }}>{o.active ? "Active" : "Paused"}</div>
                <div className="aib-press" data-testid="so-delete" onClick={() => remove(o.id)} style={{ width: 32, height: 32, borderRadius: 16, background: "rgba(255,82,82,0.14)", display: "flex", alignItems: "center", justifyContent: "center" }}><Trash2 size={16} color={C.error} /></div>
              </div>
            </div>
          </div>
        ))}

        {/* Recent payments with expected arrival time */}
        <div style={{ color: "#fff", fontSize: 20, fontWeight: 900, margin: "26px 2px 4px" }}>Recent payments</div>
        <div style={{ color: C.muted, fontSize: 13, marginBottom: 6 }}>How long until money reaches the recipient</div>
        {transfers.length === 0 ? (
          <div style={{ color: C.muted, fontSize: 13, padding: "16px 4px" }}>No recent payments. Money you send will show its live arrival time here.</div>
        ) : transfers.map((t) => {
          const delivered = Date.now() > new Date(t.created_at).getTime() + 24 * 3600 * 1000;
          const queued = t.status === "queued";
          return (
            <div key={t.id} className="aib-press" data-testid="so-recent-payment" onClick={() => nav(`/transfer/success/${t.id}`)} style={{ background: "#141416", borderRadius: 14, padding: 14, marginTop: 10 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <BankLogo slug={t.bank_slug || "aib"} size={38} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ color: "#fff", fontSize: 15, fontWeight: 800, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.recipient_name}</div>
                  <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>Ref {t.reference || t.note}</div>
                </div>
                <div style={{ color: "#fff", fontSize: 15, fontWeight: 900 }}>{formatEuros(-Math.abs(t.amount_cents))}</div>
              </div>
              <div style={{ marginTop: 10, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 12, fontWeight: 800, color: queued ? C.warning : delivered ? C.success : C.info }}>
                  {queued ? "Queued offline" : delivered ? "Delivered" : "Processing"}
                </span>
                <span style={{ color: queued ? C.warning : delivered ? C.success : C.info, fontSize: 13, fontWeight: 800 }}>
                  {queued ? "Waiting for connection" : <Countdown createdAt={t.created_at} prefix="Arrives in " doneText="Funds delivered" />}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <BottomNav active="payments" />

      {sheet && (
        <div onClick={() => setSheet(false)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "flex-end", zIndex: 50 }}>
          <div onClick={(e) => e.stopPropagation()} className="aib-fadein" style={{ width: "100%", background: "#0F0F0F", padding: "20px 20px 32px", borderTopLeftRadius: 20, borderTopRightRadius: 20 }}>
            <div style={{ width: 40, height: 4, borderRadius: 2, background: "#3D3D3D", margin: "0 auto 16px" }} />
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 20, background: "rgba(142,36,170,0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}><Repeat size={20} color={C.brandTertiary} /></div>
              <div style={{ color: "#fff", fontSize: 20, fontWeight: 900 }}>New standing order</div>
            </div>
            <input data-testid="so-name-input" style={inp} placeholder="Payee name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input data-testid="so-iban-input" style={inp} placeholder="IBAN" value={form.iban} onChange={(e) => setForm({ ...form, iban: e.target.value.toUpperCase() })} />
            {bank && (
              <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#161616", padding: 10, borderRadius: 10, marginBottom: 10 }}>
                <BankLogo slug={bank.slug} size={28} />
                <div style={{ color: "#fff", fontSize: 13, fontWeight: 800 }}>{bank.bank_name}</div>
              </div>
            )}
            <input data-testid="so-amount-input" style={inp} placeholder="Amount (EUR)" inputMode="decimal" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
            <input data-testid="so-ref-input" style={inp} placeholder="Reference (optional)" value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} maxLength={35} />
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              {["Weekly", "Monthly", "Quarterly"].map((f) => (
                <div key={f} className="aib-press" onClick={() => setForm({ ...form, freq: f })} style={{ padding: "10px 16px", borderRadius: 999, background: form.freq === f ? C.brandPrimary : "#161616", color: form.freq === f ? "#fff" : C.muted, fontWeight: 700, fontSize: 13 }}>{f}</div>
              ))}
            </div>
            <div className="aib-btn" data-testid="so-create-btn" onClick={create} style={{ background: C.brandPrimary, padding: 14, borderRadius: 999, textAlign: "center", color: "#fff", fontSize: 15, fontWeight: 800, opacity: canSave ? 1 : 0.5 }}>Create standing order</div>
          </div>
        </div>
      )}

      {toast && <div className="aib-fadein" style={{ position: "absolute", left: 24, right: 24, bottom: 110, background: "rgba(20,20,22,0.96)", border: "1px solid #2A2A2A", borderRadius: 14, padding: "14px 18px", color: "#fff", fontSize: 14, fontWeight: 700, textAlign: "center", zIndex: 40 }}>{toast}</div>}
    </div>
  );
}

const inp = { width: "100%", background: "#161616", color: "#fff", padding: 14, borderRadius: 12, fontSize: 15, fontWeight: 600, marginBottom: 10, border: "none" };
