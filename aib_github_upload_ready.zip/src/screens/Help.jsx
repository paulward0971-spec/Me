import React from "react";
import { useNavigate } from "react-router-dom";
import { C } from "../aib/theme";

function AbiOrb({ size = 150 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 200 200">
      <defs>
        <linearGradient id="orb1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#C24BE0" /><stop offset="1" stopColor="#7B1FA2" /></linearGradient>
        <linearGradient id="orb2" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#B24DD1" /><stop offset="1" stopColor="#4A0E5C" /></linearGradient>
      </defs>
      <path d="M100 30 C 145 30, 170 60, 170 100 C 170 140, 145 170, 100 170 C 80 170, 65 158, 65 140 C 65 120, 82 108, 100 108 C 118 108, 130 96, 130 78 C 130 60, 118 46, 100 46 Z" fill="url(#orb1)" />
      <path d="M100 60 C 128 60, 140 78, 140 100 C 140 122, 122 138, 100 138 C 90 138, 84 132, 84 122 C 84 112, 92 106, 100 106 C 116 106, 124 96, 124 82 C 124 68, 116 60, 100 60 Z" fill="url(#orb2)" opacity="0.9" />
      <circle cx="100" cy="100" r="18" fill="#000" opacity="0.85" />
    </svg>
  );
}
function Icon({ name, color = "#fff", size = 20 }) {
  if (name === "help") return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke={color} strokeWidth={1.6} fill="none" /><path d="M9.5 9 A2.5 2.5 0 0 1 14.5 9 C14.5 11 12 11 12 13" stroke={color} strokeWidth={1.6} strokeLinecap="round" fill="none" /><circle cx="12" cy="17" r="1" fill={color} /></svg>);
  if (name === "pin") return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M12 2 C7 2, 4 6, 4 10 C4 15, 12 22, 12 22 C12 22, 20 15, 20 10 C20 6, 17 2, 12 2 Z" stroke={color} strokeWidth={1.6} fill="none" /><circle cx="12" cy="10" r="3" stroke={color} strokeWidth={1.6} fill="none" /></svg>);
  if (name === "phone") return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M4 5 C4 4, 5 3, 6 3 L8 3 L10 8 L8 10 C9 13, 11 15, 14 16 L16 14 L21 16 L21 18 C21 19, 20 20, 19 20 C11 20, 4 13, 4 5 Z" stroke={color} strokeWidth={1.6} strokeLinejoin="round" fill="none" /></svg>);
  if (name === "chev") return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M9 5 L16 12 L9 19" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>);
  return (<svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M15 5 L8 12 L15 19" stroke={color} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>);
}

export default function Help() {
  const nav = useNavigate();
  return (
    <div style={{ height: "100%", background: "#000" }}>
      <div className="aib-scroll" style={{ padding: "40px 16px 40px" }}>
        <div className="aib-press" onClick={() => nav(-1)} style={{ width: 40, height: 40, borderRadius: 20, background: "#1A1A1A", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}><Icon name="back" color="#E1BEE7" size={22} /></div>
        <div style={{ color: "#fff", fontSize: 34, fontWeight: 900, marginBottom: 22 }}>How can we help?</div>
        <div style={{ background: "#0F0F0F", borderRadius: 20, padding: "26px 20px", display: "flex", flexDirection: "column", alignItems: "center", border: "1px solid #1F1F1F" }}>
          <AbiOrb size={150} />
          <div style={{ color: "#fff", fontSize: 20, fontWeight: 900, textAlign: "center", marginTop: 8, lineHeight: "26px" }}>Hi, I'm Abi, I'm your digital assistant.</div>
          <div className="aib-btn" onClick={() => nav("/chat")} style={{ marginTop: 20, background: C.brandPrimary, borderRadius: 999, padding: 16, textAlign: "center", alignSelf: "stretch", color: "#fff", fontSize: 18, fontWeight: 800 }}>Ask Abi</div>
        </div>
        <div style={{ background: "#0F0F0F", borderRadius: 16, marginTop: 22, border: "1px solid #1F1F1F" }}>
          <div className="aib-press" style={link}><div style={linkIcon}><Icon name="help" /></div><span style={{ color: "#fff", fontSize: 16, fontWeight: 800, flex: 1 }}>Frequently asked questions</span><Icon name="chev" color={C.muted} size={18} /></div>
          <div style={{ height: 1, background: "#1F1F1F", margin: "0 16px" }} />
          <div className="aib-press" style={link}><div style={linkIcon}><Icon name="pin" /></div><span style={{ color: "#fff", fontSize: 16, fontWeight: 800, flex: 1 }}>Find AIB branch</span><Icon name="chev" color={C.muted} size={18} /></div>
        </div>
        <div className="aib-press" style={{ display: "flex", alignItems: "center", gap: 8, justifyContent: "center", marginTop: 22, padding: 10 }}><Icon name="phone" color="#E1BEE7" /><span style={{ color: "#E1BEE7", fontSize: 16, fontWeight: 800 }}>Contact us</span></div>
      </div>
    </div>
  );
}
const link = { display: "flex", alignItems: "center", padding: 16, gap: 14 };
const linkIcon = { width: 34, height: 34, borderRadius: 17, background: C.brandPrimary, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 };
