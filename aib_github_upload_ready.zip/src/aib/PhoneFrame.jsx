import React from "react";

export default function PhoneFrame({ children }) {
  return (
    <div className="aib-stage">
      <div className="aib-phone">
        <div className="aib-island" />
        <div className="aib-screen">{children}</div>
      </div>
    </div>
  );
}
