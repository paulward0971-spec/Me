export function formatEuros(cents) {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents || 0);
  const euros = (abs / 100).toFixed(2);
  return `${sign}\u20AC${euros}`;
}

export function formatIban(iban) {
  const clean = String(iban || "").replace(/\s+/g, "").toUpperCase();
  return clean.match(/.{1,4}/g)?.join(" ") ?? clean;
}
