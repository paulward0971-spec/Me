import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../aib/mock";
import { C } from "../aib/theme";

export default function Settings() {
  const nav = useNavigate();
  const [profile, setProfile] = useState(null);
  const [saved, setSaved] = useState(false);
  const [err, setErr] = useState(null);
  const [linking, setLinking] = useState(false);
  const [linkMsg, setLinkMsg] = useState(null);

  useEffect(() => { api.getProfile().then(setProfile); }, []);
  const set = (k, v) => setProfile((p) => ({ ...p, [k]: v }));

  const linkEmail = async () => {
    setLinkMsg(null); setErr(null);
    const email = (profile.email || "").trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setErr("Enter a valid email address first"); return; }
    setLinking(true);
    try { const r = await api.verifyEmail(email); setLinkMsg(`Email linked. Confirmation sent (ref ${r.reference}).`); }
    catch (e) { setErr(e.message || "Could not link email"); } finally { setLinking(false); }
  };

  const save = async () => {
    setErr(null);
    try {
      const patch = {
        display_name: profile.display_name, account_holder: profile.account_holder, account_label: profile.account_label,
        balance_cents: Math.round(Number(profile.balance_cents || 0)), available_cents: Math.round(Number(profile.available_cents || 0)),
        monthly_spent_cents: Math.round(Number(profile.monthly_spent_cents || 0)),
        card_last4: profile.card_last4, card_holder: profile.card_holder, card_expiry: profile.card_expiry,
        iban: profile.iban, bic: profile.bic, account_number: profile.account_number, sort_code: profile.sort_code, email: profile.email || "",
      };
      const updated = await api.updateProfile(patch);
      setProfile(updated); setSaved(true); setTimeout(() => setSaved(false), 1600);
    } catch (e) { setErr(e.message || "Save failed"); }
  };

  const resetDemo = () => { api.resetDemo(); window.location.href = "/"; };

  if (!profile) return <div style={{ height: "100%", background: C.surface }} />;

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: C.surface }}>
      <div style={{ padding: "38px 20px 8px" }}>
        <div className="aib-press" onClick={() => nav(-1)} style={{ color: C.brandLight, fontSize: 15, fontWeight: 700 }}>‹  Back</div>
        <div style={{ color: "#fff", fontSize: 32, fontWeight: 900, marginTop: 8 }}>Settings</div>
      </div>
      <div className="aib-scroll" style={{ flex: 1, padding: "12px 20px 60px" }}>
        {/* DEMO DISCLAIMER */}
        <div style={{ background: "rgba(255,183,77,0.10)", border: "1px solid rgba(255,183,77,0.35)", borderRadius: 14, padding: 16, marginBottom: 14 }}>
          <div style={{ color: C.warning, fontWeight: 900, fontSize: 15 }}>This is a demo — not a real transfer</div>
          <div style={{ color: "#F3D9AE", fontSize: 13, marginTop: 6, lineHeight: "19px" }}>This app is a demonstration prototype. No real money ever moves, no real bank account is affected, and no real payment is made. Transfers, balances, receipts and emails shown here are simulated for demonstration only. It is not issued by or connected to any bank. Do not treat anything in this app as proof of a real bank transaction.</div>
        </div>
        <div style={{ background: "rgba(100,181,246,0.10)", borderLeft: `3px solid ${C.info}`, borderRadius: 12, padding: 14, marginBottom: 18 }}>
          <div style={{ color: C.info, fontWeight: 800, fontSize: 14 }}>About this app</div>
          <div style={{ color: "#B5D6F5", fontSize: 13, marginTop: 6, lineHeight: "18px" }}>An educational banking prototype. The receipt/email uses AIB Banking styling for the prototype but is not issued by or sent from AIB.</div>
        </div>

        <Section title="Security" />
        <div style={{ display: "flex", alignItems: "center", background: C.surfaceSecondary, borderRadius: 12, padding: 14 }}>
          <div style={{ flex: 1, paddingRight: 12 }}>
            <div style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>Biometric sign-in</div>
            <div style={{ color: C.muted, fontSize: 12, marginTop: 4, lineHeight: "16px" }}>Not available in this web demo. On a phone you can unlock with Face ID / fingerprint.</div>
          </div>
          <div style={{ width: 46, height: 28, borderRadius: 999, background: C.border, position: "relative", opacity: 0.6 }}><div style={{ width: 24, height: 24, borderRadius: 12, background: "#fff", position: "absolute", top: 2, left: 2 }} /></div>
        </div>
        <div className="aib-press" onClick={() => { setLinkMsg("Owner tools are disabled in this web demo."); }} style={{ display: "flex", alignItems: "center", background: C.surfaceSecondary, borderRadius: 12, padding: 14, marginTop: 10 }}>
          <div style={{ flex: 1 }}><div style={{ color: "#fff", fontSize: 15, fontWeight: 800 }}>Invite codes & owner access</div><div style={{ color: C.muted, fontSize: 12, marginTop: 4, lineHeight: "16px" }}>Generate one-time invite codes and manage owner access.</div></div>
          <span style={{ color: C.muted, fontSize: 22, marginLeft: 12 }}>›</span>
        </div>

        <Section title="Profile" />
        <Field label="Display name" value={profile.display_name} onChange={(v) => set("display_name", v)} />
        <Field label="Account holder" value={profile.account_holder} onChange={(v) => set("account_holder", v)} />
        <Field label="Email (for receipts)" value={profile.email || ""} onChange={(v) => set("email", v)} />
        <div className="aib-btn" onClick={!linking ? linkEmail : undefined} style={{ marginTop: 4, marginBottom: 8, background: C.brandDeep, padding: 14, borderRadius: 12, textAlign: "center", border: `1px solid ${C.brandPrimary}`, color: "#fff", fontSize: 14, fontWeight: 800 }}>{linking ? "Sending confirmation…" : "Link email & send confirmation"}</div>
        {linkMsg && <div style={{ color: C.success, fontSize: 13, marginTop: 4, marginBottom: 8, fontWeight: 700 }}>{linkMsg}</div>}

        <Section title="Account" />
        <Field label="Account label" value={profile.account_label} onChange={(v) => set("account_label", v)} />
        <Field label="Balance (EUR)" value={String((profile.balance_cents ?? 0) / 100)} onChange={(v) => set("balance_cents", Number(v) * 100)} />
        <Field label="Available (EUR)" value={String((profile.available_cents ?? 0) / 100)} onChange={(v) => set("available_cents", Number(v) * 100)} />
        <Field label="Monthly spent (EUR)" value={String((profile.monthly_spent_cents ?? 0) / 100)} onChange={(v) => set("monthly_spent_cents", Number(v) * 100)} />
        <Field label="IBAN" value={profile.iban} onChange={(v) => set("iban", v.toUpperCase())} />
        <Field label="BIC" value={profile.bic} onChange={(v) => set("bic", v.toUpperCase())} />
        <Field label="Account number" value={profile.account_number} onChange={(v) => set("account_number", v)} />
        <Field label="Sort code" value={profile.sort_code} onChange={(v) => set("sort_code", v)} />

        <Section title="Card" />
        <Field label="Cardholder" value={profile.card_holder} onChange={(v) => set("card_holder", v)} />
        <Field label="Last 4" value={profile.card_last4} onChange={(v) => set("card_last4", v)} />
        <Field label="Expiry (MM/YY)" value={profile.card_expiry} onChange={(v) => set("card_expiry", v)} />

        {err && <div style={{ color: C.error, marginTop: 12 }}>{err}</div>}
        {saved && <div style={{ color: C.success, marginTop: 12, fontWeight: 700 }}>Saved ✓</div>}
        <div className="aib-btn" onClick={save} style={{ marginTop: 24, background: C.brandPrimary, padding: 16, borderRadius: 999, textAlign: "center", color: "#fff", fontSize: 16, fontWeight: 800 }}>Save changes</div>
        <div className="aib-press" onClick={resetDemo} style={{ marginTop: 14, padding: 12, textAlign: "center", color: C.muted, fontSize: 14, fontWeight: 700 }}>Reset demo data</div>
      </div>
    </div>
  );
}

function Section({ title }) { return <div style={{ color: C.brandLight, fontSize: 12, fontWeight: 800, letterSpacing: 1, marginTop: 14, marginBottom: 10, textTransform: "uppercase" }}>{title}</div>; }
function Field({ label, value, onChange }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ color: C.muted, fontSize: 12, marginBottom: 6, fontWeight: 700 }}>{label}</div>
      <input value={value || ""} onChange={(e) => onChange(e.target.value)} style={{ width: "100%", background: C.surfaceSecondary, color: "#fff", padding: 14, borderRadius: 12, fontSize: 15, fontWeight: 600, border: "none" }} />
    </div>
  );
}
